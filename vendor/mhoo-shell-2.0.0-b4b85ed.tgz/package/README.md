# Mhoo Shell

## Mhoo Docs and Particle

Run `npm run workbench`, then open `http://127.0.0.1:4183/docs` for the content-first
manual. `/docs/field` provides the connected particle graph and floating search
adapted from mhoo.dev. The [documentation source](docs/content/start.md),
[Particle foundation](docs/content/particle.md), and [Jev review guide](docs/content/jev.md)
are versioned here. `npm run docs:check` validates source; `npm run test:docs`
checks compilation and review contracts. The workbench build bundles the docs.

Particle UI now owns its own `docs/catalog.json` and two Markdown pages. The
private `/api/docs/catalog` endpoint aggregates Shell and Particle UI as
`shell/*` and `particle-ui/*` IDs; it is protected by the same Shell identity
gate. The reader, search, and field browse both projects; Jev review remains
Shell-owned. A short
local [field motion clip](docs/assets/field-formation.webm) and written
equivalent are in the Particle foundation page.

Jev page review is explicit and advisory, with the current page and supplied
change evidence recorded through existing owner-scoped D1 traces. No automatic
editing, PR comments, publication, or remote deployment is introduced.

New Mhoo design work uses **Mhoo Core — Particle** as its brand foundation.
Import `@mhoo/particle-ui/styles.css` and `formParticles` / `dissolveParticles`
from the separate `@mhoo/particle-ui` package for framework-neutral effects.
Shell retains `@mhoo/shell/particle` as a compatibility export. The docs
gallery is the initial consumer; migration of older Shell/Observer surfaces is incremental.

## Live app workbench experiment

Run `npm run workbench` and open `http://127.0.0.1:4183` to see the bare Shell
frame with no app mounted. The legacy Workbench APIs and Observer route remain
available during their move to the separate Workbench repository, but their UI
is no longer part of the Shell entry. See [the workbench guide](examples/workbench/README.md).
This is a development example; the Shell library does not acquire app-specific
business logic, authentication, or fixed production routes.

This is the standalone, private source repository for `@mhoo/shell`. Design Studio is a consumer, not the owner. The package can be installed from this repository or a local path; it is not published to npm. The 1.0 candidate includes a framework-neutral host control-plane adapter, while the host Worker still owns identity, D1, service bindings, and deployment custody.

A framework-neutral shell library, not an inline page template. It supplies the workspace rail, collapsible navigation, rounded page surface, and 48px header observed in Mhoo Twenty. Application content is edge-to-edge by default; your app owns padding, borders, cards, and split-pane layout inside `appRoot`. An explicit `framed` mode retains the inset bordered surface.

The library uses the pinned MIT `twenty-ui` light/dark theme CSS snapshots from Twenty v2.37.0 (`6da524b8903ec16a3eeea4b2e4a5fb63dbfc1c58`). Keep `vendor/twenty-ui/LICENSE` with copies. Shell markup and behavior are independently authored; no AGPL Twenty Front JSX, styles, or runtime are vendored. The output is structurally equivalent for app embedding, not byte-for-byte Twenty DOM. See [REFERENCE.md](REFERENCE.md) for measured live geometry and [PROVENANCE.md](PROVENANCE.md) for the extraction boundary.

The package also includes a standalone library of all 40 icons in the user's supplied `assets/shell-icons.jpg`. It uses the unchanged sheet as a sprite, so there is no generated reinterpretation or quality loss. Import `@mhoo/shell/icons.css` and `renderIcon`, `createIcon`, or `iconNames` from `@mhoo/shell/icons`. The shell itself uses this same library. The artwork is separate from Twenty's MIT theme; its redistribution rights have not been established, so keep the package private unless those rights are confirmed.

```js
import '@mhoo/shell/icons.css';
import { renderIcon, createIcon, iconNames } from '@mhoo/shell/icons';

const html = renderIcon('chat', { size: 48, label: 'Messages' });
document.querySelector('#toolbar').append(createIcon('calendar', { size: 32, label: 'Calendar' }));
console.log(iconNames); // all 40 canonical names; aliases include dashboard, finance, brand
```

Open `http://localhost:4178/icons` after `npm run preview` for the visual catalog. `renderIcon` defaults to decorative (`aria-hidden`) unless you provide a label; sizes from 8–256px are supported. The icon CSS and JPG travel together in the private package.

## Run and inspect

```sh
cd /path/to/mhoo-shell
npm run build
npm test
npm run preview
```

Open `http://localhost:4178`. The example mounts an Inbox-like app inside the shell, lets you switch between edge and framed content, and exercises header-action overflow plus the 40px collapsed and 220px expanded rail. Consumer header actions are hidden below 560px; keep the shell More action wired to an app-owned overflow menu. The example content is not a real WhatsApp client.

## Use the library

Install from this repository (`file:../mhoo-shell` for adjacent local projects) or a pinned Git revision. The package has no runtime dependencies. Import its external stylesheet once using your bundler, or serve `dist/shell.css` as a `<link>`:

```js
import '@mhoo/shell/styles.css';
import { createShell, hydrateShell, renderShell } from '@mhoo/shell';

const shell = createShell(document.querySelector('#root'), {
  workspace: 'My Workspace', title: 'Inbox', titleIcon: 'inbox',
  collapsed: true,
  contentMode: 'edge',
  activePath: '/inbox',
  navigation: [
    { label: 'Dashboards', href: '/dashboards', icon: 'dashboard' },
    { label: 'Inbox', href: '/inbox', icon: 'inbox', active: true },
  ],
});

// Mount React, Vue, a Web Component, or plain DOM here:
shell.appRoot.append(myAppElement);
shell.actionsRoot.append(myHeaderAction);

// Existing app DOM stays mounted while shell state changes:
shell.update({ title: 'Finance', theme: 'dark', collapsed: false, contentMode: 'framed', activePath: '/finance' });

// Optional: shell.setCollapsed(false); shell.destroy();
```

## Register applications

Worker-and-page applications can provide a small manifest instead of duplicating shell navigation:

```js
import { createAppRegistry, renderShell } from '@mhoo/shell';

const apps = createAppRegistry([
  { id: 'email', label: 'Email', route: '/inbox', icon: 'inbox', capabilities: ['mail.read'], webmcp: true },
  { id: 'content', label: 'Content', route: '/content', icon: 'chat', requiredRole: 'owner' },
], { role: 'owner' });

const html = renderShell({ apps, activePath: '/inbox/thread/example' });
```

The registry validates display and discovery metadata, filters an optional exact role, and builds navigation. It does not install or deploy a Worker, grant a service binding, or authorize any listed capability. The hosting Worker remains responsible for identity, routing, and service authorization.

An independently deployed application can expose a versioned discovery document at `/.well-known/mhoo-app.json`:

```js
import { createAppCatalog, createAppManifest, parseAppManifest } from '@mhoo/shell';

const manifest = createAppManifest([
  { id: 'email', label: 'Inbox', route: '/inbox', icon: 'inbox', capabilities: ['mail.read'], webmcp: true },
]);

// Worker response
return Response.json(manifest, { headers: { 'cache-control': 'public, max-age=300' } });

// Shell or registry boundary; raw may come from a service binding or HTTP response.
const discovered = parseAppManifest(raw);

// The host decides which validated manifests belong in this shell.
const contentManifest = createAppManifest([{ id: 'content', label: 'Content', route: '/content' }]);
const catalog = createAppCatalog([discovered, contentManifest], { role: 'owner' });
```

The v1 document contains only `{ schemaVersion: 1, apps: [...] }`. Parsing rejects unknown fields, unsupported versions, more than 64 entries, unsafe routes, and JSON strings larger than 65,536 characters. The normalized result is frozen. `createAppCatalog()` accepts only the manifests the host explicitly supplies, preserves their order, and rejects duplicate IDs or exact/parent-child route overlaps before applying an optional role filter. It does not fetch URLs, install apps, grant capabilities, or change authorization; those remain host responsibilities.

## Host-owned installation control plane

The `@mhoo/shell/host` export supplies the smallest host-side building blocks for the 1.0 app registry roadmap:

- `createD1InstallationStore(env.DB)` persists owner-approved source records, optimistic-concurrency versions, immutable approval evidence, enabled state, the last known valid manifest, and an explicit failure state. Its unique approval-idempotency table makes repeated or concurrent form submissions converge on one record; apply [migrations/0001_host_installations.sql](migrations/0001_host_installations.sql) in the host Worker’s own D1 database; [host-migration.sql](host-migration.sql) is the portable copy.
- `createInstallationLedger({ store, fixtures })` validates source approvals, refreshes manifests through an exact configured service binding path, keeps stale valid manifests when a refresh fails, filters the enabled catalog, and routes only to the binding selected by the approved record.
- `renderAppsSettings()` and `createAppHostHandler()` provide the plain owner-only Apps settings surface for inspecting, approving, refreshing, enabling/disabling, and removing sources. Approval forms carry a server-rendered idempotency key, and settings writes require same-origin browser evidence. The handler expects an `actorForRequest` callback backed by the host’s verified identity system; browser form fields never establish owner authority.
- `createWebMcpDirectory()` derives descriptive, read-only directory entries from enabled `webmcp: true` apps. Capability consent records are deliberately marked `descriptiveOnly` and `authorizationBoundary: 'app-owned'`; they never grant an app permission or replace the app’s own authorization checks.

Service sources accept only an uppercase Worker binding name and the fixed `/.well-known/mhoo-app.json` manifest path. Route forwarding derives its target path from the incoming request and calls that approved binding directly. It has no URL parameter, host parameter, arbitrary `fetch()`, or open-proxy mode. Local fixture sources are available for tests and the Email Hub proof; they are not live discovery.

The first example is [fixtures/email-hub.js](fixtures/email-hub.js), an explicit local copy of the manifest served by `mhoo-email-hub/src/shell-apps.ts`. It is intentionally not fetched or edited by this repository. Run `npm run test` for the unit, type, package, and local end-to-end proof. The proof covers installation, refresh, enablement, catalog/navigation, service-binding route resolution, owner settings, stale fallback, optimistic concurrency, route conflicts, capability boundaries, and WebMCP discovery.

For a real host Worker, keep the binding and identity configuration in that Worker:

```jsonc
{
  "d1_databases": [{
    "binding": "DB",
    "database_name": "mhoo-shell",
    "database_id": "<host-owned-d1-id>",
    "migrations_dir": "migrations"
  }],
  "services": [{
    "binding": "EMAIL_HUB",
    "service": "mhoo-email-hub"
  }]
}
```

```js
import { createAppHostHandler, createD1InstallationStore, createInstallationLedger } from '@mhoo/shell/host';

export default {
  async fetch(request, env, ctx) {
    const ledger = createInstallationLedger({ store: createD1InstallationStore(env.DB) });
    const handle = createAppHostHandler({
      ledger,
      actorForRequest: (request, env, ctx) => verifiedOwnerOrMember(request, env, ctx),
    });
    return handle(request, env, ctx);
  },
};
```

Cloudflare service bindings are explicit Worker-to-Worker bindings, not public URLs. The host must deploy and configure its own Worker resources separately; this package does not create bindings, D1 databases, Access policies, DNS, or production state.

Controls expose both callbacks and bubbling DOM events. Pass `onSearch`, `onHome`, `onChat`, `onMore`, `onWorkspace`, `onNavigate`, or the catch-all `onAction`. Corresponding events use the `mhoo:<action>` names. Navigation callbacks receive `{ item, path }`; disclosure callbacks also include `expanded`. Server-rendered markup carries an escaped JSON snapshot of each navigation item so `hydrateShell(host)` and the browser-ready client source emit the same payload without requiring the navigation array a second time. Call `shell.update(patch)` to change workspace, title, title icon, theme, navigation, search visibility, app label, callbacks, content mode, active navigation path, or collapsed state without replacing `appRoot` or `actionsRoot`. Pass a stable `id` when server-rendering if the identifier must be deterministic across processes.

`renderShell(options)` returns only the shell HTML fragment for server rendering. It contains no inline CSS or script. On the client, `createShell(host, options)` mounts that fragment, wires desktop collapse/expand and mobile overlay/Escape behavior, and returns stable `railRoot`, `appRoot`, and `actionsRoot` elements. The app DOM remains mounted while the rail changes state. `activePath`, `setActivePath(path)`, and `update({ activePath })` let the consumer reflect its router state; the shell marks one safe matching target active and expands its ancestors without reading or changing browser history. The consumer owns navigation targets and the Search, Home, Chat, and More actions; these visual controls do not fake application behavior.

The left rail can also be a host-owned panel instead of navigation. Pass trusted `railContent` HTML to `renderShell` or `createShell`, or mount DOM into the stable `shell.railRoot` after creation. `railLabel` names the panel for assistive technology. Supplying `railContent` replaces the default quick controls and navigation; the Shell still owns the outer rail, collapse button, mobile drawer, and focus handling. Pass `railContent: ''` to omit the rail entirely: the app fills the available width and no rail toggle is shown. A later `shell.update({ railContent: html })` can add a context panel without replacing the app DOM. Custom rail content is hidden at the 40px collapsed desktop width and shown in the mobile drawer. The host owns links, buttons, data loading, and authorization in that content. Treat `railContent` like `content` and `headerActions`: escape untrusted data before building HTML.

The DOM boundary is a mount point, not a Shadow DOM or security sandbox. Child apps can render their own routes and layouts inside `appRoot`, but global CSS and JavaScript can still affect siblings. The host should scope app styles and isolate untrusted apps separately. A registered app does not gain access to another Worker's binding or data through this Shell DOM.

For a server-rendered app, pass trusted app-owned `content` and optional `headerActions` to `renderShell`, then call `hydrateShell(host)` in the browser. Workers and other server-only bundlers can import the browser-ready string from `@mhoo/shell/client-source`, serve it from a same-origin JavaScript endpoint, and include that endpoint with a deferred script tag. Hydration attaches rail behavior without replacing the app DOM; those two HTML slots are trusted and must not contain unsanitized user input.

## Supported public API

| Surface | Purpose |
| --- | --- |
| `renderShell(options)` | Produce a server-renderable shell fragment. |
| `createAppRegistry(apps, options)` | Validate manifests and filter apps for an optional role. |
| `createAppManifest(apps)` | Build an immutable v1 application discovery document. |
| `parseAppManifest(input)` | Validate untrusted JSON or object input at a discovery boundary. |
| `createAppCatalog(manifests, options)` | Combine explicitly supplied v1 manifests into one route-safe registry. |
| `appForPath(apps, activePath)` | Find the app owning an exact or descendant route. |
| `createShell(host, options)` | Mount and hydrate a new shell. |
| `hydrateShell(host, options)` | Bind behavior to existing SSR markup without replacing application slots. |
| `appRoot` / `actionsRoot` | Stable consumer-owned mount points. |
| `setCollapsed(value)` | Control the desktop rail state. |
| `setContentMode(mode)` | Switch between edge and framed application content. |
| `setActivePath(path)` | Reflect consumer router state without changing history. |
| `getApps()` / `getCurrentApp()` | Read visible registry metadata from a hydrated shell. |
| `update(patch)` | Update supported shell state and callbacks while preserving mounted slots. |
| `destroy()` | Remove listeners and clear the mounted shell. |
| `@mhoo/shell/host` | Host-owned installation ledger, route resolver, Apps settings, consent records, and WebMCP directory. |
| `@mhoo/shell/fixtures/email-hub` | Explicit local Email Hub manifest/service fixture for tests and proofs. |
| `@mhoo/shell/icons` | Render or create icons from the private Mhoo artwork sheet. |
| `@mhoo/shell/client-source` | Browser-ready hydration source for server-only consumers. |

See [CHANGELOG.md](CHANGELOG.md) for 0.6.0 compatibility notes. The package remains private and should be pinned to an exact Git revision until a separately authorized release process exists.

The older inline page renderer is **not** part of this repository. Existing Design Studio source still uses its local compatibility copy; migrate that consumer separately after its in-progress changes are safe to touch. This repository is the canonical source for new shell work.

### Design skill library experiment

The local workbench supports agent-driven design skill selection through HTTP, CLI and optional WebMCP. Jev batches applicability and ranking judgments, then progressively verifies a shortlist from 24 pinned skills; the agent reads only selected guidance. See [design-catalog/README.md](design-catalog/README.md).

### Cloudflare workbench

The Pages + Worker version and durable D1 evaluation inspector are documented in [examples/cloudflare-workbench/README.md](examples/cloudflare-workbench/README.md). Start with `npm run cloudflare:migrate:local`, then `npm run cloudflare:dev`. The older `npm run workbench:legacy` Node example retains only transient traces.
