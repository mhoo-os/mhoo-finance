/** A framework-neutral workspace shell. App DOM mounts inside the returned appRoot. */
import { hasIcon, renderIcon } from './icons.js';

let shellSequence = 0;
const hydratedShells = new WeakMap();
const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
const navigationPath = value => {
  const href = String(value ?? '').trim();
  return /^(?:https?:\/\/|\/(?!\/)|#|\.?\.\/)/i.test(href) ? href : undefined;
};
const appId = value => /^[a-z][a-z0-9-]{0,62}$/.test(String(value ?? '')) ? String(value) : undefined;
const safeHref = value => escape(navigationPath(value) || '#');
const safeId = value => {
  const id = String(value ?? '').trim().replace(/[^A-Za-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '');
  return id || `mhoo-shell-${++shellSequence}`;
};
const nextShellId = () => `mhoo-shell-${++shellSequence}`;
const normalizeContentMode = value => value === 'framed' ? 'framed' : 'edge';
const manifestKeys = new Set(['schemaVersion', 'apps']);
const appManifestKeys = new Set(['id', 'label', 'route', 'icon', 'requiredRole', 'capabilities', 'webmcp']);
const routeBoundary = route => route === '/' ? '/' : route.replace(/\/+$/, '');
const routesOverlap = (left, right) => {
  const first = routeBoundary(left);
  const second = routeBoundary(right);
  return first === second || first === '/' || second === '/' || first.startsWith(`${second}/`) || second.startsWith(`${first}/`);
};
const assertRouteOwnership = apps => {
  for (let index = 0; index < apps.length; index += 1) {
    for (let otherIndex = index + 1; otherIndex < apps.length; otherIndex += 1) {
      const app = apps[index];
      const other = apps[otherIndex];
      if (routesOverlap(app.route, other.route)) {
        throw new TypeError(`ambiguous route ownership: ${app.id} (${app.route}) conflicts with ${other.id} (${other.route})`);
      }
    }
  }
};

/** Validate application manifests and return the apps visible to the current role. */
export function createAppRegistry(apps = [], { role } = {}) {
  if (!Array.isArray(apps)) throw new TypeError('apps must be an array');
  const ids = new Set();
  const registered = apps.map((app, index) => {
    if (!app || typeof app !== 'object' || Array.isArray(app)) throw new TypeError(`apps[${index}] must be an object`);
    const id = appId(app.id);
    if (!id) throw new TypeError(`apps[${index}].id must start with a lowercase letter and contain only lowercase letters, numbers, or hyphens`);
    if (ids.has(id)) throw new TypeError(`duplicate app id: ${id}`);
    ids.add(id);
    const label = String(app.label ?? '').trim();
    if (!label) throw new TypeError(`apps[${index}].label is required`);
    const route = navigationPath(app.route);
    if (!route || !route.startsWith('/')) throw new TypeError(`apps[${index}].route must be a same-origin absolute path`);
    const capabilities = app.capabilities === undefined ? [] : app.capabilities;
    if (!Array.isArray(capabilities) || capabilities.some(value => typeof value !== 'string' || !value.trim())) throw new TypeError(`apps[${index}].capabilities must be an array of non-empty strings`);
    if (app.requiredRole !== undefined && (typeof app.requiredRole !== 'string' || !app.requiredRole.trim())) throw new TypeError(`apps[${index}].requiredRole must be a non-empty string`);
    return Object.freeze({
      id, label, route, icon: String(app.icon || 'folder'),
      capabilities: Object.freeze([...new Set(capabilities.map(value => value.trim()))]),
      webmcp: app.webmcp === true,
      ...(app.requiredRole ? { requiredRole: app.requiredRole.trim() } : {}),
    });
  });
  return registered.filter(app => role === undefined || app.requiredRole === undefined || app.requiredRole === role);
}

/** Build the versioned discovery document exposed by an application Worker. */
export function createAppManifest(apps = []) {
  if (!Array.isArray(apps) || apps.length > 64) throw new TypeError('manifest apps must be an array with at most 64 entries');
  return Object.freeze({ schemaVersion: 1, apps: Object.freeze(createAppRegistry(apps)) });
}

/** Parse untrusted discovery JSON into an immutable, normalized manifest. */
export function parseAppManifest(input) {
  let value = input;
  if (typeof input === 'string') {
    if (input.length > 65_536) throw new TypeError('app manifest must not exceed 65536 characters');
    try { value = JSON.parse(input); }
    catch { throw new TypeError('app manifest must be valid JSON'); }
  }
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('app manifest must be an object');
  const unknownRootKey = Object.keys(value).find(key => !manifestKeys.has(key));
  if (unknownRootKey) throw new TypeError(`unknown app manifest field: ${unknownRootKey}`);
  if (value.schemaVersion !== 1) throw new TypeError('app manifest schemaVersion must be 1');
  if (!Array.isArray(value.apps) || value.apps.length > 64) throw new TypeError('manifest apps must be an array with at most 64 entries');
  value.apps.forEach((app, index) => {
    if (!app || typeof app !== 'object' || Array.isArray(app)) return;
    const unknownAppKey = Object.keys(app).find(key => !appManifestKeys.has(key));
    if (unknownAppKey) throw new TypeError(`unknown apps[${index}] field: ${unknownAppKey}`);
  });
  return createAppManifest(value.apps);
}

/** Combine only host-supplied, validated v1 manifests into one registry. */
export function createAppCatalog(manifests = [], { role } = {}) {
  if (!Array.isArray(manifests)) throw new TypeError('manifests must be an array');
  const apps = manifests.flatMap((manifest, index) => {
    try {
      return parseAppManifest(manifest).apps;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      throw new TypeError(`manifests[${index}] is invalid: ${message}`);
    }
  });
  const registered = createAppRegistry(apps);
  assertRouteOwnership(registered);
  return role === undefined ? registered : registered.filter(app => app.requiredRole === undefined || app.requiredRole === role);
}

export function appForPath(apps, activePath) {
  const target = navigationPath(activePath);
  if (!target) return undefined;
  return createAppRegistry(apps).find(app => target === app.route || target.startsWith(`${app.route.replace(/\/$/, '')}/`));
}

const appsToNavigation = apps => apps.map(app => ({ label: app.label, href: app.route, icon: app.icon, appId: app.id }));
const paths = {
  sidebar: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
  dashboard: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  chat: '<path d="M20 15a4 4 0 0 1-4 4H9l-5 3v-7a4 4 0 0 1-2-3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10H3z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
  more: '<circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
};
const icon = name => `<svg class="ms-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.folder}</svg>`;
const artwork = name => hasIcon(name) ? renderIcon(name) : icon(name);
const itemAtPath = (navigation, path) => path.split('.').reduce(
  (item, part, index) => index === 0 ? navigation[Number(part)] : item?.children?.[Number(part)],
  undefined,
);

const navigationItem = (item, path) => {
  const children = Array.isArray(item.children) ? item.children : [];
  const body = `<span class="ms-nav-icon">${artwork(item.icon || 'folder')}</span><span class="ms-nav-label">${escape(item.label)}</span>${children.length ? `<span class="ms-nav-chevron">${icon('chevron')}</span>` : ''}`;
  const current = item.active ? ' aria-current="page"' : '';
  const cls = `ms-nav-item${item.active ? ' is-active' : ''}`;
  if (children.length) {
    const expanded = item.expanded !== false;
    return `<button class="${cls}" type="button" data-shell-nav-toggle data-nav-path="${path}" data-nav-item="${escape(JSON.stringify(item))}" aria-label="${escape(item.label)}" aria-expanded="${expanded}"${current}>${body}</button><div class="ms-nav-children" data-nav-children="${path}"${expanded ? '' : ' hidden'}>${children.map((child, index) => navigationItem(child, `${path}.${index}`)).join('')}</div>`;
  }
  return item.href
    ? `<a class="${cls}" href="${safeHref(item.href)}" data-shell-navigate data-nav-path="${path}" data-nav-item="${escape(JSON.stringify(item))}" aria-label="${escape(item.label)}"${current}>${body}</a>`
    : `<button class="${cls}" type="button" data-shell-navigate data-nav-path="${path}" data-nav-item="${escape(JSON.stringify(item))}" aria-label="${escape(item.label)}"${current}>${body}</button>`;
};
const renderNavigation = navigation => navigation.map((item, index) => navigationItem(item, String(index))).join('');
const navigationWithActivePath = (navigation, activePath) => {
  if (activePath === undefined) return navigation;
  let matched = false;
  const visit = item => {
    const href = navigationPath(item.href);
    const target = navigationPath(activePath);
    const active = !matched && href !== undefined && target !== undefined && (target === href || (href !== '/' && target.startsWith(`${href.replace(/\/$/, '')}/`)));
    if (active) matched = true;
    const children = Array.isArray(item.children) ? item.children.map(visit) : undefined;
    const descendantActive = children?.some(child => child.active || child.__activeDescendant) || false;
    return { ...item, active, ...(children ? { children } : {}), ...(descendantActive ? { expanded: true, __activeDescendant: true } : {}), ...(active ? { __activeDescendant: true } : {}) };
  };
  const prepared = navigation.map(visit);
  const clean = item => {
    const { __activeDescendant, ...value } = item;
    if (Array.isArray(value.children)) value.children = value.children.map(clean);
    return value;
  };
  return prepared.map(clean);
};
const itemFromElement = element => {
  try { return JSON.parse(element?.dataset.navItem || 'null') ?? undefined; }
  catch { return undefined; }
};

/** Returns only shell markup. Include the exported stylesheet and client module separately. */
export function renderShell({ id, workspace = 'Workspace', title = 'Home', titleIcon = 'dashboard', navigation = [], apps, role, collapsed = false, appLabel = title, showSearch = true, railLabel = 'Workspace panel', railContent, theme = 'light', contentMode = 'edge', activePath, content = '', headerActions = '' } = {}) {
  if (!Array.isArray(navigation)) throw new TypeError('navigation must be an array');
  const registry = apps === undefined ? undefined : createAppRegistry(apps, { role });
  const shellNavigation = registry === undefined ? navigation : appsToNavigation(registry);
  const shellId = safeId(id || nextShellId());
  const railId = `${shellId}-rail`;
  const actionsId = `${shellId}-actions`;
  const railEnabled = railContent !== '';
  const defaultRail = `<div class="ms-quick"><button type="button" class="ms-quick-button" data-shell-action="search" aria-label="Search"${showSearch ? '' : ' hidden'}>${icon('search')}</button><span class="ms-quick-spacer"></span><button type="button" class="ms-quick-button" data-shell-action="home" aria-label="Home">${icon('dashboard')}</button><button type="button" class="ms-quick-button" data-shell-action="chat" aria-label="Chat">${icon('chat')}</button></div><div class="ms-nav-heading">Workspace</div><nav class="ms-nav" aria-label="Workspace pages">${renderNavigation(navigationWithActivePath(shellNavigation, activePath))}</nav>`;
  return `<div class="ms-shell ${theme === 'dark' ? 'dark' : 'light'}" data-mhoo-shell data-shell-id="${shellId}" data-collapsed="${collapsed ? 'true' : 'false'}" data-content-mode="${normalizeContentMode(contentMode)}" data-rail-enabled="${railEnabled}" data-rail-label="${escape(railLabel)}"><aside class="ms-rail" id="${railId}" aria-label="${escape(railLabel)}"${railEnabled ? '' : ' hidden'}><div class="ms-rail-head"><button class="ms-brand" type="button" data-shell-action="workspace" aria-label="Select workspace"${workspace ? '' : ' hidden'}>${artwork('brand')}<span class="ms-brand-name">${escape(workspace)}</span></button><button class="ms-rail-collapse" type="button" data-shell-collapse aria-label="Collapse panel"${railEnabled ? '' : ' hidden'}>${icon('sidebar')}</button></div><div class="ms-rail-body${railContent === undefined ? '' : ' is-custom'}" data-shell-rail>${railContent === undefined ? defaultRail : railContent}</div></aside><section class="ms-page"><header class="ms-header"><button type="button" class="ms-header-toggle" data-shell-toggle${railEnabled ? '' : ' hidden'} aria-label="${collapsed ? 'Expand' : 'Collapse'} panel" aria-expanded="${collapsed ? 'false' : 'true'}" aria-controls="${railId}">${icon('sidebar')}</button><div class="ms-header-title"${title ? '' : ' hidden'}><span data-shell-title-icon>${artwork(titleIcon)}</span><span data-shell-title>${escape(title)}</span></div><div class="ms-header-actions" data-shell-actions id="${actionsId}">${headerActions}</div><button type="button" class="ms-header-more" data-shell-action="more" aria-label="More options" aria-haspopup="dialog" aria-expanded="false" aria-controls="${actionsId}">${icon('more')}</button></header><div class="ms-stage"><div class="ms-app-frame"><main class="ms-app-root" data-shell-app aria-label="${escape(appLabel)}">${content}</main></div></div></section><button type="button" class="ms-scrim" data-shell-scrim aria-label="Close panel"></button></div>`;
}

/** Mounts the shell into a host element and returns stable slots for any app framework. */
export function createShell(host, options = {}) {
  if (!(host instanceof Element)) throw new TypeError('host must be a DOM element');
  hydratedShells.get(host)?.dispose();
  const state = { ...options, id: options.id || nextShellId() };
  host.innerHTML = renderShell(state);
  return hydrateShell(host, state);
}

/** Bind behavior to an existing server-rendered shell without replacing its app DOM. */
export function hydrateShell(host, options = {}) {
  if (!(host instanceof Element)) throw new TypeError('host must be a DOM element');
  const existing = hydratedShells.get(host);
  if (existing) {
    if (host.contains(existing.shell)) return existing.api;
    existing.dispose();
  }
  const shell = host.querySelector('[data-mhoo-shell]');
  if (!shell) throw new TypeError('host must contain rendered shell markup');
  let appSource = options.apps || [];
  const registry = options.apps === undefined ? [] : createAppRegistry(appSource, { role: options.role });
  const state = { ...options, apps: registry, navigation: options.apps === undefined ? (options.navigation || []) : appsToNavigation(registry) };
  const toggle = host.querySelector('[data-shell-toggle]');
  const rail = host.querySelector('.ms-rail');
  const railRoot = host.querySelector('[data-shell-rail]');
  const page = host.querySelector('.ms-page');
  const moreButton = host.querySelector('[data-shell-action="more"]');
  const actionsRoot = host.querySelector('[data-shell-actions]');
  const mobile = matchMedia('(max-width: 768px)');
  const compactHeader = matchMedia('(max-width: 560px)');
  const focusableSelector = 'button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]';
  const focusableElements = container => [...container.querySelectorAll(focusableSelector)].filter(element => {
    const tabIndex = element.getAttribute('tabindex');
    return !(tabIndex !== null && Number(tabIndex) < 0) && !element.closest('[hidden],[aria-hidden="true"]');
  });
  const focusFirst = container => focusableElements(container)[0]?.focus();
  const emit = (name, detail, event) => {
    const callback = state[`on${name[0].toUpperCase()}${name.slice(1)}`];
    callback?.(detail, event);
    state.onAction?.({ action: name, ...detail }, event);
    host.dispatchEvent(new CustomEvent(`mhoo:${name}`, { detail, bubbles: true }));
  };
  const syncToggle = () => {
    const railEnabled = shell.dataset.railEnabled === 'true';
    const expanded = mobile.matches ? shell.classList.contains('ms-mobile-open') : shell.dataset.collapsed !== 'true';
    const collapseButton = host.querySelector('[data-shell-collapse]');
    collapseButton.hidden = !railEnabled;
    collapseButton.setAttribute('aria-label', mobile.matches ? 'Close panel' : `${expanded ? 'Collapse' : 'Expand'} panel`);
    toggle.hidden = !railEnabled || !mobile.matches;
    toggle.setAttribute('aria-expanded', String(expanded));
    toggle.setAttribute('aria-label', mobile.matches ? `${expanded ? 'Close' : 'Open'} panel` : `${expanded ? 'Collapse' : 'Expand'} panel`);
  };
  const setCollapsed = collapsed => { shell.dataset.collapsed = String(Boolean(collapsed)); syncToggle(); };
  const setActionsOpen = (open, { restoreFocus = false } = {}) => {
    const expanded = Boolean(open) && compactHeader.matches && Boolean(actionsRoot.children.length);
    shell.dataset.actionsOpen = String(expanded);
    moreButton.setAttribute('aria-expanded', String(expanded));
    if (compactHeader.matches) { actionsRoot.setAttribute('role', 'dialog'); actionsRoot.setAttribute('aria-label', 'Header actions'); }
    else { actionsRoot.removeAttribute('role'); actionsRoot.removeAttribute('aria-label'); }
    if (expanded) focusFirst(actionsRoot);
    else if (restoreFocus) moreButton.focus();
  };
  const syncActions = () => setActionsOpen(shell.dataset.actionsOpen === 'true');
  const setMobileOpen = (open, { restoreFocus = false } = {}) => {
    const expanded = Boolean(open) && mobile.matches && shell.dataset.railEnabled === 'true';
    if (expanded && shell.dataset.actionsOpen === 'true') setActionsOpen(false);
    shell.classList.toggle('ms-mobile-open', expanded);
    page.inert = expanded;
    if (expanded) {
      page.setAttribute('aria-hidden', 'true');
      rail.setAttribute('role', 'dialog');
      rail.setAttribute('aria-modal', 'true');
      rail.setAttribute('aria-label', shell.dataset.railLabel || 'Workspace panel');
      focusFirst(rail);
    } else {
      page.removeAttribute('aria-hidden');
      rail.removeAttribute('role');
      rail.removeAttribute('aria-modal');
      if (restoreFocus) toggle.focus();
    }
    syncToggle();
  };
  const closeMobile = (restoreFocus = false) => setMobileOpen(false, { restoreFocus });
  const syncMobile = () => {
    if (!mobile.matches) setMobileOpen(false);
    else syncToggle();
  };
  const setContentMode = contentMode => { shell.dataset.contentMode = normalizeContentMode(contentMode); };
  const setActivePath = activePath => {
    state.activePath = activePath;
    const nav = railRoot.querySelector('.ms-nav');
    if (state.navigation.length && nav) {
      nav.innerHTML = renderNavigation(navigationWithActivePath(state.navigation, activePath));
      return;
    }
    const target = navigationPath(activePath);
    let matched = false;
    for (const element of railRoot.querySelectorAll('[data-shell-navigate],[data-shell-nav-toggle]')) {
      const item = itemFromElement(element);
      const active = !matched && target !== undefined && navigationPath(item?.href) === target;
      element.classList.toggle('is-active', active);
      if (active) {
        matched = true;
        element.setAttribute('aria-current', 'page');
        let children = element.closest('.ms-nav-children');
        while (children) {
          children.hidden = false;
          host.querySelector(`[data-shell-nav-toggle][data-nav-path="${children.dataset.navChildren}"]`)?.setAttribute('aria-expanded', 'true');
          children = children.parentElement?.closest('.ms-nav-children');
        }
      } else element.removeAttribute('aria-current');
    }
  };
  const onClick = event => {
    const action = event.target.closest('[data-shell-action]');
    if (action && (rail.contains(action) || actionsRoot.contains(action) || action === moreButton)) {
      emit(action.dataset.shellAction, {}, event);
      if (action === moreButton && compactHeader.matches) setActionsOpen(shell.dataset.actionsOpen !== 'true');
      else if (actionsRoot.contains(action)) setActionsOpen(false);
    }
    if (compactHeader.matches && actionsRoot.contains(event.target) && event.target.closest('button,a,[role="button"]')) setActionsOpen(false);
    const disclosure = event.target.closest('[data-shell-nav-toggle]');
    if (disclosure && railRoot.contains(disclosure)) {
      const expanded = disclosure.getAttribute('aria-expanded') !== 'true';
      disclosure.setAttribute('aria-expanded', String(expanded));
      host.querySelector(`[data-nav-children="${disclosure.dataset.navPath}"]`).hidden = !expanded;
      emit('navigate', { item: itemAtPath(state.navigation, disclosure.dataset.navPath) || itemFromElement(disclosure), path: disclosure.dataset.navPath, expanded }, event);
    }
    const navigation = event.target.closest('[data-shell-navigate]');
    if (navigation && railRoot.contains(navigation)) emit('navigate', { item: itemAtPath(state.navigation, navigation.dataset.navPath) || itemFromElement(navigation), path: navigation.dataset.navPath }, event);
  };
  toggle.addEventListener('click', () => {
    if (mobile.matches) setMobileOpen(!shell.classList.contains('ms-mobile-open'));
    else setCollapsed(shell.dataset.collapsed !== 'true');
  });
  host.querySelector('[data-shell-collapse]').addEventListener('click', () => {
    if (mobile.matches) closeMobile(true);
    else setCollapsed(shell.dataset.collapsed !== 'true');
  });
  host.querySelector('[data-shell-scrim]').addEventListener('click', () => closeMobile(true));
  host.addEventListener('click', onClick);
  const onDocumentClick = event => {
    if (shell.dataset.actionsOpen === 'true' && !actionsRoot.contains(event.target) && !moreButton.contains(event.target)) setActionsOpen(false);
  };
  const trapFocus = (event, container) => {
    const focusable = focusableElements(container);
    if (!focusable.length) { event.preventDefault(); return; }
    const first = focusable[0];
    const last = focusable.at(-1);
    const active = document.activeElement;
    if (event.shiftKey && (active === first || !container.contains(active))) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && (active === last || !container.contains(active))) { event.preventDefault(); first.focus(); }
  };
  const onKey = event => {
    if (event.key === 'Tab') {
      if (shell.dataset.actionsOpen === 'true') trapFocus(event, actionsRoot);
      else if (shell.classList.contains('ms-mobile-open')) trapFocus(event, rail);
      return;
    }
    if (event.key !== 'Escape') return;
    if (shell.dataset.actionsOpen === 'true') setActionsOpen(false, { restoreFocus: true });
    else if (shell.classList.contains('ms-mobile-open')) closeMobile(true);
  };
  document.addEventListener('click', onDocumentClick);
  document.addEventListener('keydown', onKey);
  mobile.addEventListener('change', syncMobile);
  compactHeader.addEventListener('change', syncActions);
  setCollapsed(options.collapsed === undefined ? shell.dataset.collapsed === 'true' : Boolean(options.collapsed));
  syncMobile();
  setContentMode(options.contentMode === undefined ? shell.dataset.contentMode : options.contentMode);
  syncActions();
  if (options.activePath !== undefined) setActivePath(options.activePath);
  const appRoot = host.querySelector('[data-shell-app]');
  const update = patch => {
    if ('navigation' in patch && !Array.isArray(patch.navigation)) throw new TypeError('navigation must be an array');
    if ('apps' in patch || 'role' in patch) {
      if ('apps' in patch) appSource = patch.apps;
      const nextRole = 'role' in patch ? patch.role : state.role;
      const nextRegistry = createAppRegistry(appSource, { role: nextRole });
      patch = { ...patch, apps: nextRegistry, navigation: appsToNavigation(nextRegistry) };
    }
    Object.assign(state, patch);
    if ('workspace' in patch) { host.querySelector('.ms-brand-name').textContent = String(patch.workspace); host.querySelector('.ms-brand').hidden = !patch.workspace; }
    if ('title' in patch) { host.querySelector('[data-shell-title]').textContent = String(patch.title); host.querySelector('.ms-header-title').hidden = !patch.title; }
    if ('titleIcon' in patch) host.querySelector('[data-shell-title-icon]').innerHTML = artwork(patch.titleIcon);
    if ('theme' in patch) { shell.classList.toggle('dark', patch.theme === 'dark'); shell.classList.toggle('light', patch.theme !== 'dark'); }
    if ('showSearch' in patch) railRoot.querySelector('[data-shell-action="search"]')?.toggleAttribute('hidden', !patch.showSearch);
    if ('railLabel' in patch) { shell.dataset.railLabel = String(patch.railLabel); rail.setAttribute('aria-label', String(patch.railLabel)); }
    if ('railContent' in patch) {
      railRoot.innerHTML = patch.railContent;
      railRoot.classList.add('is-custom');
      shell.dataset.railEnabled = String(patch.railContent !== '');
      rail.hidden = patch.railContent === '';
      if (rail.hidden) closeMobile();
      syncToggle();
    }
    if ('appLabel' in patch) appRoot.setAttribute('aria-label', String(patch.appLabel));
    if ('contentMode' in patch) setContentMode(patch.contentMode);
    if ('navigation' in patch) {
      const nav = railRoot.querySelector('.ms-nav');
      if (nav) nav.innerHTML = renderNavigation(navigationWithActivePath(patch.navigation, state.activePath));
    }
    if ('activePath' in patch) setActivePath(patch.activePath);
    if ('collapsed' in patch) setCollapsed(patch.collapsed);
    return api;
  };
  const dispose = () => { document.removeEventListener('click', onDocumentClick); document.removeEventListener('keydown', onKey); mobile.removeEventListener('change', syncMobile); compactHeader.removeEventListener('change', syncActions); host.removeEventListener('click', onClick); page.inert = false; hydratedShells.delete(host); };
  const destroy = () => { dispose(); host.replaceChildren(); };
  const getApps = () => state.apps.map(app => ({ ...app, capabilities: [...app.capabilities] }));
  const getCurrentApp = () => appForPath(state.apps, state.activePath);
  const api = { shell, railRoot, appRoot, actionsRoot, setCollapsed, setContentMode, setActivePath, getApps, getCurrentApp, update, destroy };
  hydratedShells.set(host, { shell, api, dispose });
  return api;
}
