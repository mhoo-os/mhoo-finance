declare const shellClientSource: string;
export default shellClientSource;
