# Source provenance and distribution boundary

- Extracted on 2026-09-14 from the committed `packages/twenty-shell/` tree on `mhooooo/design-studio` branch `codex/mhoo-twenty-shell`, source commit `690220b`.
- The former Design Studio-specific `legacy` inline renderer and `css-source.js` were intentionally excluded. This repository owns the composable shell, independent icon API, theme snapshots, tests, and previews.
- `vendor/twenty-ui/theme-light.css` and `theme-dark.css` are pinned from Twenty v2.37.0 at `6da524b8903ec16a3eeea4b2e4a5fb63dbfc1c58`, under the included MIT license. No AGPL Twenty Front runtime or JSX was copied.
- `assets/shell-icons.jpg` is the exact user-supplied contact sheet. Its rights are not established by the Twenty MIT license. Keep this GitHub repository and package private; do not publish the image or a package containing it publicly without confirming distribution rights.
- Design Studio currently has relative imports into its own old package copy and uncommitted consumer edits. That copy remains a compatibility bridge; it is not the canonical source and should be removed only in a separate, verified consumer migration.
