import type { MhooAppManifest } from '../component.js';

export declare const EMAIL_HUB_MANIFEST: MhooAppManifest;
export declare const EMAIL_HUB_SOURCE: {
  readonly type: 'fixture';
  readonly fixture: 'email-hub';
};
export declare const EMAIL_HUB_FIXTURE: {
  readonly manifest: MhooAppManifest;
  fetch(request: Request): Promise<Response>;
};
