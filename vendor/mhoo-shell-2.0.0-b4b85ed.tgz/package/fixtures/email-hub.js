import { createAppManifest } from '../component.js';

/**
 * Local copy of the currently served Email Hub discovery contract. Keep this
 * fixture explicit and review it alongside mhoo-email-hub/src/shell-apps.ts;
 * it is not a live fetch and it does not edit or deploy Email Hub.
 */
export const EMAIL_HUB_MANIFEST = createAppManifest([
  { id: 'owner', label: 'Owner', route: '/owner', icon: 'dashboard', capabilities: ['workspace.summary'], webmcp: true },
  { id: 'email', label: 'Inbox', route: '/inbox', icon: 'inbox', capabilities: ['mail.read', 'mail.draft'], webmcp: true },
  { id: 'campaigns', label: 'Campaigns', route: '/campaigns', icon: 'chat', capabilities: ['campaign.read', 'campaign.draft'] },
  { id: 'content', label: 'Content', route: '/content', icon: 'chat', capabilities: ['content.read', 'content.draft'], webmcp: true },
  { id: 'news', label: 'News', route: '/api/newsletter/manage', icon: 'inbox', capabilities: ['newsletter.manage'] },
]);

export const EMAIL_HUB_SOURCE = Object.freeze({
  type: 'fixture',
  fixture: 'email-hub',
});

/** A deterministic local service-like fixture used by the E2E proof. */
export const EMAIL_HUB_FIXTURE = Object.freeze({
  manifest: EMAIL_HUB_MANIFEST,
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/.well-known/mhoo-app.json') {
      return Response.json(EMAIL_HUB_MANIFEST, { headers: { 'cache-control': 'public, max-age=300' } });
    }
    const app = EMAIL_HUB_MANIFEST.apps.find(candidate => url.pathname === candidate.route || url.pathname.startsWith(`${candidate.route}/`));
    return app
      ? new Response(`Email Hub fixture route: ${url.pathname}`, { headers: { 'content-type': 'text/plain; charset=utf-8', 'x-mhoo-app': app.id } })
      : new Response('Email Hub fixture route not found', { status: 404 });
  },
});
