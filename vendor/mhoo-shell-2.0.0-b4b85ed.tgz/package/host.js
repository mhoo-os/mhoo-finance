import { appForPath, createAppCatalog, parseAppManifest } from './component.js';

export const APP_HOST_SCHEMA_VERSION = 1;
export const DEFAULT_MANIFEST_PATH = '/.well-known/mhoo-app.json';
export const MAX_MANIFEST_BYTES = 65_536;

const SOURCE_ID = /^[a-z][a-z0-9-]{0,62}$/;
const BINDING_NAME = /^[A-Z][A-Z0-9_]{0,62}$/;
const FIXTURE_KEY = /^[a-z][a-z0-9-]{0,62}$/;
const TABLE_NAME = /^[A-Za-z_][A-Za-z0-9_]{0,62}$/;

/** Base error for the host-side installation control plane. */
export class MhooHostError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'MhooHostError';
    this.code = code;
    Object.assign(this, details);
  }
}

/** Raised when a non-owner attempts to use an owner-only control-plane action. */
export class MhooAuthorizationError extends MhooHostError {
  constructor(message = 'owner authorization is required') {
    super('owner_required', message, { status: 403 });
    this.name = 'MhooAuthorizationError';
  }
}

/** Raised when a caller writes an old ledger version. */
export class MhooConflictError extends MhooHostError {
  constructor(message = 'installation ledger version conflict', current, code = 'version_conflict') {
    super(code, message, { status: 409, current });
    this.name = 'MhooConflictError';
  }
}

const clone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
const freeze = value => {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  Object.freeze(value);
  for (const child of Object.values(value)) freeze(child);
  return value;
};
const immutable = value => freeze(clone(value));
const now = () => new Date().toISOString();
const makeId = () => {
  if (typeof globalThis.crypto?.randomUUID !== 'function') throw new MhooHostError('crypto_unavailable', 'Web Crypto randomUUID is required');
  return globalThis.crypto.randomUUID();
};
const text = value => String(value ?? '').trim();
const boundedText = (value, max) => text(value).slice(0, max);
const safeErrorMessage = error => boundedText(error instanceof Error ? error.message : error, 240) || 'unknown host error';
const approvalPayload = ({ sourceId, label, source }) => JSON.stringify({ sourceId, label, source });
const approvalPayloadMatches = (evidence, record, payloadHash) => evidence?.payloadHash
  ? evidence.payloadHash === payloadHash
  : evidence?.label === record.label && JSON.stringify(evidence.source) === JSON.stringify(record.source);
const idempotencyConflict = (idempotencyKey, current) => new MhooConflictError(
  `approval idempotency key is already bound to a different payload: ${idempotencyKey}`,
  current,
  'idempotency_conflict',
);
const consentPayloadMatches = (canonical, requested) => canonical
  && canonical.consentKey === requested.consentKey
  && canonical.appId === requested.appId
  && canonical.capability === requested.capability
  && canonical.description === requested.description
  && canonical.descriptiveOnly === true
  && canonical.authorizationBoundary === 'app-owned';

function assertSourceId(value, field = 'sourceId') {
  const result = text(value);
  if (!SOURCE_ID.test(result)) throw new TypeError(`${field} must start with a lowercase letter and contain only lowercase letters, numbers, or hyphens`);
  return result;
}

function normalizeSource(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new TypeError('source must be an object');
  const type = text(input.type || (input.binding || input.bindingName ? 'service' : input.fixture || input.fixtureKey ? 'fixture' : ''));
  if (type === 'service') {
    const binding = text(input.binding || input.bindingName);
    if (!BINDING_NAME.test(binding)) throw new TypeError('service source binding must be a valid uppercase Worker binding name');
    const manifestPath = text(input.manifestPath || DEFAULT_MANIFEST_PATH);
    if (manifestPath !== DEFAULT_MANIFEST_PATH) throw new TypeError(`service source manifestPath must be ${DEFAULT_MANIFEST_PATH}`);
    return immutable({ type, binding, manifestPath });
  }
  if (type === 'fixture') {
    const fixture = text(input.fixture || input.fixtureKey);
    if (!FIXTURE_KEY.test(fixture)) throw new TypeError('fixture source fixture must be a valid lowercase fixture key');
    return immutable({ type, fixture });
  }
  throw new TypeError('source type must be service or fixture');
}

function normalizeLabel(value) {
  const label = boundedText(value, 120);
  if (!label) throw new TypeError('source label is required');
  return label;
}

function actorIdentity(actor) {
  if (!actor || actor.role !== 'owner') throw new MhooAuthorizationError();
  const id = text(actor.id || actor.email || actor.subject);
  if (!id) throw new MhooAuthorizationError('owner identity is required');
  return id;
}

function sourceRecord(record) {
  if (!record || typeof record !== 'object') throw new TypeError('installation record must be an object');
  return immutable(record);
}

function rowToRecord(row) {
  if (!row) return undefined;
  try {
    return sourceRecord({
      sourceId: String(row.source_id),
      label: String(row.label),
      source: JSON.parse(String(row.source_json)),
      enabled: Number(row.enabled) === 1,
      version: Number(row.version),
      approvalEvidence: JSON.parse(String(row.approval_evidence_json)),
      lastKnownValidManifest: row.last_manifest_json ? JSON.parse(String(row.last_manifest_json)) : null,
      lastKnownValidManifestHash: row.last_manifest_hash ? String(row.last_manifest_hash) : null,
      lastCheckedAt: row.last_checked_at ? String(row.last_checked_at) : null,
      failure: row.failure_json ? JSON.parse(String(row.failure_json)) : null,
    });
  } catch (error) {
    throw new MhooHostError('ledger_corrupt', `installation ledger record is invalid: ${safeErrorMessage(error)}`);
  }
}

function recordToColumns(record) {
  return [
    record.sourceId,
    record.label,
    JSON.stringify(record.source),
    record.enabled ? 1 : 0,
    record.version,
    JSON.stringify(record.approvalEvidence),
    record.lastKnownValidManifest ? JSON.stringify(record.lastKnownValidManifest) : null,
    record.lastKnownValidManifestHash,
    record.lastCheckedAt,
    record.failure ? JSON.stringify(record.failure) : null,
  ];
}

function assertTableName(value) {
  const name = text(value);
  if (!TABLE_NAME.test(name)) throw new TypeError('D1 table name is invalid');
  return name;
}

/**
 * A small in-memory implementation of the host storage contract for local
 * proofs and tests. Production hosts should use createD1InstallationStore.
 */
export function createMemoryInstallationStore(initialInstallations = [], initialConsents = []) {
  const installations = new Map(initialInstallations.map(record => [record.sourceId, clone(record)]));
  const consents = new Map(initialConsents.map(record => [record.consentKey, clone(record)]));
  const approvalClaims = new Map();
  for (const record of installations.values()) {
    for (const evidence of record.approvalEvidence || []) {
      if (evidence.idempotencyKey) approvalClaims.set(evidence.idempotencyKey, {
        sourceId: record.sourceId,
        payloadHash: evidence.payloadHash,
        evidenceId: evidence.evidenceId,
      });
    }
  }
  return {
    async listInstallations() {
      return [...installations.values()].map(clone);
    },
    async getInstallation(sourceId) {
      return clone(installations.get(sourceId));
    },
    async insertInstallation(record) {
      if (installations.has(record.sourceId)) throw new MhooConflictError(`source already exists: ${record.sourceId}`, clone(installations.get(record.sourceId)));
      installations.set(record.sourceId, clone(record));
      return clone(record);
    },
    approveInstallation(record, { idempotencyKey, payloadHash, evidenceId, expectedVersion } = {}) {
      if (idempotencyKey) {
        let claim = approvalClaims.get(idempotencyKey);
        if (!claim) {
          for (const current of installations.values()) {
            const evidence = (current.approvalEvidence || []).find(item => item.idempotencyKey === idempotencyKey);
            if (evidence) {
              claim = { sourceId: current.sourceId, payloadHash: evidence.payloadHash, evidenceId: evidence.evidenceId };
              approvalClaims.set(idempotencyKey, claim);
              break;
            }
          }
        }
        if (claim) {
          const canonical = installations.get(claim.sourceId);
          const evidence = canonical?.approvalEvidence?.find(item => item.evidenceId === claim.evidenceId || item.idempotencyKey === idempotencyKey);
          if (claim.sourceId !== record.sourceId || (claim.payloadHash && claim.payloadHash !== payloadHash) || !canonical || !approvalPayloadMatches(evidence, record, payloadHash)) {
            throw idempotencyConflict(idempotencyKey, clone(canonical));
          }
          if (!claim.payloadHash) claim.payloadHash = payloadHash;
          return clone(canonical);
        }
      }

      const current = installations.get(record.sourceId);
      if (expectedVersion === undefined) {
        if (current) throw new MhooConflictError(`source already exists: ${record.sourceId}`, clone(current));
      } else if (!current || current.version !== expectedVersion) {
        throw new MhooConflictError(undefined, clone(current));
      }
      installations.set(record.sourceId, clone(record));
      if (idempotencyKey) approvalClaims.set(idempotencyKey, { sourceId: record.sourceId, payloadHash, evidenceId });
      return clone(record);
    },
    async updateInstallation(record, expectedVersion) {
      const current = installations.get(record.sourceId);
      if (!current || current.version !== expectedVersion) throw new MhooConflictError(undefined, clone(current));
      installations.set(record.sourceId, clone(record));
      return clone(record);
    },
    async removeInstallation(sourceId, expectedVersion) {
      const current = installations.get(sourceId);
      if (!current) return null;
      if (current.version !== expectedVersion) throw new MhooConflictError(undefined, clone(current));
      installations.delete(sourceId);
      return clone(current);
    },
    async listCapabilityConsents() {
      return [...consents.values()].map(clone);
    },
    async getCapabilityConsent(consentKey) {
      return clone(consents.get(consentKey));
    },
    async insertCapabilityConsent(record) {
      if (consents.has(record.consentKey)) throw new MhooConflictError(`capability consent already exists: ${record.consentKey}`, clone(consents.get(record.consentKey)));
      consents.set(record.consentKey, clone(record));
      return clone(record);
    },
  };
}

/**
 * Adapt a Cloudflare D1 binding to the installation storage contract.
 * The SQL migration is shipped as host-migration.sql; no live binding is
 * created or changed by this package.
 */
export function createD1InstallationStore(db, { installationTable = 'mhoo_shell_installations', consentTable = 'mhoo_shell_capability_consents', approvalTable = 'mhoo_shell_approval_idempotency' } = {}) {
  if (!db || typeof db.prepare !== 'function' || typeof db.batch !== 'function') throw new TypeError('db must be a D1Database-like binding with batch support');
  const installations = assertTableName(installationTable);
  const consents = assertTableName(consentTable);
  const approvals = assertTableName(approvalTable);
  const readInstallation = async sourceId => {
    const row = await db.prepare(`SELECT source_id,label,source_json,enabled,version,approval_evidence_json,last_manifest_json,last_manifest_hash,last_checked_at,failure_json FROM ${installations} WHERE source_id=?`).bind(sourceId).first();
    return rowToRecord(row);
  };
  const readApprovalClaim = async idempotencyKey => {
    const row = await db.prepare(`SELECT idempotency_key,source_id,payload_hash,evidence_id FROM ${approvals} WHERE idempotency_key=?`).bind(idempotencyKey).first();
    if (!row) return undefined;
    return {
      idempotencyKey: String(row.idempotency_key),
      sourceId: String(row.source_id),
      payloadHash: String(row.payload_hash),
      evidenceId: String(row.evidence_id),
    };
  };
  const resolveApprovalClaim = async (claim, record) => {
    const canonical = await readInstallation(claim.sourceId);
    const evidence = canonical?.approvalEvidence?.find(item => item.evidenceId === claim.evidenceId || item.idempotencyKey === claim.idempotencyKey);
    if (!canonical || claim.sourceId !== record.sourceId || claim.payloadHash !== record.approvalEvidence.at(-1)?.payloadHash || !approvalPayloadMatches(evidence, record, claim.payloadHash)) {
      throw idempotencyConflict(claim.idempotencyKey, canonical);
    }
    return canonical;
  };
  const updateStatement = (record, expectedVersion) => db.prepare(`UPDATE ${installations} SET label=?,source_json=?,enabled=?,version=?,approval_evidence_json=?,last_manifest_json=?,last_manifest_hash=?,last_checked_at=?,failure_json=? WHERE source_id=? AND version=?`).bind(
    record.label,
    JSON.stringify(record.source),
    record.enabled ? 1 : 0,
    record.version,
    JSON.stringify(record.approvalEvidence),
    record.lastKnownValidManifest ? JSON.stringify(record.lastKnownValidManifest) : null,
    record.lastKnownValidManifestHash,
    record.lastCheckedAt,
    record.failure ? JSON.stringify(record.failure) : null,
    record.sourceId,
    expectedVersion,
  );
  return {
    async listInstallations() {
      const result = await db.prepare(`SELECT source_id,label,source_json,enabled,version,approval_evidence_json,last_manifest_json,last_manifest_hash,last_checked_at,failure_json FROM ${installations} ORDER BY source_id`).all();
      return (result.results || []).map(rowToRecord);
    },
    async getInstallation(sourceId) {
      return readInstallation(sourceId);
    },
    async insertInstallation(record) {
      try {
        await db.prepare(`INSERT INTO ${installations} (source_id,label,source_json,enabled,version,approval_evidence_json,last_manifest_json,last_manifest_hash,last_checked_at,failure_json) VALUES (?,?,?,?,?,?,?,?,?,?)`).bind(...recordToColumns(record)).run();
      } catch (error) {
        const current = await readInstallation(record.sourceId);
        if (current) throw new MhooConflictError(`source already exists: ${record.sourceId}`, current);
        throw error;
      }
      return record;
    },
    async approveInstallation(record, { idempotencyKey, payloadHash, evidenceId, expectedVersion } = {}) {
      if (!idempotencyKey) {
        if (expectedVersion === undefined) return this.insertInstallation(record);
        return this.updateInstallation(record, expectedVersion);
      }

      const current = await readInstallation(record.sourceId);
      const existingEvidence = current?.approvalEvidence?.find(item => item.idempotencyKey === idempotencyKey);
      if (existingEvidence) {
        if (!approvalPayloadMatches(existingEvidence, record, payloadHash)) throw idempotencyConflict(idempotencyKey, current);
        return current;
      }

      const existingClaim = await readApprovalClaim(idempotencyKey);
      if (existingClaim) return resolveApprovalClaim(existingClaim, record);

      const claim = db.prepare(`INSERT INTO ${approvals} (idempotency_key,source_id,payload_hash,evidence_id) VALUES (?,?,?,?)`).bind(
        idempotencyKey,
        record.sourceId,
        payloadHash,
        evidenceId,
      );
      try {
        if (expectedVersion === undefined) {
          await db.batch([
            claim,
            db.prepare(`INSERT INTO ${installations} (source_id,label,source_json,enabled,version,approval_evidence_json,last_manifest_json,last_manifest_hash,last_checked_at,failure_json) VALUES (?,?,?,?,?,?,?,?,?,?)`).bind(...recordToColumns(record)),
          ]);
          return record;
        }

        const results = await db.batch([
          claim,
          updateStatement(record, expectedVersion),
          // The claim and the update commit together. If an optimistic writer
          // won first, remove this batch's claim before the transaction ends.
          db.prepare(`DELETE FROM ${approvals} WHERE idempotency_key=? AND changes()=0`).bind(idempotencyKey),
        ]);
        if (!results[1]?.meta?.changes) throw new MhooConflictError(undefined, await readInstallation(record.sourceId));
        return record;
      } catch (error) {
        const canonicalClaim = await readApprovalClaim(idempotencyKey);
        if (canonicalClaim) return resolveApprovalClaim(canonicalClaim, record);
        if (error instanceof MhooConflictError) throw error;
        const after = await readInstallation(record.sourceId);
        if (after && expectedVersion === undefined) throw new MhooConflictError(`source already exists: ${record.sourceId}`, after);
        throw error;
      }
    },
    async updateInstallation(record, expectedVersion) {
      const result = await updateStatement(record, expectedVersion).run();
      if (!result.meta?.changes) throw new MhooConflictError(undefined, await readInstallation(record.sourceId));
      return record;
    },
    async removeInstallation(sourceId, expectedVersion) {
      const current = await readInstallation(sourceId);
      if (!current) return null;
      const result = await db.prepare(`DELETE FROM ${installations} WHERE source_id=? AND version=?`).bind(sourceId, expectedVersion).run();
      if (!result.meta?.changes) throw new MhooConflictError(undefined, await readInstallation(sourceId));
      return current;
    },
    async listCapabilityConsents() {
      const result = await db.prepare(`SELECT consent_id,consent_key,app_id,capability,description,consented_by,consented_at,descriptive_only,authorization_boundary FROM ${consents} ORDER BY consented_at,consent_id`).all();
      return (result.results || []).map(row => immutable({
        consentId: String(row.consent_id),
        consentKey: String(row.consent_key),
        appId: String(row.app_id),
        capability: String(row.capability),
        description: String(row.description),
        consentedBy: String(row.consented_by),
        consentedAt: String(row.consented_at),
        descriptiveOnly: Number(row.descriptive_only) === 1,
        authorizationBoundary: String(row.authorization_boundary),
      }));
    },
    async getCapabilityConsent(consentKey) {
      const row = await db.prepare(`SELECT consent_id,consent_key,app_id,capability,description,consented_by,consented_at,descriptive_only,authorization_boundary FROM ${consents} WHERE consent_key=?`).bind(consentKey).first();
      if (!row) return undefined;
      return immutable({
        consentId: String(row.consent_id),
        consentKey: String(row.consent_key),
        appId: String(row.app_id),
        capability: String(row.capability),
        description: String(row.description),
        consentedBy: String(row.consented_by),
        consentedAt: String(row.consented_at),
        descriptiveOnly: Number(row.descriptive_only) === 1,
        authorizationBoundary: String(row.authorization_boundary),
      });
    },
    async insertCapabilityConsent(record) {
      try {
        await db.prepare(`INSERT INTO ${consents} (consent_id,consent_key,app_id,capability,description,consented_by,consented_at,descriptive_only,authorization_boundary) VALUES (?,?,?,?,?,?,?,?,?)`).bind(
          record.consentId,
          record.consentKey,
          record.appId,
          record.capability,
          record.description,
          record.consentedBy,
          record.consentedAt,
          record.descriptiveOnly ? 1 : 0,
          record.authorizationBoundary,
        ).run();
      } catch (error) {
        const current = await this.getCapabilityConsent(record.consentKey);
        if (current) throw new MhooConflictError(`capability consent already exists: ${record.consentKey}`, current);
        throw error;
      }
      return record;
    },
  };
}

async function readBoundedText(body, limit = MAX_MANIFEST_BYTES) {
  if (!body) return '';
  if (typeof body.getReader !== 'function') throw new MhooHostError('manifest_unreadable', 'manifest response body is not readable');
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let bytes = 0;
  let result = '';
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) {
        result += decoder.decode();
        return result;
      }
      bytes += chunk.value.byteLength;
      if (bytes > limit) {
        await reader.cancel();
        throw new MhooHostError('manifest_too_large', `manifest response exceeds ${limit} bytes`);
      }
      result += decoder.decode(chunk.value, { stream: true });
    }
  } catch (error) {
    try { await reader.cancel(); } catch { /* the stream is already closed */ }
    throw error;
  }
}

async function sha256(value) {
  if (!globalThis.crypto?.subtle) throw new MhooHostError('crypto_unavailable', 'Web Crypto subtle is required');
  const digest = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

function failureFor(error, timestamp) {
  const message = safeErrorMessage(error);
  const code = error?.code || (/(?:duplicate app id|ambiguous route ownership)/i.test(message) ? 'manifest_conflict' : error instanceof TypeError ? 'invalid_manifest' : 'manifest_unavailable');
  return immutable({ code, message, at: timestamp });
}

function activeEntries(records) {
  return records.filter(record => record.enabled && record.lastKnownValidManifest);
}

function fixtureValue(fixtures, key) {
  if (fixtures instanceof Map) return fixtures.get(key);
  return fixtures?.[key];
}

async function fixtureManifest(value, context) {
  const resolved = typeof value === 'function' ? await value(context) : value;
  if (resolved && typeof resolved === 'object' && 'manifest' in resolved) return resolved.manifest;
  return resolved;
}

function fixtureBinding(value) {
  return value && typeof value === 'object' && typeof value.fetch === 'function' ? value : value?.service;
}

async function loadManifest(source, { env, origin, fixtures, defaultOrigin }) {
  if (source.type === 'fixture') {
    const fixture = fixtureValue(fixtures, source.fixture);
    if (fixture === undefined) throw new MhooHostError('fixture_missing', `manifest fixture is not configured: ${source.fixture}`);
    return fixtureManifest(fixture, { env, origin: origin || defaultOrigin, source });
  }
  const binding = env?.[source.binding];
  if (!binding || typeof binding.fetch !== 'function') throw new MhooHostError('binding_missing', `configured service binding is unavailable: ${source.binding}`);
  const target = new URL(source.manifestPath, origin || defaultOrigin);
  const response = await binding.fetch(new Request(target, { method: 'GET', headers: { accept: 'application/json' } }));
  if (!response.ok) throw new MhooHostError('manifest_unavailable', `manifest binding returned HTTP ${response.status}`);
  return readBoundedText(response.body);
}

function catalogFromRecords(records, role) {
  return createAppCatalog(activeEntries(records).map(record => record.lastKnownValidManifest), { role });
}

/** Build a descriptive WebMCP directory from already-enabled catalog entries. */
export function createWebMcpDirectory(apps = []) {
  if (!Array.isArray(apps)) throw new TypeError('apps must be an array');
  const visible = apps.filter(app => app && app.webmcp === true);
  return immutable({
    schemaVersion: APP_HOST_SCHEMA_VERSION,
    apps: visible.map(app => ({
      id: app.id,
      label: app.label,
      route: app.route,
      capabilities: [...(app.capabilities || [])],
      tools: [{
        name: `mhoo_${app.id}_open`,
        title: `Open ${app.label}`,
        description: `Open the ${app.label} app at its configured Shell route. This directory entry is descriptive; the app remains responsible for authorization.`,
        inputSchema: { type: 'object', properties: {}, additionalProperties: false },
        annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false },
      }],
      authorizationBoundary: 'app-owned',
    })),
  });
}

/**
 * Create the host-owned installation ledger and its safe routing/catalog
 * operations. The caller supplies identity and Cloudflare bindings; this
 * module never invents authorization or fetches arbitrary URLs.
 */
export function createInstallationLedger({ store, fixtures = {}, clock = now, idFactory = makeId, defaultOrigin = 'https://mhoo.internal' } = {}) {
  if (!store || typeof store.getInstallation !== 'function' || typeof store.listInstallations !== 'function') throw new TypeError('store must implement the installation storage contract');

  const getRecord = async sourceId => {
    const normalized = assertSourceId(sourceId);
    const record = await store.getInstallation(normalized);
    return record ? sourceRecord(record) : undefined;
  };
  const updateRecord = async (current, next) => sourceRecord(await store.updateInstallation(sourceRecord(next), current.version));
  const owner = actor => actorIdentity(actor);

  const listInstallations = async actor => {
    owner(actor);
    return (await store.listInstallations()).map(sourceRecord);
  };

  const approveSource = async (input, actor) => {
    const approvedBy = owner(actor);
    if (!input || typeof input !== 'object') throw new TypeError('approval input must be an object');
    const sourceId = assertSourceId(input.sourceId);
    const source = normalizeSource(input.source || input);
    const label = normalizeLabel(input.label || sourceId);
    const idempotencyKey = text(input.idempotencyKey);
    const existing = await getRecord(sourceId);
    const payloadHash = await sha256(approvalPayload({ sourceId, label, source }));
    const timestamp = text(input.approvedAt) || clock();
    const evidence = immutable({
      evidenceId: idFactory(),
      ...(idempotencyKey ? { idempotencyKey } : {}),
      payloadHash,
      approvedBy,
      approvedAt: timestamp,
      source,
      label,
    });
    const next = sourceRecord({
      sourceId,
      label,
      source,
      enabled: existing?.enabled || false,
      version: existing?.version || 0,
      approvalEvidence: [...(existing?.approvalEvidence || []), evidence],
      lastKnownValidManifest: existing?.lastKnownValidManifest || null,
      lastKnownValidManifestHash: existing?.lastKnownValidManifestHash || null,
      lastCheckedAt: existing?.lastCheckedAt || null,
      failure: existing?.failure || null,
    });
    if (!store.approveInstallation) {
      if (!existing) return sourceRecord(await store.insertInstallation(next));
      return updateRecord(existing, { ...next, version: existing.version + 1 });
    }
    return sourceRecord(await store.approveInstallation(
      sourceRecord({ ...next, version: existing ? existing.version + 1 : 0 }),
      { idempotencyKey: idempotencyKey || undefined, payloadHash, evidenceId: evidence.evidenceId, expectedVersion: existing?.version },
    ));
  };

  const setEnabled = async (sourceId, actor, { enabled, expectedVersion } = {}) => {
    owner(actor);
    const current = await getRecord(sourceId);
    if (!current) throw new MhooHostError('source_missing', `installed source does not exist: ${sourceId}`, { status: 404 });
    const desired = Boolean(enabled);
    if (current.enabled === desired && (expectedVersion === undefined || current.version === expectedVersion)) return current;
    if (expectedVersion !== undefined && current.version !== expectedVersion) throw new MhooConflictError(undefined, current);
    return updateRecord(current, { ...current, enabled: desired, version: current.version + 1 });
  };

  const removeSource = async (sourceId, actor, { expectedVersion } = {}) => {
    owner(actor);
    const current = await getRecord(sourceId);
    if (!current) return null;
    if (expectedVersion !== undefined && current.version !== expectedVersion) throw new MhooConflictError(undefined, current);
    return store.removeInstallation(current.sourceId, current.version);
  };

  const refreshSource = async (sourceId, actor, context = {}) => {
    owner(actor);
    const current = await getRecord(sourceId);
    if (!current) throw new MhooHostError('source_missing', `installed source does not exist: ${sourceId}`, { status: 404 });
    const checkedAt = context.checkedAt || clock();
    try {
      const raw = await loadManifest(current.source, { ...context, fixtures, defaultOrigin });
      const manifest = parseAppManifest(raw);
      // A source with an ambiguous manifest is not allowed to become a valid
      // fallback. The last known valid manifest remains untouched on failure.
      createAppCatalog([manifest]);
      const manifestHash = await sha256(JSON.stringify(manifest));
      return updateRecord(current, {
        ...current,
        version: current.version + 1,
        lastKnownValidManifest: manifest,
        lastKnownValidManifestHash: manifestHash,
        lastCheckedAt: checkedAt,
        failure: null,
      });
    } catch (error) {
      return updateRecord(current, {
        ...current,
        version: current.version + 1,
        lastCheckedAt: checkedAt,
        failure: failureFor(error, checkedAt),
      });
    }
  };

  const getCatalog = async ({ role } = {}) => catalogFromRecords(await store.listInstallations(), role);
  const getWebMcpDirectory = async ({ role } = {}) => createWebMcpDirectory(await getCatalog({ role }));

  const recordCapabilityConsent = async (input, actor) => {
    const consentedBy = owner(actor);
    if (!input || typeof input !== 'object') throw new TypeError('capability consent input must be an object');
    const appId = assertSourceId(input.appId, 'appId');
    const capability = text(input.capability);
    const description = boundedText(input.description, 240);
    if (!capability || !description) throw new TypeError('capability and description are required');
    const consentKey = `${appId}:${capability}`;
    const consent = sourceRecord({
      consentId: idFactory(),
      consentKey,
      appId,
      capability,
      description,
      consentedBy,
      consentedAt: text(input.consentedAt) || clock(),
      descriptiveOnly: true,
      authorizationBoundary: 'app-owned',
    });
    try {
      return sourceRecord(await store.insertCapabilityConsent(consent));
    } catch (error) {
      const canonical = await store.getCapabilityConsent?.(consentKey);
      if (!canonical) throw error;
      if (!consentPayloadMatches(canonical, consent)) throw new MhooConflictError(`capability consent payload conflict: ${consentKey}`, sourceRecord(canonical), 'idempotency_conflict');
      return sourceRecord(canonical);
    }
  };

  const listCapabilityConsents = async actor => {
    owner(actor);
    return (await store.listCapabilityConsents()).map(sourceRecord);
  };

  const resolveAppRoute = async (request, actor, { env, role = actor?.role, origin = defaultOrigin } = {}) => {
    if (!request || typeof request.url !== 'string') throw new TypeError('request must be a Request-like object');
    if (!actor?.role) throw new MhooAuthorizationError('authenticated app identity is required');
    const records = await store.listInstallations();
    const catalog = catalogFromRecords(records, role);
    const requestUrl = new URL(request.url);
    const app = appForPath(catalog, requestUrl.pathname);
    if (!app) return null;
    const entry = activeEntries(records).find(record => record.lastKnownValidManifest.apps.some(candidate => candidate.id === app.id));
    if (!entry) return null;
    let binding;
    if (entry.source.type === 'service') binding = env?.[entry.source.binding];
    else binding = fixtureBinding(fixtureValue(fixtures, entry.source.fixture));
    if (!binding || typeof binding.fetch !== 'function') throw new MhooHostError('binding_missing', `route binding is unavailable for ${entry.source.type === 'service' ? entry.source.binding : entry.source.fixture}`, { status: 503 });
    // The target is derived only from the incoming path and the approved
    // source's binding. There is no URL, host, or binding selector in input.
    const target = new URL(`${requestUrl.pathname}${requestUrl.search}`, origin);
    return binding.fetch(new Request(target, request));
  };

  return {
    listInstallations,
    getInstallation: getRecord,
    approveSource,
    setEnabled,
    setSourceEnabled: setEnabled,
    removeSource,
    refreshSource,
    getCatalog,
    getWebMcpDirectory,
    recordCapabilityConsent,
    listCapabilityConsents,
    resolveAppRoute,
    routeInstalledApp: resolveAppRoute,
  };
}

const htmlEscape = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
const formatSource = source => source.type === 'service' ? `Service binding · ${source.binding}` : `Local fixture · ${source.fixture}`;
const formatStatus = record => {
  if (record.failure) return record.lastKnownValidManifest ? `Stale · ${record.failure.code}` : `Failed · ${record.failure.code}`;
  if (!record.lastKnownValidManifest) return 'Approved · refresh needed';
  return record.enabled ? 'Enabled' : 'Disabled';
};

export const APPS_SETTINGS_CSS = `.mhoo-app-settings{max-width:70rem;margin:0 auto;padding:clamp(1.5rem,5vw,4rem);font:14px/1.5 system-ui;color:#252525}.mhoo-app-settings h1{margin:0;font-size:clamp(2rem,5vw,4rem);font-weight:520;letter-spacing:-.06em}.mhoo-app-settings p{color:#666}.mhoo-app-settings__intro{max-width:42rem}.mhoo-app-settings__grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(18rem,1fr));gap:1rem;margin:2rem 0}.mhoo-app-settings__card{border:1px solid #dedede;border-radius:16px;padding:1rem;background:#fff}.mhoo-app-settings__card h2{margin:.1rem 0;font-size:1rem}.mhoo-app-settings__meta{color:#666;font-size:.85rem}.mhoo-app-settings__status{display:inline-flex;border:1px solid #cfcfcf;border-radius:999px;padding:.15rem .55rem;font-size:.75rem}.mhoo-app-settings__status[data-state="Enabled"]{border-color:#6c9b73;background:#eff8f0}.mhoo-app-settings__failure{color:#9b3e35}.mhoo-app-settings form{display:flex;flex-wrap:wrap;gap:.55rem;align-items:end}.mhoo-app-settings label{display:grid;gap:.2rem;min-width:10rem;flex:1}.mhoo-app-settings input,.mhoo-app-settings select,.mhoo-app-settings button{font:inherit;border:1px solid #aaa;border-radius:8px;padding:.55rem .7rem;background:#fff}.mhoo-app-settings button{cursor:pointer}.mhoo-app-settings button[data-danger]{color:#9b3e35}.mhoo-app-settings__source-form{display:grid;grid-template-columns:repeat(auto-fit,minmax(10rem,1fr));gap:.7rem;align-items:end}.mhoo-app-settings__source-form button{height:fit-content}.mhoo-app-settings__apps{padding-left:1.1rem}.mhoo-app-settings__apps li{margin:.2rem 0}.mhoo-app-settings__evidence{margin-top:.75rem;font-size:.78rem;color:#666}.mhoo-app-settings__actions{margin-top:1rem}.mhoo-app-settings__consent{margin-top:2rem;border-top:1px solid #ddd;padding-top:1rem}@media(max-width:600px){.mhoo-app-settings__source-form{grid-template-columns:1fr}}`;

/** Render the owner-only Apps settings surface. Host authentication remains the security boundary. */
export function renderAppsSettings({ role, installations = [], capabilityConsents = [], actionPath = '/settings/apps', approvalIdempotencyKey = makeId() } = {}) {
  if (role !== 'owner') throw new MhooAuthorizationError();
  const approvalKey = text(approvalIdempotencyKey) || makeId();
  const rows = installations.map(record => {
    const manifestApps = record.lastKnownValidManifest?.apps || [];
    const state = formatStatus(record);
    const latestEvidence = record.approvalEvidence.at(-1);
    return `<article class="mhoo-app-settings__card" data-source-id="${htmlEscape(record.sourceId)}" data-version="${record.version}"><h2>${htmlEscape(record.label)}</h2><p class="mhoo-app-settings__meta">${htmlEscape(record.sourceId)} · ${htmlEscape(formatSource(record.source))}</p><p><span class="mhoo-app-settings__status" data-state="${htmlEscape(state)}">${htmlEscape(state)}</span>${record.failure ? ` <span class="mhoo-app-settings__failure">${htmlEscape(record.failure.message)}</span>` : ''}</p>${manifestApps.length ? `<ul class="mhoo-app-settings__apps">${manifestApps.map(app => `<li><strong>${htmlEscape(app.label)}</strong> <code>${htmlEscape(app.route)}</code>${app.webmcp ? ' · WebMCP' : ''}</li>`).join('')}</ul>` : '<p>No valid manifest has been recorded yet.</p>'}<p class="mhoo-app-settings__evidence">${record.approvalEvidence.length} immutable approval record${record.approvalEvidence.length === 1 ? '' : 's'} · latest by ${htmlEscape(latestEvidence?.approvedBy)} on ${htmlEscape(latestEvidence?.approvedAt)}</p><div class="mhoo-app-settings__actions"><form method="post" action="${htmlEscape(actionPath)}"><input type="hidden" name="sourceId" value="${htmlEscape(record.sourceId)}"><input type="hidden" name="expectedVersion" value="${record.version}"><button name="intent" value="refresh">Refresh manifest</button><button name="intent" value="toggle">${record.enabled ? 'Disable' : 'Enable'}</button><button data-danger name="intent" value="remove">Remove</button></form></div></article>`;
  }).join('');
  const consents = capabilityConsents.length ? `<div class="mhoo-app-settings__consent"><h2>Capability descriptions</h2><p>These records describe owner consent only. Each app still authorizes its own actions.</p><ul>${capabilityConsents.map(consent => `<li><strong>${htmlEscape(consent.appId)} · ${htmlEscape(consent.capability)}</strong> — ${htmlEscape(consent.description)}</li>`).join('')}</ul></div>` : '';
  return `<section class="mhoo-app-settings" data-mhoo-apps-settings><header><p>PRIVATE WORKSPACE · OWNER SETTINGS</p><h1>Apps</h1><p class="mhoo-app-settings__intro">Approve the exact sources this host may discover and route to. Disabled or failed sources never become part of the active catalog; a stale valid manifest may remain visible while its failure is shown.</p></header><section class="mhoo-app-settings__card"><h2>Approve a source</h2><form class="mhoo-app-settings__source-form" method="post" action="${htmlEscape(actionPath)}"><input type="hidden" name="idempotencyKey" value="${htmlEscape(approvalKey)}"><label>Source ID<input name="sourceId" required pattern="[a-z][a-z0-9-]{0,62}" autocomplete="off"></label><label>Label<input name="label" required maxlength="120"></label><label>Type<select name="sourceType"><option value="service">Cloudflare service binding</option><option value="fixture">Local fixture</option></select></label><label>Binding<input name="binding" placeholder="EMAIL_HUB" pattern="[A-Z][A-Z0-9_]{0,62}"></label><label>Fixture key<input name="fixture" placeholder="email-hub" pattern="[a-z][a-z0-9-]{0,62}"></label><button name="intent" value="approve">Approve source</button></form></section><section class="mhoo-app-settings__grid">${rows || '<p>No approved sources yet.</p>'}</section>${consents}</section>`;
}

function jsonResponse(body, status = 200, headers = {}) {
  return new Response(JSON.stringify(body), { status, headers: { 'cache-control': 'no-store', 'content-type': 'application/json; charset=utf-8', ...headers } });
}

function sameOriginRequest(request) {
  const requestOrigin = new URL(request.url).origin;
  const origin = request.headers.get('origin');
  const referer = request.headers.get('referer');
  const fetchSite = text(request.headers.get('sec-fetch-site')).toLowerCase();
  const validFetchSite = !fetchSite || fetchSite === 'same-origin' || fetchSite === 'same-site' || fetchSite === 'none';
  if (!validFetchSite) return false;

  let hasEvidence = false;
  if (origin !== null) {
    hasEvidence = true;
    if (origin !== requestOrigin) return false;
  }
  if (referer !== null) {
    hasEvidence = true;
    try {
      if (new URL(referer).origin !== requestOrigin) return false;
    } catch {
      return false;
    }
  }
  return hasEvidence;
}

/**
 * Optional thin Worker handler for local proofs and host integration. The
 * actorForRequest callback must use the host's verified identity system; this
 * helper intentionally does not trust role fields from browser form data.
 */
export function createAppHostHandler({ ledger, actorForRequest, settingsPath = '/settings/apps', directoryPath = '/.well-known/mhoo-tools.json', origin = 'https://mhoo.internal', renderSettings = renderAppsSettings } = {}) {
  if (!ledger || typeof ledger.listInstallations !== 'function') throw new TypeError('ledger is required');
  if (typeof actorForRequest !== 'function') throw new TypeError('actorForRequest is required');
  return async function handle(request, env, ctx) {
    const url = new URL(request.url);
    try {
      const actor = await actorForRequest(request, env, ctx);
      if (url.pathname === settingsPath) {
        if (!actor || actor.role !== 'owner') throw new MhooAuthorizationError();
        if (request.method === 'GET') {
          const [installations, capabilityConsents] = await Promise.all([ledger.listInstallations(actor), ledger.listCapabilityConsents(actor)]);
          const body = renderSettings({ role: actor.role, installations, capabilityConsents, actionPath: settingsPath, approvalIdempotencyKey: makeId() });
          return new Response(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Apps · Mhoo</title><style>${APPS_SETTINGS_CSS}</style></head><body>${body}</body></html>`, { headers: { 'cache-control': 'no-store', 'content-type': 'text/html; charset=utf-8', 'x-content-type-options': 'nosniff' } });
        }
        if (request.method === 'POST') {
          if (!sameOriginRequest(request)) throw new MhooHostError('cross_origin', 'settings writes must be same-origin', { status: 403 });
          const form = await request.formData();
          const intent = text(form.get('intent'));
          const sourceId = text(form.get('sourceId'));
          const expectedVersionValue = text(form.get('expectedVersion'));
          const expectedVersion = expectedVersionValue ? Number(expectedVersionValue) : undefined;
          if (intent === 'approve') {
            const sourceType = text(form.get('sourceType'));
            const source = sourceType === 'fixture' ? { type: 'fixture', fixture: text(form.get('fixture')) } : { type: 'service', binding: text(form.get('binding')) };
            await ledger.approveSource({ sourceId, label: text(form.get('label')), source, idempotencyKey: text(form.get('idempotencyKey')) }, actor);
          } else if (intent === 'refresh') {
            await ledger.refreshSource(sourceId, actor, { env, origin });
          } else if (intent === 'toggle') {
            const current = await ledger.getInstallation(sourceId);
            if (!current) throw new MhooHostError('source_missing', `installed source does not exist: ${sourceId}`, { status: 404 });
            await ledger.setEnabled(sourceId, actor, { enabled: !current.enabled, expectedVersion });
          } else if (intent === 'remove') {
            await ledger.removeSource(sourceId, actor, { expectedVersion });
          } else {
            return jsonResponse({ error: 'unknown settings action' }, 400);
          }
          return new Response(null, { status: 303, headers: { location: settingsPath, 'cache-control': 'no-store' } });
        }
        return jsonResponse({ error: 'method not allowed' }, 405, { allow: 'GET, POST' });
      }
      if (url.pathname === directoryPath && request.method === 'GET') {
        if (!actor?.role) throw new MhooAuthorizationError('authenticated app identity is required');
        return jsonResponse(await ledger.getWebMcpDirectory({ role: actor.role }), 200, { 'cache-control': 'private, max-age=60' });
      }
      const routed = await ledger.resolveAppRoute(request, actor, { env, origin });
      return routed || new Response('Not found', { status: 404, headers: { 'cache-control': 'no-store' } });
    } catch (error) {
      if (error instanceof MhooHostError) return jsonResponse({ error: error.code, message: safeErrorMessage(error) }, error.status || (error.code === 'version_conflict' ? 409 : 400));
      console.error(JSON.stringify({ event: 'mhoo_shell.host_failed', message: safeErrorMessage(error) }));
      return jsonResponse({ error: 'host_unavailable', message: 'Host control plane unavailable.' }, 503);
    }
  };
}
