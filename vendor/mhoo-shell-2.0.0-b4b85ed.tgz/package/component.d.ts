export type ContentMode = 'edge' | 'framed';
export type ShellTheme = 'light' | 'dark';
export type ShellActionName = 'search' | 'home' | 'chat' | 'more' | 'workspace';

export interface NavigationItem {
  label: string;
  href?: string;
  icon?: string;
  active?: boolean;
  expanded?: boolean;
  children?: NavigationItem[];
  [key: string]: unknown;
}

export interface MhooApp {
  id: string;
  label: string;
  route: string;
  icon?: string;
  requiredRole?: string;
  capabilities?: readonly string[];
  webmcp?: boolean;
}

export interface RegisteredMhooApp {
  readonly id: string;
  readonly label: string;
  readonly route: string;
  readonly icon: string;
  readonly requiredRole?: string;
  readonly capabilities: readonly string[];
  readonly webmcp: boolean;
}

export interface MhooAppManifest {
  readonly schemaVersion: 1;
  readonly apps: readonly RegisteredMhooApp[];
}

export type MhooAppManifestInput = string | MhooAppManifest;

export interface NavigateDetail {
  item?: NavigationItem;
  path: string;
  expanded?: boolean;
}

export interface ShellActionDetail {
  action: ShellActionName | 'navigate';
  item?: NavigationItem;
  path?: string;
  expanded?: boolean;
}

export type ShellActionCallback = (detail: Record<string, never>, event: Event) => void;
export type NavigateCallback = (detail: NavigateDetail, event: Event) => void;
export type AnyActionCallback = (detail: ShellActionDetail, event: Event) => void;

export interface ShellOptions {
  id?: string;
  workspace?: string;
  title?: string;
  titleIcon?: string;
  navigation?: NavigationItem[];
  /** Trusted host HTML for the left panel. Replaces the default navigation template. */
  railContent?: string;
  railLabel?: string;
  apps?: readonly MhooApp[];
  role?: string;
  collapsed?: boolean;
  appLabel?: string;
  showSearch?: boolean;
  theme?: ShellTheme;
  contentMode?: ContentMode;
  activePath?: string | null;
  content?: string;
  headerActions?: string;
  onSearch?: ShellActionCallback;
  onHome?: ShellActionCallback;
  onChat?: ShellActionCallback;
  onMore?: ShellActionCallback;
  onWorkspace?: ShellActionCallback;
  onNavigate?: NavigateCallback;
  onAction?: AnyActionCallback;
}

export type ShellUpdateOptions = Pick<ShellOptions,
  | 'workspace' | 'title' | 'titleIcon' | 'navigation' | 'apps' | 'role' | 'collapsed' | 'railContent' | 'railLabel'
  | 'appLabel' | 'showSearch' | 'theme' | 'contentMode' | 'activePath'
  | 'onSearch' | 'onHome' | 'onChat' | 'onMore' | 'onWorkspace'
  | 'onNavigate' | 'onAction'
>;

export interface ShellController {
  readonly shell: HTMLElement;
  readonly railRoot: HTMLElement;
  readonly appRoot: HTMLElement;
  readonly actionsRoot: HTMLElement;
  setCollapsed(collapsed: boolean): void;
  setContentMode(contentMode: ContentMode): void;
  setActivePath(activePath: string | null): void;
  getApps(): RegisteredMhooApp[];
  getCurrentApp(): RegisteredMhooApp | undefined;
  update(patch: ShellUpdateOptions): ShellController;
  destroy(): void;
}

export function renderShell(options?: ShellOptions): string;
export function createAppRegistry(apps?: readonly MhooApp[], options?: { role?: string }): RegisteredMhooApp[];
export function createAppManifest(apps?: readonly MhooApp[]): MhooAppManifest;
export function parseAppManifest(input: string | unknown): MhooAppManifest;
export function createAppCatalog(manifests?: readonly MhooAppManifestInput[], options?: { role?: string }): RegisteredMhooApp[];
export function appForPath(apps: readonly MhooApp[], activePath: string | null | undefined): RegisteredMhooApp | undefined;
export function createShell(host: Element, options?: ShellOptions): ShellController;
export function hydrateShell(host: Element, options?: ShellOptions): ShellController;
