import { TypeSafeClient, choice, noul } from '@typesafe-ai/sdk';
import { layouts, validateDesign } from './config.js';
import { JevError } from './jev.mjs';

export const toolDefinitions = [
  { name: 'shell_inspect', description: 'Read the active shared inbox layout and preview revision.', inputSchema: { type: 'object', properties: {}, additionalProperties: false } },
  { name: 'shell_preview_layout', description: 'Change the live inbox layout without saving to disk, committing, or modifying inbox data.', inputSchema: { type: 'object', properties: { layout: { type: 'string', enum: Object.keys(layouts) }, expectedRevision: { type: 'integer', minimum: 0 } }, required: ['layout','expectedRevision'], additionalProperties: false } },
];
export function createShellTools(initial) {
  let preview = { design: validateDesign(initial), revision: 0 };
  const snapshot = () => structuredClone(preview);
  return { snapshot, call(name, args = {}) {
    if (!args || typeof args !== 'object' || Array.isArray(args)) throw new JevError('Tool arguments must be an object.',400);
    if (name === 'shell_inspect' && Object.keys(args).length === 0) return snapshot();
    if (name !== 'shell_preview_layout') throw new JevError('Unknown tool or invalid arguments.',400);
    if (Object.keys(args).some(k=>!['layout','expectedRevision'].includes(k)) || !Number.isInteger(args.expectedRevision)) throw new JevError('Invalid preview arguments.',400);
    let design; try { design=validateDesign({layout:args.layout}); } catch { throw new JevError('Unsupported layout.',400); }
    if(args.expectedRevision !== preview.revision) throw new JevError('Preview changed during this decision. Inspect it and retry.',409);
    preview = {design, revision:preview.revision+1}; return snapshot();
  } };
}
export function commandRequest(input, current) {
  if(!input || typeof input.request !== 'string' || !input.request.trim() || input.request.length>4000) throw new JevError('Describe the command in 1–4000 characters.',400);
  return {model:'jev-latest',state:{request:input.request.trim(),current,availableLayouts:layouts},questions:{
    action:choice('What operation does `request` ask Shell to perform now? Choose none for discussion, hypothetical examples, negated commands, or requests outside these tools.',{
      shell_inspect:'Read or show the current layout configuration.',shell_preview_layout:'Apply or preview one of the available inbox layouts now.',none:'No supported operation requested.'}),
    layout:choice('If the user requests an inbox layout change, which available layout matches `request`? Select unspecified if the intended layout cannot be determined.',{
      ...Object.fromEntries(Object.entries(layouts).map(([id,l])=>[id,l.description])),unspecified:'No clear layout preference, or multiple conflicting preferences.'}),
    requested:noul('Does `request` ask for a supported operation to happen now, rather than ask for an explanation or quote an example?'),
    outside_scope:noul('Does satisfying `request` require anything beyond reading the current layout or previewing Split, Focus, or Compact? This includes sending messages, saving permanently, deleting data, building a new design, committing or deploying.'),
  }};
}
function validChoice(answer, options) {
  return answer?.type==='choice' && options.includes(answer.choice) && Number.isFinite(answer.confidence) && answer.confidence>=0 && answer.confidence<=1 && answer.probabilities && Object.keys(answer.probabilities).length===options.length && options.every(k=>Number.isFinite(answer.probabilities[k])&&answer.probabilities[k]>=0&&answer.probabilities[k]<=1) && answer.probabilities[answer.choice] >= Math.max(...Object.values(answer.probabilities)) && Math.abs(Object.values(answer.probabilities).reduce((a,b)=>a+b,0)-1)<.02;
}
// Provisional experiment policy; these are not calibrated guarantees or authorization.
export const commandPolicy = {minimumConfidence:.65,minimumProbability:.65,minimumRequested:.75,maximumOutsideScope:.25};
export function decideCommand(answers, current) {
  if(!validChoice(answers?.action,['shell_inspect','shell_preview_layout','none']) || !validChoice(answers?.layout,[...Object.keys(layouts),'unspecified']) || !['requested','outside_scope'].every(k=>answers[k]?.type==='noul'&&Number.isFinite(answers[k].noul)&&answers[k].noul>=0&&answers[k].noul<=1)) throw new JevError('TypeSafe returned invalid command judgments.',502);
  const reasons=[];
  if(answers.action.choice==='none')reasons.push('No supported operation selected.');
  if(answers.action.confidence<commandPolicy.minimumConfidence || answers.action.probabilities[answers.action.choice]<commandPolicy.minimumProbability)reasons.push('Action is uncertain.');
  if(answers.requested.noul<commandPolicy.minimumRequested)reasons.push('An immediate operation was not clearly requested.');
  if(answers.outside_scope.noul>commandPolicy.maximumOutsideScope)reasons.push('The request includes unsupported work.');
  if(answers.action.choice==='shell_preview_layout'&&(answers.layout.choice==='unspecified'||answers.layout.confidence<commandPolicy.minimumConfidence || answers.layout.probabilities[answers.layout.choice]<commandPolicy.minimumProbability))reasons.push('The layout preference is uncertain.');
  if(reasons.length)return {status:'not_executed',reasons};
  return {status:'ready',tool:answers.action.choice,arguments:answers.action.choice==='shell_inspect'?{}:{layout:answers.layout.choice,expectedRevision:current.revision}};
}
export async function runCommand(input,{tools,apiKey=process.env.TYPESAFE_API_KEY,fetchImpl=fetch,preview=false}={}) {
  const current=await tools.snapshot(); const request=commandRequest(input,current);
  if(preview)return {source:'preview',providerCalls:0,request,policy:commandPolicy};
  if(!apiKey)throw new JevError('This server needs TYPESAFE_API_KEY to run Jev commands.',503);
  const client=new TypeSafeClient({apiKey,baseURL:'https://api.typesafe.ai',defaultModel:'jev-latest',logLevel:'off',timeout:15000,retry:{maxRetries:0},fetch:(url,init)=>fetchImpl(url,{...init,redirect:'manual'})});
  let response;
  try {response=await client.systemOne(request);}catch{throw new JevError('TypeSafe command evaluation failed. No tool was executed.',502);}
  const decision=decideCommand(response.answers,current);
  let execution=decision;
  if(decision.status==='ready')execution={...decision,status:'executed',result:await tools.call(decision.tool,decision.arguments)};
  return {source:'typesafe',model:response.model,providerCalls:1,judgments:response.answers,usage:response.usage,policy:commandPolicy,execution};
}
