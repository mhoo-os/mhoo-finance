import test from 'node:test';
import assert from 'node:assert/strict';
import {createDurableTraces} from './durable-traces.mjs';
test('durable recorder persists request before provider, retains error body and redacts secret',async()=>{
 let saved;const writes=[];const traces=createDurableTraces({async put(r){saved=structuredClone(r);writes.push(saved);}}, {redact:'test-secret'});
 await assert.rejects(traces.run('/api/commands/run',{request:'test-secret'},async fetcher=>{const r=await fetcher('https://provider.invalid',{body:JSON.stringify({state:'test-secret',questions:{}})});assert.equal(r.status,429);throw Object.assign(Error('Rate limited'),{status:502});},async()=>{assert.equal(saved.steps[0].status,'running');return new Response('{"error":"test-secret"}',{status:429});}));
 assert.equal(saved.status,'failed');assert.equal(saved.steps[0].httpStatus,429);assert.equal(saved.steps[0].response.error,'[REDACTED]');assert.ok(!JSON.stringify(writes).includes('test-secret'));
});
test('storage failure prevents provider execution',async()=>{let called=false;const traces=createDurableTraces({async put(){throw Error('storage unavailable');}});await assert.rejects(traces.run('/run',{},()=>{called=true;}));assert.equal(called,false);});

test('all configured provider credentials are removed from persisted results',async()=>{
 const writes=[];const traces=createDurableTraces({async put(r){writes.push(structuredClone(r));}},{redact:['jev-secret','codex-secret',undefined,'gateway-secret']});
 await traces.run('/run',{request:'jev-secret'},async()=>({raw:'codex-secret gateway-secret'}));
 const serialized=JSON.stringify(writes);
 for(const secret of ['jev-secret','codex-secret','gateway-secret'])assert.ok(!serialized.includes(secret));
 assert.match(serialized,/REDACTED/);
});

test('progress and workflow metadata persist before the final result',async()=>{
 let saved;const traces=createDurableTraces({async put(r){saved=structuredClone(r);}});
 await traces.run('/run',{workflow:{id:'example',title:'Example',stageIndex:0}},async(_fetch,_id,progress)=>{await progress({status:'streaming',characters:120,bytes:200});assert.equal(saved.status,'running');assert.equal(saved.generation.characters,120);assert.equal(saved.workflow.id,'example');return {html:'done'};});
 assert.equal(saved.status,'complete');assert.equal(saved.generation.characters,120);
});
