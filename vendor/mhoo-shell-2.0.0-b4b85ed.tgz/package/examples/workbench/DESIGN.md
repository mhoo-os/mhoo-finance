# Workbench design notes

## Inherited Shell

This example is a functional local app mounted inside the existing Shell. It keeps the Shell's 220px desktop rail, 48px header, white app surface, light gray navigation surface, thin borders, Inter/Arial typography, and restrained icon-led controls. The app uses the Shell's edge content mode; it does not define a new global design direction.

The inbox continues that quiet, low-chrome language. Information hierarchy comes from spacing, weight, dividers, and a pale green selected row rather than decoration. Message content stays readable with a narrow text measure, generous line height, and a centered reading column.

## Workbench tokens

The extension defines only local `--wb-*` tokens:

- Ink `#272a29`, muted text `#666b68`, and line `#e6e8e6`.
- Action green `#28624c` for primary controls, focus rings, selection details, and active toolbar choices.
- Soft surface `#f4f6f3`, white panels, and page background `#f8f9f7`.
- Gently rounded containers use `12px`; the floating toolbar uses `16px`.
- The toolbar alone receives the ambient shadow `0 12px 40px #18291d29` so it reads as a developer control above the app.

Controls retain visible two-pixel focus outlines. Labels and secondary controls are small and muted; primary actions use compact solid-green buttons. The toolbar arrives with a short animation when reduced motion is not requested.

## Layout and behavior

Split is the default two-pane inbox. Focus uses a list-to-detail journey. Compact keeps two panes while reducing row height and hiding message previews. All three variants operate on the same conversations and draft data; changing layout does not create a separate app state. **Keep layout** saves the selected configuration to `examples/workbench/selected-design.json` for review.

The floating developer toolbar stays near the lower center of the app on desktop and exposes three bounded layout choices: Split, Focus, and Compact. Jev may choose only among those supported choices; it does not generate components or arbitrary behavior.

At 1000px and below, the toolbar centers in the viewport, list spacing tightens, and list avatars are temporarily hidden. At 700px and below, every variant uses the list-to-detail journey, the toolbar spans the viewport with 12px side margins, and the Shell rail follows its existing mobile drawer behavior. The toolbar may collapse to a small control at the lower right.

## Review status

**SHIP.** The desktop and mobile captures show the local inbox inside the real Shell, the shared message and draft state, and the floating toolbar at both sizes:

- `.workbench/proof/desktop.png` (1048 × 921)
- `.workbench/proof/mobile.png` (390 × 844)

The review has two bounded limitations. No live Jev call was verified because no TypeSafe API key was available; the UI correctly reports `Jev · key needed`, while manual variants remain functional. The review browser also exposes no WebMCP tools, so the optional registered browser-tool path was not exercised.

## API-first inspector extension

Current default hides the legacy floating toolbar. `/jev` is a separate developer
surface, following the same quiet white/gray and green visual system. Brief and
connection controls occupy a 360px left column; expandable request/response JSON
and probability bars occupy the flexible right column. Under760px, columns stack.
The inspectable unit is an actual provider call. Preview has an explicit no-call
label and no fabricated response. Provider keys and headers never enter the view.
