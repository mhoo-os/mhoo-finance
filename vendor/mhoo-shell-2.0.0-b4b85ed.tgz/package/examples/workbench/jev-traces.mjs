export function describeJevTurn(request, index = 0) {
  const questions = Object.values(request?.questions || {});
  const counts = questions.reduce((result, question) => {
    const type = question?.type || 'unknown'; result[type] = (result[type] || 0) + 1; return result;
  }, {});
  const types = Object.entries(counts).map(([type, count]) => `${count} ${type}`).join(', ');
  return `Jev turn ${index + 1} · ${questions.length} parallel question${questions.length === 1 ? '' : 's'}${types ? ` (${types})` : ''}`;
}

// Process-local history only. Never record request headers or credentials.
export function createTraceStore({ limit = 12, redact = '' } = {}) {
  const records = [];
  const clean = value => {
    const text = JSON.stringify(value);
    return JSON.parse(redact ? text.split(redact).join('[REDACTED]') : text);
  };
  return {
    list: () => clean(records),
    async run(route, operation, fetchImpl) {
      const record = { id: crypto.randomUUID(), route, startedAt: new Date().toISOString(), status: 'running', steps: [] };
      records.unshift(record); records.splice(limit);
      const started = Date.now();
      const tracedFetch = async (url, init) => {
        const request = clean(JSON.parse(init.body));
        const step = { stage: describeJevTurn(request, record.steps.length), request, status: 'running' };
        record.steps.push(step); const time = Date.now();
        try {
          const response = await fetchImpl(url, init);
          step.httpStatus = response.status;
          // Keep a bounded response; do not expose upstream error bodies or headers.
          if (response.ok) {
            const text = await response.clone().text();
            step.response = text.length <= 64000 ? clean(JSON.parse(text)) : { omitted: 'Response exceeds trace limit.' };
          }
          step.status = response.ok ? 'received' : 'failed';
          return response;
        } catch (error) { step.status = 'failed'; throw error; }
        finally { step.elapsedMs = Date.now() - time; }
      };
      try { const result = await operation(tracedFetch); record.result = clean(result); record.status = 'complete'; return { ...result, traceId: record.id }; }
      catch (error) { record.status = 'failed'; record.error = error.status ? error.message : 'Request failed.'; throw error; }
      finally { record.elapsedMs = Date.now() - started; }
    },
  };
}
