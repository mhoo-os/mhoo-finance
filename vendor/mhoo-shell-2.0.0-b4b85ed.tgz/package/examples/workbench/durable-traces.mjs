import { describeJevTurn } from './jev-traces.mjs';

// Await storage before inference and after every stage. Backends never evict runs.
export function createDurableTraces(store, { redact = '' } = {}) {
  const secrets = (Array.isArray(redact) ? redact : [redact]).filter(v => typeof v === 'string' && v.length);
  const clean = value => JSON.parse(JSON.stringify(value), (_key,v) => typeof v === 'string' ? secrets.reduce((text, secret) => text.split(secret).join('[REDACTED]'), v) : v);
  return {
    list: input => store.list(input),
    async run(route, input, operation, fetchImpl) {
      const record={id:crypto.randomUUID(),route,input:clean(input),startedAt:new Date().toISOString(),status:'running',steps:[]};
      if(input.workflow){
        const w=input.workflow;
        if(typeof w.id!=='string'||!/^[-a-zA-Z0-9_]{1,100}$/.test(w.id)||typeof w.title!=='string'||w.title.length>160||!Number.isInteger(w.stageIndex)||w.stageIndex<0||w.stageIndex>100)throw Object.assign(Error('Invalid workflow metadata.'),{status:400});
        record.workflow={id:w.id,title:w.title,stageIndex:w.stageIndex};
      }
      const save=()=>store.put(clean(record));
      const progress=async value=>{record.generation=clean({...value,updatedAt:new Date().toISOString()});await save();};
      await save();
      const start=Date.now();
      const tracedFetch=async(url,init)=>{
        const request=clean(JSON.parse(init.body));
        const step={stage:describeJevTurn(request,record.steps.length),request,status:'running'};
        record.steps.push(step);await save();const started=Date.now();
        try {
          const response=await fetchImpl(url,init);step.httpStatus=response.status;
          // Provider bodies are bounded, headers are never recorded. Preserve error bodies too.
          const reader=response.clone().body?.getReader();let bytes=0;const chunks=[];
          if(reader)try {while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>200_000){void reader.cancel().catch(()=>{});throw Error('Provider response exceeds capture limit.');}chunks.push(value);}}finally{reader.releaseLock();}
          const joined=new Uint8Array(bytes);let offset=0;for(const c of chunks){joined.set(c,offset);offset+=c.length;}
          const text=new TextDecoder().decode(joined);
          try {step.response=clean(JSON.parse(text));}catch {step.response={text:clean(text)};}
          step.status=response.ok?'received':'failed';return response;
        } catch(error){step.status='failed';step.error='Provider request failed or exceeded the capture limit.';step.errorName=error.name;throw error;}
        finally {step.elapsedMs=Date.now()-started;await save();}
      };
      try {const result=await operation(tracedFetch,record.id,progress);record.result=clean(result);record.status='complete';return {...result,traceId:record.id};}
      catch(error){record.status='failed';record.error=error.status?error.message:'Run interrupted or failed. Inspect its persisted stages and tool events.';throw error;}
      finally{record.elapsedMs=Date.now()-start;await save();}
    },
  };
}
