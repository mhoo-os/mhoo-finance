import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, mkdir, symlink, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { DesignLibrary, designLibrary, selectDesignSkill } from './design-skills.mjs';
import { createWorkbenchServer } from './server.mjs';

const skill = (id, requires = []) => ({ id, description: `Use ${id}`, requires, explicitOnly: false, resources: {} });
const library = { skills: [skill('minimal'), skill('accessible'), skill('stitch', ['stitch-mcp']), { ...skill('nothing'), explicitOnly: true }], read: async ({ id }) => ({ text: `${id} design reference` }) };
const provider = (selected, calls = []) => async (_url, init) => {
  const body = JSON.parse(init.body); calls.push(body);
  const keys = Object.keys(body.questions.skill.criteria);
  const chosen = typeof selected === 'function' ? selected(calls.length) : selected;
  const answers = { skill: { type: 'choice', choice: chosen, confidence: .9, probabilities: Object.fromEntries(keys.map(k => [k, k === chosen ? .9 : .1 / (keys.length - 1)])) } };
  for (const [id, question] of Object.entries(body.questions)) if (question.type === 'noul') answers[id] = { type: 'noul', noul: .9 };
  return Response.json({ model: 'test-jev', answers });
};
test('selection filters prerequisites and explicit-only styles, reads only three excerpts, returns metadata', async () => {
  const calls = [];
  const result = await selectDesignSkill({ request: 'Make the page calmer' }, { library, apiKey: 'test', fetchImpl: provider('minimal', calls) });
  assert.equal(result.selected.id, 'minimal'); assert.equal(result.providerCalls, 2);
  assert.deepEqual(Object.keys(calls[0].questions.skill.criteria), ['minimal', 'accessible', 'none']);
  assert.deepEqual(Object.keys(calls[0].questions), ['skill', 'guidance_applicable']);
  assert.equal(calls[1].state.candidates.length, 2);
  assert.deepEqual(Object.keys(calls[1].questions), ['skill', 'fit:minimal', 'fit:accessible']);
  assert.equal(JSON.stringify(result).includes('design reference'), false);
});
test('explicit choice bypasses inference but respects avoid and capabilities', async () => {
  const fetchImpl = () => { throw new Error('Must not call provider'); };
  const result = await selectDesignSkill({ request: 'Use this', preferred: 'nothing' }, { library, fetchImpl });
  assert.equal(result.source, 'explicit');
  await assert.rejects(selectDesignSkill({ request: 'Use it', preferred: 'stitch' }, { library }), /requires capabilities/);
  await assert.rejects(selectDesignSkill({ request: 'Use it', preferred: 'minimal', avoid: ['minimal'] }, { library }), /also be avoided/);
});
test('no-fit can stop either stage and malformed responses fail closed', async () => {
  assert.equal((await selectDesignSkill({ request: 'Solve arithmetic' }, { library, apiKey: 'x', fetchImpl: provider('none') })).providerCalls, 1);
  const result = await selectDesignSkill({ request: 'Maybe design' }, { library, apiKey: 'x', fetchImpl: provider(n => n === 1 ? 'minimal' : 'none') });
  assert.equal(result.selected, null); assert.equal(result.providerCalls, 2);
  await assert.rejects(selectDesignSkill({ request: 'Design' }, { library, apiKey: 'x', fetchImpl: provider('invented') }), /invalid skill/);
  await assert.rejects(selectDesignSkill(null, { library }), /request object/);
  await assert.rejects(selectDesignSkill({ request: 'Design' }, { library, apiKey: '' }), /TYPESAFE_API_KEY/);
  await assert.rejects(selectDesignSkill({ request: 'Design' }, { library, apiKey: 'x', fetchImpl: async () => new Response('', { status: 429 }) }), /rate limit/);
});
test('paged reader checks hashes, text allowlist, bounds and symlink containment', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'shell-skills-')); t.after(() => rm(dir, { recursive: true, force: true }));
  await mkdir(join(dir, 'sample')); await writeFile(join(dir, 'sample/SKILL.md'), 'abcdefghij');
  const resources = { 'SKILL.md': { bytes: 10, sha256: createHash('sha256').update('abcdefghij').digest('hex') } };
  const local = new DesignLibrary({ store: dir, skills: [{ ...skill('sample'), resources }] });
  const first = await local.read({ id: 'sample', limit: 4 }); assert.equal(first.text, 'abcd'); assert.equal(first.nextOffset, 4);
  assert.equal((await local.read({ id: 'sample', offset: 4 })).text, 'efghij');
  await assert.rejects(local.read({ id: 'sample', resource: '../secret.md' }), /listed text/);
  await assert.rejects(local.read({ id: 'sample', limit: 12001 }), /12000/);
  await writeFile(join(dir, 'sample/SKILL.md'), 'tampered'); await assert.rejects(local.read({ id: 'sample' }), /differs/);
  await rm(join(dir, 'sample/SKILL.md')); await writeFile(join(dir, 'outside.md'), 'abcdefghij');
  await symlink(join(dir, 'outside.md'), join(dir, 'sample/SKILL.md')); await assert.rejects(local.read({ id: 'sample' }), /escapes/);
});
test('HTTP endpoints enforce local access and return bounded guidance without provider credentials', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'shell-api-')); t.after(() => rm(dir, { recursive: true, force: true }));
  const server = await createWorkbenchServer({ dataDir: dir, designFile: join(dir, 'design.json'), apiKey: 'secret-test-value' });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); t.after(() => new Promise(resolve => server.close(resolve)));
  const origin = `http://127.0.0.1:${server.address().port}`;
  const listing = await (await fetch(origin + '/api/design-skills')).json(); assert.equal(listing.skills.length, 24);
  assert.equal(JSON.stringify(listing).includes('secret-test-value'), false);
  const rejected = await fetch(origin + '/api/design-skills/select', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' }); assert.equal(rejected.status, 403);
  const { csrf } = await (await fetch(origin + '/api/bootstrap')).json();
  const response = await fetch(origin + '/api/design-skills/select', { method: 'POST', headers: { origin, 'x-workbench-token': csrf, 'content-type': 'application/json' }, body: JSON.stringify({ request: 'Design', preferred: 'not-a-skill' }) }); assert.equal(response.status, 400);
});
test('unavailable skills are disclosed and excluded before inference', async t => {
  const dir = await mkdtemp(join(tmpdir(), 'shell-availability-')); t.after(() => rm(dir, { recursive: true, force: true }));
  await mkdir(join(dir, 'available')); await writeFile(join(dir, 'available/SKILL.md'), 'Design');
  const resources = { 'SKILL.md': { bytes: 6, sha256: createHash('sha256').update('Design').digest('hex') } };
  await mkdir(join(dir, 'tampered')); await writeFile(join(dir, 'tampered/SKILL.md'), 'Change');
  const local = new DesignLibrary({ store: dir, skills: ['available','missing','tampered'].map(id => ({ ...skill(id), resources })) });
  const listing = await local.list(); assert.deepEqual(listing.map(s => s.available), [true, false, false]);
  const calls = [];
  const result = await selectDesignSkill({ request: 'Design' }, { library: local, apiKey: 'x', fetchImpl: provider('available', calls) });
  assert.equal(result.selected.id, 'available'); assert.equal(result.unavailable.length, 2);
  assert.deepEqual(Object.keys(calls[0].questions.skill.criteria), ['available','none']);
});
test('request preview needs no credential, makes no provider call, and contains eligible criteria', async () => {
  const result = await selectDesignSkill({ request: 'Design a calm page' }, { library, preview: true, fetchImpl: () => { throw Error('No network'); } });
  assert.equal(result.source,'preview'); assert.equal(result.providerCalls,0);
  assert.equal(result.request.model,'jev-latest'); assert.equal(result.request.questions.skill.type,'choice');
  assert.equal(result.request.questions.guidance_applicable.type,'noul');
  assert.equal(Object.hasOwn(result.request.questions.skill.criteria,'stitch'),false);
});
