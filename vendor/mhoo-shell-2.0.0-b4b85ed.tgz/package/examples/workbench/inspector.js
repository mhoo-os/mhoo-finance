const $ = id => document.getElementById(id);
let csrf, activeId, renderedRecord, newestSeen, durable = false, nextCursor = null, pageBefore;
const json = value => JSON.stringify(value, null, 2);
function node(tag, text, className) { const element = document.createElement(tag); if (text !== undefined) element.textContent = text; if (className) element.className = className; return element; }
async function post(path, input = {}) {
  const response = await fetch(path, { method: 'POST', headers: { 'content-type': 'application/json', 'x-workbench-token': csrf }, body: json(input) });
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || 'Request failed.');
  return value;
}
function detail(title, value, open = false) { const element = node('details'); element.open = open; element.append(node('summary', title), node('pre', json(value))); return element; }
function answerCard(id, answer) {
  const card = node('article', undefined, 'answer');
  const heading = node('div', undefined, 'answer-heading');
  const value = answer.type === 'choice' ? answer.choice : answer.type === 'noul' ? `${(answer.noul * 100).toFixed(1)}% yes` : answer.type === 'score' ? String(answer.score) : answer.type || 'unknown';
  heading.append(node('h4', id), node('strong', value)); card.append(heading);
  if (answer.probabilities) for (const [label, probability] of Object.entries(answer.probabilities).sort((a, b) => b[1] - a[1])) {
    const row = node('div', undefined, 'probability'); const bar = node('progress'); bar.max = 1; bar.value = probability; bar.setAttribute('aria-label', `${id}: ${label}`);
    row.append(node('span', label), bar, node('span', `${(probability * 100).toFixed(1)}%`)); card.append(row);
  }
  if (Number.isFinite(answer.confidence)) card.append(node('p', `${(answer.confidence * 100).toFixed(1)}% confidence`, 'confidence'));
  return card;
}
function runSummary(record) {
  if (record.error) return record.error;
  if (record.result?.execution) return record.result.execution.status === 'executed' ? `Executed ${record.result.execution.tool}.` : `No tool executed: ${record.result.execution.reasons?.join(' ')}`;
  if(record.result?.phase) return `${record.result.phase} · ${record.result.model || record.result.judgments?.model || 'recorded'}${record.result.ready===false?' · needs revision':''}`;
  if (record.result?.selected && !Array.isArray(record.result.selected)) return `Selected design guidance: ${record.result.selected.id}.`;
  if (record.result?.selected === null) return 'No design guidance met the selection policy.';
  return record.status === 'running' ? 'This stage is running; provider results will appear when recorded.' : 'The run completed without a selection or tool event.';
}
let observerView = 'trace';
function setObserverView(view) {
  observerView=view;
  $('inspection-heading').textContent={trace:'Execution trace',payload:'Output inspector',preview:'Preview canvas'}[view];
  $('execution-path').hidden=view==='preview';
  for(const name of ['trace','payload','preview']) $('view-'+name).setAttribute('aria-pressed',String(name===view));
  $('steps').hidden=view!=='trace';$('payload-panel').hidden=view!=='payload';$('preview-panel').hidden=view!=='preview';
}
for(const view of ['trace','payload','preview']) $('view-'+view).addEventListener('click',()=>setObserverView(view));
const phaseNames={references:'Select references',specification:'Write specification',verify:'Check specification',generate:'Generate app'};
function phaseName(record){if(record.route==='/api/artifacts/evaluate')return 'Evaluate artifact';if(record.route==='/api/design-recipes/compose')return 'Select skills';return phaseNames[record.result?.phase || record.input?.phase] || record.route.replace('/api/','').replaceAll('/',' / ');}
function executionPath(record){
  const list=$('path-list');list.replaceChildren();
  const entries=[{label:'Request received',state:'complete',detail:phaseName(record)},...record.steps.map((step,index)=>({label:step.stage || `Jev turn ${index+1}`,state:step.status,detail:`${Object.keys(step.request?.questions || {}).length} questions · ${step.elapsedMs ?? '…'} ms`}))];
  if(record.result?.model)entries.push({label:record.result.model,state:record.result.status==='invalid'?'failed':'complete',detail:record.result.phase || 'Generator response'});
  entries.push({label:record.result?.status==='invalid'?'Output rejected':record.error?'Run failed':record.status==='running'?(record.generation?.status==='streaming'?'Receiving output':'Awaiting response'):(record.result?.html||record.result?.artifact)?'Artifact saved':record.result?.ready===false?'Revision requested':'Result recorded',state:record.error||record.result?.status==='invalid'?'failed':record.status,detail:record.error || (record.elapsedMs ? `${(record.elapsedMs/1000).toFixed(1)} seconds` : 'In progress')});
  for(const entry of entries){const item=node('li');item.dataset.state=entry.state;item.append(node('strong',entry.label),node('span',entry.detail));list.append(item);}
}
for(const [id,width] of [['preview-wide','fit'],['preview-phone','phone']])$(id).addEventListener('click',()=>{ $('artifact-frame').classList.toggle('phone',width==='phone');$('preview-wide').setAttribute('aria-pressed',String(width==='fit'));$('preview-phone').setAttribute('aria-pressed',String(width==='phone')); });
$('preview-expand').addEventListener('click',()=>{const expanded=document.body.classList.toggle('expanded-preview');$('preview-expand').setAttribute('aria-pressed',String(expanded));$('preview-expand').textContent=expanded?'Restore layout':'Expand canvas';});
async function showWorkflow(record){
  $('workflow-panel').hidden=!record.workflow;
  if(!record.workflow)return;
  const current=record.id;
  $('workflow-title').textContent=record.workflow.title;
  $('workflow-status').textContent='Loading recorded stages…';
  try{
    let before,traces=[];
    do{const page=await post('/api/jev/traces',{workflowId:record.workflow.id,limit:100,...(before?{before}:{})});traces.push(...page.traces);before=page.nextCursor;}while(before&&activeId===current);
    if(activeId!==current)return;
    traces.sort((a,b)=>a.workflow.stageIndex-b.workflow.stageIndex||a.startedAt.localeCompare(b.startedAt));
    $('workflow-stages').replaceChildren();
    for(const stage of traces){const item=node('li'),button=node('button');button.type='button';button.setAttribute('aria-pressed',String(stage.id===current));button.dataset.status=stage.error||stage.result?.status==='invalid'?'failed':stage.status;button.append(node('strong',phaseName(stage)),node('span',`${button.dataset.status} · ${stage.result?.model || stage.generation?.model || (stage.steps.length?'Jev':'recorded')}`));button.addEventListener('click',()=>show(stage));item.append(button);$('workflow-stages').append(item);}
    $('workflow-status').textContent=`${traces.length} recorded stages and attempts. Select a stage to inspect its evidence.`;
  }catch(error){if(activeId===current)$('workflow-status').textContent=error.message;}
}
function show(record) {
  if(activeId!==record.id){$('quality-observations').value='';$('quality-status').textContent='';}
  activeId = record.id; renderedRecord = json(record);
  executionPath(record);
  void showWorkflow(record);
  $('generation-progress').hidden=!record.generation;
  if(record.generation){const g=record.generation;$('generation-label').textContent=record.status==='failed'?'Generation stopped':record.status==='complete'?'Generation finished':g.status==='waiting'?'Waiting for provider':'Receiving output';$('generation-detail').textContent=`${(g.characters||0).toLocaleString()} characters · ${(g.bytes||0).toLocaleString()} bytes received · last update ${new Date(g.updatedAt).toLocaleTimeString()}`;}

  $('quality-panel').hidden=!(record.result?.artifact||typeof record.result?.html==='string');
  if(!$('quality-panel').hidden)void loadQuality(record.id);
  $('preview-open').hidden=!(record.result?.artifact||typeof record.result?.html==='string');
  $('preview-open').href='/api/artifact?id='+encodeURIComponent(record.id);
  $('payload-content').textContent=json(record.result ?? {status:record.status,error:record.error});
  const html=record.result?.html;
  const hasArtifact=Boolean(record.result?.artifact)||typeof html==='string';
  $('artifact-source').hidden=!hasArtifact;
  const frame=$('artifact-frame');frame.removeAttribute('srcdoc');frame.removeAttribute('src');frame.hidden=true;
  $('preview-status').textContent=hasArtifact?`Recorded HTML · ${record.result?.artifact?.storage || 'D1 legacy'} · isolated from Shell. External requests are blocked.`:'This run has no rendered artifact. Select a generation run; judgments and specifications appear in Output Inspector.';
  if(hasArtifact){
    frame.src='/api/artifact?id='+encodeURIComponent(record.id);
    frame.hidden=false;
  }
  setObserverView(observerView);
  $('evaluation').hidden = !durable || !record.id; $('verdict').value = record.evaluation?.verdict || 'unreviewed'; $('expected').value = record.evaluation?.expected || ''; $('notes').value = record.evaluation?.notes || '';
  $('run-meta').textContent = `${record.status} · ${record.elapsedMs ?? '…'} ms · ${record.steps.length} Jev turn${record.steps.length === 1 ? '' : 's'}`;
  $('summary').textContent = runSummary(record); $('steps').replaceChildren();
  for (const [index, step] of record.steps.entries()) {
    const section = node('section', undefined, 'step'); const head = node('div', undefined, 'step-head');
    const questionCount = Object.keys(step.request?.questions || {}).length; const turnNumber = node('div', String(index + 1), 'turn-number');
    head.append(turnNumber, node('h3', step.stage || `Turn ${index + 1}`), node('span', `${step.elapsedMs ?? '…'} ms · HTTP ${step.httpStatus ?? '—'} · ${questionCount} question${questionCount === 1 ? '' : 's'}`)); section.append(head);
    const answers = step.response?.answers;
    if (answers) { const grid = node('div', undefined, 'answers'); for (const [id, answer] of Object.entries(answers)) grid.append(answerCard(id, answer)); section.append(grid); }
    section.append(detail('State sent to Jev', step.request?.state, true), detail('Batched question schema', step.request?.questions), detail('Full request JSON', step.request));
    if (step.response) section.append(detail('Typed provider response', step.response, true));
    else section.append(node('p', step.status === 'running' ? 'Request in progress.' : 'No provider response body was recorded.', 'hint'));
    $('steps').append(section);
  }
  if (record.result) $('steps').append(detail('Composed application result', record.result));
  if (record.toolEvents?.length) $('steps').append(detail('Tool events', record.toolEvents, true));
  $('steps').append(detail('Complete run record', record));
  for (const button of document.querySelectorAll('#history-list button')) button.setAttribute('aria-pressed', String(button.dataset.id === activeId));
}
async function refresh(follow = false) {
  const page = await post('/api/jev/traces', pageBefore ? { before: pageBefore } : {}); const traces = page.traces.filter(record => record.route !== '/api/tools/call'); nextCursor = page.nextCursor; $('older').hidden = !nextCursor; $('history-list').replaceChildren();
  if (!traces.length) $('history-list').textContent = 'No turns recorded yet.';
  for (const record of traces) {
    const button = node('button'); button.type = 'button'; button.dataset.id = record.id; button.dataset.status=record.result?.status==='invalid'?'failed':record.status; button.setAttribute('aria-pressed', String(record.id === activeId));
    const route = node('span', phaseName(record), 'route'); const meta = node('span', `${record.result?.status==='invalid'?'invalid output':record.status} · ${new Date(record.startedAt).toLocaleString()}${record.result?.model ? ' · '+record.result.model : ''}`, 'turn-meta');
    button.append(route, meta); button.addEventListener('click', () => show(record)); $('history-list').append(button);
  }
  if (traces[0] && (follow || !activeId)) show(traces[0]);
  else if (activeId) { const record = traces.find(item => item.id === activeId); if (record && json(record) !== renderedRecord) show(record); }
  if(activeId&&!traces.some(item=>item.id===activeId)&&renderedRecord){const selected=JSON.parse(renderedRecord);if(selected.workflow)void showWorkflow(selected);}
  newestSeen = traces[0]?.id;
}
$('artifact-source').addEventListener('click',async()=>{const id=activeId;try{const source=await post('/api/artifacts/source',{id});if(activeId===id)$('payload-content').textContent=json(source);}catch(error){$('status').textContent=error.message;}});
async function loadQuality(id){
 try{const {evaluations}=await post('/api/artifacts/evaluations',{id});if(activeId!==id)return;$('quality-results').replaceChildren();
 for(const report of evaluations){const section=node('section');section.append(node('h4',new Date(report.createdAt).toLocaleString()),node('p',report.scope,'hint'));const scores=node('div',undefined,'quality-scores');for(const [name,answer] of Object.entries(report.judgment.answers)){const cell=node('div');cell.append(node('strong',`${(answer.score*2.5).toFixed(1)} / 10`),node('span',name));scores.append(cell);}section.append(scores,detail('Evidence, rubric and full Jev judgment',report));$('quality-results').append(section);}
 if(!evaluations.length)$('quality-results').textContent='No quality evaluation recorded for this artifact.';
 }catch(error){$('quality-status').textContent=error.message;}
}
$('quality-form').addEventListener('submit',async event=>{event.preventDefault();const id=activeId;const button=$('quality-submit');button.disabled=true;$('quality-status').textContent='Evaluating supplied evidence…';try{await post('/api/artifacts/evaluate',{id,observations:$('quality-observations').value});$('quality-status').textContent='Evaluation saved';if(activeId===id)await loadQuality(id);}catch(error){$('quality-status').textContent=error.message;}finally{button.disabled=false;}});
$('refresh').addEventListener('click', () => { pageBefore = undefined; refresh(true).catch(error => { $('status').textContent = error.message; }); });
$('older').addEventListener('click', () => { pageBefore = nextCursor; refresh(true).catch(error => { $('status').textContent = error.message; }); });
$('evaluation').querySelector('form').addEventListener('submit', async event => { event.preventDefault(); try { await post('/api/jev/evaluate', { id: activeId, verdict: $('verdict').value, expected: $('expected').value, notes: $('notes').value }); $('eval-status').textContent = 'Saved'; await refresh(); } catch (error) { $('eval-status').textContent = error.message; } });
$('export').addEventListener('click', async () => { const button = $('export'); button.disabled = true; try { let before, parts = []; do { const response = await fetch('/api/jev/export', { method: 'POST', headers: { 'content-type': 'application/json', 'x-workbench-token': csrf }, body: JSON.stringify({ limit: 100, ...(before ? { before } : {}) }) }); if (!response.ok) throw new Error('Export failed.'); parts.push(await response.text()); before = Number(response.headers.get('x-next-cursor')) || null; } while (before); const href = URL.createObjectURL(new Blob(parts, { type: 'application/x-ndjson' })); const anchor = node('a'); anchor.href = href; anchor.download = 'jev-turns.jsonl'; anchor.click(); setTimeout(() => URL.revokeObjectURL(href), 1000); } catch (error) { $('status').textContent = error.message; } finally { button.disabled = false; } });
try {
  const response = await fetch('/api/bootstrap'); if (!response.ok) throw new Error('Cannot connect to Shell.');
  const bootstrap = await response.json(); csrf = bootstrap.csrf; durable = Boolean(bootstrap.history?.durable); $('retention').textContent = durable ? 'Stored in D1 across restarts. No automatic eviction.' : 'Legacy local server: the last 12 runs are kept in memory.'; $('export').hidden = !durable;
  $('connection').textContent = [bootstrap.jev.configured ? 'TypeSafe configured' : 'TypeSafe key missing', bootstrap.generator ? `${bootstrap.generator.provider} · ${bootstrap.generator.model || 'model missing'}${bootstrap.generator.configured ? '' : ' · not configured'}` : null].filter(Boolean).join(' / '); await refresh();
  setInterval(() => { if (!document.hidden && !$('evaluation').contains(document.activeElement)&&!$('quality-panel').contains(document.activeElement)&&!$('quality-submit').disabled) refresh().catch(() => {}); }, 2000);
} catch (error) { $('status').textContent = error.message; }
