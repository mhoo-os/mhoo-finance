import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { parseHTML } from 'linkedom';
import { createShell } from '../../component.js';

test('Shell entry renders empty host mount points without Workbench content', async () => {
  const { document, window } = parseHTML('<!doctype html><html><body><div id="app-shell"></div></body></html>');
  const previous = { document: globalThis.document, Element: globalThis.Element, CustomEvent: globalThis.CustomEvent, matchMedia: globalThis.matchMedia };
  Object.assign(globalThis, { document, Element: window.Element, CustomEvent: window.CustomEvent, matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }) });
  try {
    const source = (await readFile(new URL('./app.js', import.meta.url), 'utf8')).replace(/^import .*;\n/gm, '');
    const run = new Function('document', 'createShell', source);
    run(document, createShell);
    assert.equal(document.querySelectorAll('.ms-nav-item').length, 0);
    assert.equal(document.querySelector('[data-shell-rail]').textContent.trim(), '');
    assert.equal(document.querySelector('[data-shell-app]').textContent.trim(), '');
    assert.equal(document.querySelector('[data-shell-actions]').textContent.trim(), '');
    assert.equal(document.querySelector('[data-shell-action="more"]').hidden, true);
    assert.equal(document.querySelector('[data-mhoo-shell]').dataset.collapsed, 'true');
    assert.equal(document.querySelector('.ms-brand').hidden, true);
    assert.equal(document.querySelector('.ms-header-title').hidden, true);
    const expand = document.querySelector('[data-shell-toggle]');
    const collapse = document.querySelector('[data-shell-collapse]');
    assert.equal(document.querySelector('[data-mhoo-shell]').dataset.railEnabled, 'false');
    assert.equal(document.querySelector('.ms-rail').hidden, true);
    assert.equal(expand.hidden, true);
    assert.equal(collapse.hidden, true);
    assert.equal(document.querySelector('[data-mhoo-shell]').dataset.collapsed, 'true');

    const configured = document.createElement('div');
    configured.id = 'app-shell';
    configured.dataset.workspace = 'Example';
    configured.dataset.title = 'Inbox';
    document.body.replaceChildren(configured);
    run(document, createShell);
    assert.equal(document.querySelector('.ms-brand-name').textContent, 'Example');
    assert.equal(document.querySelector('[data-shell-title]').textContent, 'Inbox');
    assert.equal(document.querySelector('.ms-brand').hidden, false);
    assert.equal(document.querySelector('.ms-header-title').hidden, false);
    assert.equal(document.title, 'Inbox · Example');
  } finally { Object.assign(globalThis, previous); }
});
