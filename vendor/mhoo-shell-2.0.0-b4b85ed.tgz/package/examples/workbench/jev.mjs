import { layoutQuestion, validateDesign } from './config.js';

export class JevError extends Error {
  constructor(message, status = 502) { super(message); this.status = status; }
}
export async function chooseLayout({ request, current }, { apiKey = process.env.TYPESAFE_API_KEY, fetchImpl = fetch } = {}) {
  const design = validateDesign(current);
  if (typeof request !== 'string' || !request.trim() || request.length > 2000) throw new JevError('Describe a layout change in 1–2,000 characters.', 400);
  if (!apiKey) throw new JevError('Jev is not connected. Set TYPESAFE_API_KEY on the local server, then restart it. Manual layouts work now.', 503);
  let response;
  try {
    response = await fetchImpl('https://api.typesafe.ai/v1/systemone', {
      method: 'POST', headers: { authorization: `Bearer ${apiKey}`, 'content-type': 'application/json' },
      // Do not send inbox content, drafts, identities, or project files.
      body: JSON.stringify({ model: 'jev-latest', state: { request: request.trim(), current: design }, questions: { layout: layoutQuestion } }),
      signal: AbortSignal.timeout(12_000), redirect: 'manual',
    });
  } catch { throw new JevError('Jev could not be reached. Try again or choose a layout manually.'); }
  if (!response.ok) throw new JevError(response.status === 401 || response.status === 403 ? 'TypeSafe rejected the server credential. Check your API access.' : response.status === 429 ? 'TypeSafe is rate limiting requests. Wait a moment and try again.' : 'TypeSafe could not complete this request. Your layout is unchanged.');
  let result;
  try { result = await response.json(); } catch { throw new JevError('TypeSafe returned an unreadable response. Your layout is unchanged.'); }
  const answer = result?.answers?.layout;
  const options = Object.keys(layoutQuestion.criteria);
  if (answer?.type !== 'choice' || !options.includes(answer.choice) || !Number.isFinite(answer.confidence) || answer.confidence < 0 || answer.confidence > 1 ||
      !answer.probabilities || Object.keys(answer.probabilities).length !== options.length ||
      !options.every(key => Number.isFinite(answer.probabilities[key]) && answer.probabilities[key] >= 0 && answer.probabilities[key] <= 1) ||
      Math.abs(Object.values(answer.probabilities).reduce((a, b) => a + b, 0) - 1) > 0.02) {
    throw new JevError('TypeSafe returned an invalid layout choice. Your layout is unchanged.');
  }
  return { choice: answer.choice, confidence: answer.confidence, probabilities: answer.probabilities, model: String(result.model || 'jev-latest'), source: 'typesafe' };
}
