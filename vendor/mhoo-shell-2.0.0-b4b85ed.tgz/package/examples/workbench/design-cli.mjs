// This client never reads or prints the TypeSafe key. The server owns credentials.
const [command = 'list', argument] = process.argv.slice(2);
const origin = `http://127.0.0.1:${process.env.WORKBENCH_PORT || '4182'}`;
try {
  if (!['list', 'select', 'read'].includes(command)) throw new Error('Use list, select <JSON>, or read <JSON>.');
  let response;
  if (command === 'list') response = await fetch(`${origin}/api/design-skills`);
  else {
    const input = JSON.parse(argument || '{}');
    const bootstrapResponse = await fetch(`${origin}/api/bootstrap`);
    if (!bootstrapResponse.ok) throw new Error('Cannot connect to the local Shell server.');
    const { csrf } = await bootstrapResponse.json();
    response = await fetch(`${origin}/api/design-skills/${command}`, { method: 'POST', headers: { origin, 'content-type': 'application/json', 'x-workbench-token': csrf }, body: JSON.stringify(input) });
  }
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
  console.log(JSON.stringify(result, null, 2));
} catch (error) { console.error(error.message); process.exitCode = 1; }
