const catalogProofs = new WeakSet();
const routeProofs = new WeakSet();

export class ModelRoutingError extends Error {
  constructor(message, status = 422) { super(message); this.status = status; }
}

const policies = Object.freeze({
  'visual-observation': Object.freeze({ candidates: Object.freeze(['gpt-6-astra']), reasoningEffort: 'high' }),
  'visual-design': Object.freeze({ candidates: Object.freeze(['gpt-6-astra']), reasoningEffort: 'high' }),
  'design-planning': Object.freeze({ candidates: Object.freeze(['gpt-6-astra']), reasoningEffort: 'high' }),
  implementation: Object.freeze({ candidates: Object.freeze(['gpt-5.6-terra', 'gpt-6-sol', 'gpt-6-astra']), reasoningEffort: 'medium' }),
  coordination: Object.freeze({ candidates: Object.freeze(['gpt-5.6-sol', 'gpt-5.6-terra']), reasoningEffort: 'low' }),
  routine: Object.freeze({ candidates: Object.freeze(['gpt-5.6-luna', 'gpt-6-luna', 'gpt-5.6-terra']), reasoningEffort: 'low' }),
});

const modelId = value => typeof value === 'string' && /^[a-z0-9][a-z0-9._:-]{0,127}$/i.test(value);

/** Parse an OpenAI-compatible model list into an immutable proof of discovery. */
export function parseCodexModelCatalog(payload) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload) || !Array.isArray(payload.data) || payload.data.length > 500) {
    throw new ModelRoutingError('Codex-lb returned an invalid model catalog.', 502);
  }
  const models = [];
  const seen = new Set();
  for (const entry of payload.data) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry) || !modelId(entry.id) || seen.has(entry.id)) {
      throw new ModelRoutingError('Codex-lb returned an invalid model catalog.', 502);
    }
    seen.add(entry.id);
    models.push(entry.id);
  }
  if (!models.length) throw new ModelRoutingError('Codex-lb returned an empty model catalog.', 503);
  const catalog = Object.freeze({ models: Object.freeze(models) });
  catalogProofs.add(catalog);
  return catalog;
}

/** Validate the application-owned routing decision before any provider call. */
export function parseCodexModelRoute(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).some(key => key !== 'task') || !Object.hasOwn(policies, input.task)) {
    throw new ModelRoutingError('Model routing requires a known task.');
  }
  const route = Object.freeze({ task: input.task });
  routeProofs.add(route);
  return route;
}

/** Select from discovered models only. Workflow-specific context stays the caller's responsibility. */
export function selectCodexModel(catalog, route) {
  if (!catalogProofs.has(catalog)) throw new ModelRoutingError('Model selection requires a validated Codex-lb catalog.', 500);
  if (!routeProofs.has(route)) throw new ModelRoutingError('Model selection requires a validated route.', 500);
  const policy = policies[route.task];
  const model = policy.candidates.find(candidate => catalog.models.includes(candidate));
  if (!model) throw new ModelRoutingError(`No approved Codex-lb model is available for ${route.task}.`, 503);
  return Object.freeze({
    model,
    task: route.task,
    reasoningEffort: policy.reasoningEffort,
    source: 'discovered-policy',
  });
}

export const modelRoutingTasks = Object.freeze(Object.keys(policies));
