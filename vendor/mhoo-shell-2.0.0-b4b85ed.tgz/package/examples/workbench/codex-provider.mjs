import { JevError } from './jev.mjs';
import { ModelRoutingError, parseCodexModelCatalog, parseCodexModelRoute, selectCodexModel } from './model-router.mjs';

// Credentials and upstream origin come exclusively from server configuration.
// Models are discovered once per provider instance and selected by a closed policy.
export function codexProvider(env, fetchImpl = fetch, onProgress = async () => {}) {
  let catalogPromise;
  const configuration = () => {
    if (!env.CODEX_LB_BASE_URL || !env.CODEX_LB_API_KEY) throw new JevError('Configure CODEX_LB_BASE_URL and CODEX_LB_API_KEY on the server.', 503);
    const base = new URL(env.CODEX_LB_BASE_URL);
    if (base.protocol !== 'https:' || base.username || base.password || base.search || base.hash) throw new JevError('Codex-lb requires a clean HTTPS API base URL.', 503);
    const headers = { authorization: `Bearer ${env.CODEX_LB_API_KEY}` };
    if (env.CF_AIG_TOKEN) { headers['cf-aig-authorization'] = `Bearer ${env.CF_AIG_TOKEN}`; headers['cf-aig-no-wholesale'] = 'true'; }
    return { base, headers };
  };
  const catalog = async () => {
    if (catalogPromise) return catalogPromise;
    catalogPromise = (async () => {
      const { base, headers } = configuration();
      const response = await fetchImpl(new URL(base.href.replace(/\/$/, '') + '/models'), { headers, redirect: 'manual', signal: AbortSignal.timeout(15_000) });
      if (!response.ok) throw new JevError(`Codex-lb model discovery failed (HTTP ${response.status}).`, 502);
      return parseCodexModelCatalog(await readBoundedJson(response, 512_000, 'model catalog'));
    })();
    return catalogPromise;
  };
  return {
    async run(_unusedModel, input) {
      const { base, headers } = configuration();
      let selection;
      try {
        const route = parseCodexModelRoute(input?.route);
        selection = selectCodexModel(await catalog(), route);
      } catch (error) {
        if (error instanceof ModelRoutingError) throw new JevError(error.message, error.status);
        if (error instanceof JevError) throw error;
        if (error.name === 'TimeoutError' || error.name === 'AbortError') throw new JevError('Codex-lb model discovery timed out.', 504);
        throw new JevError('Codex-lb model discovery failed.', 502);
      }
      const endpoint=new URL(base.href.replace(/\/$/,'')+'/chat/completions');
      headers['content-type']='application/json';
      try {
      await onProgress({status:'waiting',model:selection.model,route:selection.task,characters:0,bytes:0});
      const response=await fetchImpl(endpoint,{method:'POST',headers,body:JSON.stringify({model:selection.model,messages:input.messages,stream:true,stream_options:{include_usage:true},max_tokens:input.max_tokens,reasoning_effort:selection.reasoningEffort}),redirect:'manual',signal:AbortSignal.timeout(300000)});
      if(!response.ok)throw new JevError(`Codex-lb request failed (HTTP ${response.status}).`,502);
      const body=response.headers.get('content-type')?.includes('text/event-stream') ? await readCompletionStream(response,onProgress) : await readBoundedJson(response,2_000_000,'completion');
      const content=body.choices?.[0]?.message?.content;
      if(typeof content!=='string'||!content.length)throw new JevError('Codex-lb returned no text completion.',502);
      return {response:content,usage:body.usage||null,model:body.model||selection.model,settings:{maxTokens:input.max_tokens,stream:true,reasoningEffort:selection.reasoningEffort,route:selection.task,routingSource:selection.source}};
      } catch(error) {
        if(error.name==='TimeoutError'||error.name==='AbortError')throw new JevError('Codex-lb exceeded the five-minute generation limit.',504);
        if(error instanceof JevError)throw error;
        throw new JevError('Codex-lb connection or response decoding failed.',502);
      }
    },
  };
}

async function readBoundedJson(response, limit, label) {
  const reader=response.body?.getReader();
  if(!reader)throw new JevError(`Codex-lb returned no ${label}.`,502);
  const decoder=new TextDecoder();let bytes=0,text='';
  try {
    while(true){const {value,done}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>limit)throw new JevError(`Codex-lb ${label} exceeded the capture limit.`,502);text+=decoder.decode(value,{stream:true});}
    text+=decoder.decode();
    try{return JSON.parse(text);}catch{throw new JevError(`Codex-lb returned an unreadable ${label}.`,502);}
  } finally {await reader.cancel().catch(()=>{});reader.releaseLock();}
}

// Buffer bounded generated artifacts while consuming SSE promptly from the proxy.
async function readCompletionStream(response,onProgress) {
  const reader=response.body.getReader(),decoder=new TextDecoder();
  let pending='',content='',model,usage=null,bytes=0,doneMarker=false,finishReason,lastSaved=0;
  await onProgress({status:'streaming',characters:0,bytes:0});
  function event(block) {
    const data=block.split('\n').filter(line=>line.startsWith('data:')).map(line=>line.slice(5).trimStart()).join('\n');
    if(!data)return;
    if(data==='[DONE]'){doneMarker=true;return;}
    const chunk=JSON.parse(data);
    if(chunk.error)throw new JevError('Codex-lb reported a streaming error.',502);
    if(chunk.model)model=chunk.model;
    if(chunk.usage)usage=chunk.usage;
    const choice=chunk.choices?.[0];
    if(typeof choice?.delta?.content==='string')content+=choice.delta.content;
    if(choice?.finish_reason)finishReason=choice.finish_reason;
  }
  try {
    while(true){
      const {value,done}=await reader.read();
      if(done){pending+=decoder.decode();break;}
      bytes+=value.byteLength;
      if(bytes>2_000_000)throw new JevError('Codex-lb response exceeded the capture limit.',502);
      pending+=decoder.decode(value,{stream:true});
      pending=pending.replaceAll('\r\n','\n');
      let end;while((end=pending.indexOf('\n\n'))!==-1){event(pending.slice(0,end));pending=pending.slice(end+2);}
      if(Date.now()-lastSaved>=2000){await onProgress({status:'streaming',model,characters:content.length,bytes});lastSaved=Date.now();}
    }
    if(pending.trim())event(pending);
    if(!doneMarker||finishReason!=='stop')throw new JevError('Codex-lb stream ended without a complete response.',502);
    await onProgress({status:'received',model,characters:content.length,bytes});
    return {model,usage,choices:[{message:{content}}]};
  } finally { await reader.cancel().catch(()=>{});reader.releaseLock(); }
}
