import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseCodexModelCatalog, parseCodexModelRoute, selectCodexModel } from './model-router.mjs';

const payload = ids => ({ object: 'list', data: ids.map(id => ({ id, object: 'model' })) });

test('catalog and route proofs are validated, immutable, and not forgeable', () => {
  const catalog = parseCodexModelCatalog(payload(['gpt-6-astra', 'gpt-5.6-terra']));
  const route = parseCodexModelRoute({ task: 'visual-design' });
  assert.equal(Object.isFrozen(catalog), true);
  assert.equal(Object.isFrozen(catalog.models), true);
  assert.equal(Object.isFrozen(route), true);
  assert.throws(() => selectCodexModel({ models: catalog.models }, route), /validated.*catalog/i);
  assert.throws(() => selectCodexModel(catalog, { ...route }), /validated route/i);
  assert.throws(() => parseCodexModelCatalog(payload(['gpt-6-astra', 'gpt-6-astra'])), /invalid model catalog/);
  assert.throws(() => parseCodexModelRoute({ task: 'unknown' }), /known task/);
  assert.throws(() => parseCodexModelRoute({ task: 'visual-design', model: 'anything' }), /known task/);
});

test('policy reserves Astra for visual work and chooses bounded cheaper workers elsewhere', () => {
  const catalog = parseCodexModelCatalog(payload(['gpt-5.6-luna', 'gpt-5.6-sol', 'gpt-5.6-terra', 'gpt-6-astra']));
  assert.deepEqual(selectCodexModel(catalog, parseCodexModelRoute({ task: 'visual-observation' })), { model: 'gpt-6-astra', task: 'visual-observation', reasoningEffort: 'high', source: 'discovered-policy' });
  assert.equal(selectCodexModel(catalog, parseCodexModelRoute({ task: 'visual-design' })).model, 'gpt-6-astra');
  assert.equal(selectCodexModel(catalog, parseCodexModelRoute({ task: 'implementation' })).model, 'gpt-5.6-terra');
  assert.equal(selectCodexModel(catalog, parseCodexModelRoute({ task: 'coordination' })).model, 'gpt-5.6-sol');
  assert.equal(selectCodexModel(catalog, parseCodexModelRoute({ task: 'routine' })).model, 'gpt-5.6-luna');
});

test('visual work fails closed when Astra is absent instead of silently downgrading', () => {
  const catalog = parseCodexModelCatalog(payload(['gpt-5.6-sol', 'gpt-5.6-terra']));
  assert.throws(() => selectCodexModel(catalog, parseCodexModelRoute({ task: 'visual-design' })), /No approved.*visual-design/);
});
