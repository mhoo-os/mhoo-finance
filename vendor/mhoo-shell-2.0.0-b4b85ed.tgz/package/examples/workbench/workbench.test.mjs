import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { request as httpRequest } from 'node:http';
import { createWorkbenchServer } from './server.mjs';
import { chooseLayout } from './jev.mjs';
import { layoutQuestion } from './config.js';

async function fixture(t, options = {}) {
  const dir = await mkdtemp(join(tmpdir(), 'shell-workbench-'));
  const designFile = join(dir, 'selected-design.json');
  const config = { dataDir: dir, designFile, apiKey: '', ...options };
  const server = await createWorkbenchServer(config);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const bootstrap = await (await fetch(`${base}/api/bootstrap`)).json();
  const post = (path, body, headers = {}) => fetch(base + path, { method: 'POST', headers: { origin: base, 'content-type': 'application/json', 'x-workbench-token': bootstrap.csrf, ...headers }, body: JSON.stringify(body) });
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); await rm(dir, { recursive: true, force: true }); });
  return { dir, designFile, config, server, base, bootstrap, post };
}
test('drafts and archive changes persist, stale writes conflict, and reset preserves selected design', async t => {
  const f = await fixture(t);
  let response = await f.post('/api/messages', { revision: 0, action: 'draft', id: 'launch', draft: 'Testing a real saved reply.' });
  assert.equal(response.status, 200);
  let state = await response.json();
  assert.equal(state.messages[0].draft, 'Testing a real saved reply.');
  assert.equal(JSON.parse(await readFile(join(f.dir, 'inbox.json'))).messages[0].draft, state.messages[0].draft);
  assert.equal((await f.post('/api/messages', { revision: 0, action: 'archive', id: 'launch' })).status, 409);
  state = await (await f.post('/api/messages', { revision: 1, action: 'archive', id: 'launch' })).json();
  assert.equal(state.messages[0].archived, true);
  state = await (await f.post('/api/messages', { revision: 2, action: 'restore', id: 'launch' })).json();
  assert.equal(state.messages[0].archived, false);
  assert.equal((await f.post('/api/design', { layout: 'focus' })).status, 200);
  assert.deepEqual(JSON.parse(await readFile(f.designFile)), { layout: 'focus' });
  state = await (await f.post('/api/reset', { revision: 3 })).json();
  assert.equal(state.messages[0].draft, '');
  assert.deepEqual((await (await fetch(f.base + '/api/bootstrap')).json()).selected, { layout: 'focus' });
  // A fresh server instance reads the files instead of regenerating state.
  const reopened = await createWorkbenchServer(f.config);
  await new Promise(resolve => reopened.listen(0, '127.0.0.1', resolve));
  try {
    const persisted = await (await fetch(`http://127.0.0.1:${reopened.address().port}/api/bootstrap`)).json();
    assert.equal(persisted.state.revision, 4);
    assert.equal(persisted.selected.layout, 'focus');
  } finally { reopened.closeAllConnections(); await new Promise(resolve => reopened.close(resolve)); }
});
test('parallel writes do not overwrite one another', async t => {
  const f = await fixture(t);
  const responses = await Promise.all(['one', 'two'].map(draft => f.post('/api/messages', { revision: 0, action: 'draft', id: 'launch', draft })));
  assert.deepEqual(responses.map(r => r.status).sort(), [200, 409]);
});
test('local server rejects foreign origins, missing tokens, unknown hosts, invalid actions and designs', async t => {
  const f = await fixture(t);
  assert.equal((await f.post('/api/reset', { revision: 0 }, { origin: 'https://evil.example' })).status, 403);
  assert.equal((await f.post('/api/reset', { revision: 0 }, { 'x-workbench-token': '' })).status, 403);
  // Node fetch controls Host itself; raw HTTP verifies an actual forged Host.
  const forgedStatus = await new Promise((resolve, reject) => {
    const request = httpRequest(f.base + '/api/bootstrap', { headers: { host: 'evil.example' } }, response => { response.resume(); resolve(response.statusCode); });
    request.on('error', reject); request.end();
  });
  assert.equal(forgedStatus, 403);
  assert.equal((await fetch(f.base + '/api/bootstrap', { headers: { 'sec-fetch-site': 'cross-site' } })).status, 403);
  assert.equal((await f.post('/api/design', { layout: 'focus', command: 'push' })).status, 400);
  assert.equal((await f.post('/api/messages', { revision: 0, id: 'launch', action: 'send' })).status, 400);
  assert.equal((await f.post('/api/messages', { revision: 0, id: 'launch', action: 'draft', draft: 'x'.repeat(10001) })).status, 400);
  assert.equal((await fetch(f.base + '/.env')).status, 404);
  assert.equal((await fetch(f.base + '/server.mjs')).status, 404);
  assert.equal((await f.post('/api/jev', { request: 'compact please', current: { layout: 'split' } })).status, 503);
  for (const path of ['/', '/app.js', '/config.js', '/workbench.css', '/component.js', '/icons.js', '/shell.css', '/assets/shell-icons.jpg']) assert.equal((await fetch(f.base + path)).status, 200, path);
});
function answer(choice = 'compact') {
  return { model: 'jev-test', answers: { layout: { type: 'choice', choice, confidence: 0.92, probabilities: Object.fromEntries(Object.keys(layoutQuestion.criteria).map(key => [key, key === choice ? 1 : 0])) } } };
}
test('Jev uses the documented contract and sends only instruction plus layout', async () => {
  let observed;
  const result = await chooseLayout({ request: 'Show more messages at once', current: { layout: 'split' } }, { apiKey: 'test-only', fetchImpl: async (url, init) => {
    observed = { url, init, body: JSON.parse(init.body) };
    return Response.json(answer());
  } });
  assert.equal(result.choice, 'compact');
  assert.equal(result.source, 'typesafe');
  assert.equal(observed.url, 'https://api.typesafe.ai/v1/systemone');
  assert.equal(observed.init.redirect, 'manual');
  assert.deepEqual(Object.keys(observed.body.state), ['request', 'current']);
  assert.deepEqual(observed.body.questions.layout, layoutQuestion);
  assert.equal(observed.body.model, 'jev-latest');
});
test('Jev never substitutes fake results for missing access, API errors or invalid answers', async () => {
  const input = { request: 'Focus on one message', current: { layout: 'split' } };
  await assert.rejects(chooseLayout(input, { apiKey: '' }), /not connected/);
  for (const response of [Response.json({}, { status: 401 }), Response.json({}, { status: 429 }), Response.json(answer('send-email')), Response.json({ answers: {} }), new Response('invalid JSON')]) {
    await assert.rejects(chooseLayout(input, { apiKey: 'test-only', fetchImpl: async () => response }));
  }
  await assert.rejects(chooseLayout(input, { apiKey: 'test-only', fetchImpl: async () => { throw new Error('private provider error'); } }), /could not be reached/);
  assert.equal((await chooseLayout(input, { apiKey: 'test-only', fetchImpl: async () => Response.json(answer('unsupported')) })).choice, 'unsupported');
});
