# Shell workbench

Run `npm run workbench`, then open `http://127.0.0.1:4183`.

The default route demonstrates Shell before any application is installed. It
passes an empty app registry to the real component, so the navigation contains no
product entries. The page reports host readiness, the separately installed design
guidance catalog, and Jev connectivity. The Email Hub package remains an explicit
fixture for host tests; it is not mounted by this workbench.

## Coding agent design guidance

The page registers four optional WebMCP tools: inspect Shell, list design skills,
select guidance, and read selected guidance. The same catalog is available through
the CLI and HTTP endpoints documented in [the design catalog](../../design-catalog/README.md).

Selection follows the TypeSafe quickstart pattern:

1. Code filters unavailable skills and unmet capabilities.
2. One Jev turn batches a relative Choice with an independent applicability Noul.
3. Code uses that result to load only the leading skill excerpts.
4. A second Jev turn batches the shortlist Choice with one independent fit Noul
   per candidate.
5. Code applies explicit provisional thresholds and returns metadata for the
   coding agent to read. Jev does not generate code or execute skill instructions.

The second turn is progressive because its evidence depends on the first turn.
Questions within each turn are independent and run together. Thresholds are
visible in the result and require evaluation on representative tasks.

## Jev turn log

Open `/jev` to inspect real Jev activity. The page has no prompt form and does not
act as a playground. It lists agent and API initiated runs, then shows every turn's
structured state, full batched schema, typed answers, provider response, timing,
application result, and recorded tool events. Direct tools that make no Jev call
are excluded.

Cloudflare stores runs and optional human evaluations in D1 across restarts. The
legacy Node server keeps the latest 12 runs in memory. Both redact the configured
API key and never record request headers. The TypeSafe credential remains on the
server.

## Verification

```sh
npm run test:workbench
npm run cloudflare:build
npm test
```

The older layout and synthetic inbox adapters remain covered as compatibility
fixtures for command and persistence tests. They are not rendered by the default
Shell route.

## Generator model routing

Codex-lb is treated as a model gateway, not one fixed model. The server discovers
its OpenAI-compatible `/models` catalog, validates and seals that snapshot, then
applies a closed application policy. Visual observation, visual design and design
planning require GPT-6 Astra. Other registered task classes have bounded worker
choices. A missing task, malformed catalog or unavailable required model fails
before generation; there is no silent downgrade. Each workflow remains
responsible for validating its required context before it requests a model.
