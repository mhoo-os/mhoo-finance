import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runDesignPhase, validateSpecification } from './design-pipeline.mjs';
const brief={request:'Decision log with search, statuses, and details',preferences:'Compact editorial rows'};
const spec={direction:'Warm paper and dark ink',layout:'Compact rows with labelled columns',typography:'Georgia headings and Arial body',responsive:'Stack record fields under their labels below 600px',accessibility:'Native details and summary with visible focus',assetPlan:'No imagery needed',components:['Search and status controls'],acceptance:['Search returns matching records','Keyboard opens details','No horizontal overflow at 390px']};
test('reference stage selects only supported pinned references and validates probabilities',async()=>{
  const fetchImpl=async(_url,init)=>{const q=JSON.parse(init.body).questions;return Response.json({answers:Object.fromEntries(Object.keys(q).map(id=>[id,{type:'noul',noul:id==='table'?.9:.2}]))});};
  const r=await runDesignPhase({...brief,phase:'references'},{apiKey:'fixture',fetchImpl});
  assert.deepEqual(r.selected.map(r=>r.id),['table']);assert.match(r.selected[0].sha256,/^[a-f0-9]{64}$/);
  await assert.rejects(runDesignPhase({...brief,phase:'references'},{apiKey:'fixture',fetchImpl:async()=>Response.json({answers:{table:{type:'noul',noul:2}}})}),/Invalid Jev/);
});
test('one weak requirement blocks readiness instead of being averaged away',async()=>{
  const r=await runDesignPhase({...brief,phase:'verify',referenceIds:[],specification:spec},{apiKey:'fixture',fetchImpl:async(_url,init)=>Response.json({answers:Object.fromEntries(Object.keys(JSON.parse(init.body).questions).map(k=>[k,{type:'noul',noul:k==='keyboard'?.2:.99}]))})});
  assert.equal(r.ready,false);
});
test('planner preserves malformed output and accepts wrapped provider results',async()=>{
  const input={...brief,phase:'specification',referenceIds:[],guidance:'Fixture guidance'};
  const malformed=await runDesignPhase(input,{ai:{run:async()=>({response:'not json'})}});
  assert.equal(malformed.status,'invalid');assert.equal(malformed.raw,'not json');
  const good=await runDesignPhase(input,{ai:{run:async()=>({result:{response:JSON.stringify(spec)}})}});
  assert.equal(good.status,'ready');assert.deepEqual(good.specification,spec);
  const structured=await runDesignPhase(input,{ai:{run:async()=>({response:{...spec,components:[{name:'Details',contract:'Native details and summary'}]}})}});
  assert.equal(structured.status,'ready');assert.equal(structured.specification.components[0].name,'Details');
  let routed;
  await runDesignPhase(input,{ai:{run:async(_model,request)=>{routed=request.route;return {response:JSON.stringify(spec)};}}});
  assert.deepEqual(routed,{task:'design-planning'});
});
test('unknown references and missing specification fields fail before generation',async()=>{
  let called=false;const ai={run:async()=>{called=true;}};
  await assert.rejects(runDesignPhase({...brief,phase:'specification',referenceIds:[],guidance:''},{ai}),/selected guidance/);
  await assert.rejects(runDesignPhase({...brief,phase:'generate',referenceIds:['unknown'],specification:spec},{ai}),/Unknown reference/);
  assert.throws(()=>validateSpecification({...spec,accessibility:''}),/accessibility/);assert.equal(called,false);
});
