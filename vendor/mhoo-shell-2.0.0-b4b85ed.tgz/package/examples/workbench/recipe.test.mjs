import {test} from 'node:test';
import assert from 'node:assert/strict';
import {composeRecipe} from './recipe.mjs';
const skills=['primary','access','motion'].map(id=>({id,description:id,requires:[],resources:{'SKILL.md':{}},explicitOnly:false}));
function library(){return {skills,list:async()=>skills.map(s=>({...s,available:true})),read:async({id,offset=0})=>({text:offset?'end':`${id} guidance `,nextOffset:offset?null:1,resources:['SKILL.md','reference.md'],source:`https://example.com/${id}`,license:'MIT'})};}
function provider({conflict=false,invalid=false}={}){return async(_url,init)=>{
 const body=JSON.parse(init.body);const answers={};
 for(const [id,q] of Object.entries(body.questions)){
  if(q.type==='choice'){const chosen=id==='accessibility'?'access':id==='interaction'?'motion':'primary';answers[id]={type:'choice',choice:chosen,confidence:.9,probabilities:Object.fromEntries(Object.keys(q.criteria).map(k=>[k,k===chosen?1:0]))};}
  else answers[id]={type:'noul',noul:invalid?NaN:id.startsWith('conflict')?(conflict?1:0):1};
 }
 return Response.json({answers,model:'fixture'});
};}
test('recipe reads complete guidance, composes bounded roles and keeps baseline identical',async()=>{
 const r=await composeRecipe({request:'Design',preferred:'primary'},{library:library(),apiKey:'fixture',fetchImpl:provider()});
 assert.equal(r.ingredients.length,3);assert.ok(r.ingredients.every(i=>i.text.endsWith('end')));
 const a=JSON.parse(r.baselinePrompt),b=JSON.parse(r.prompt);assert.deepEqual(a.guidance,[b.guidance[0]]);delete a.guidance;delete b.guidance;assert.deepEqual(a,b);
});
test('conflicting specialists are discarded after their evidence is read',async()=>{
 const r=await composeRecipe({request:'Design',preferred:'primary'},{library:library(),apiKey:'fixture',fetchImpl:provider({conflict:true})});assert.equal(r.ingredients.length,1);
});
test('malformed evidence checks and missing keys do not produce a ready recipe',async()=>{
 await assert.rejects(composeRecipe({request:'Design',preferred:'primary'},{library:library(),apiKey:'fixture',fetchImpl:provider({invalid:true})}),/Invalid recipe verification/);
 await assert.rejects(composeRecipe({request:'Design',preferred:'primary'},{library:library(),apiKey:''}),/requires a server/);
});
