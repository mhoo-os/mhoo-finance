import { createShell } from '/component.js';

const host = document.querySelector('#app-shell');
const workspace = host.dataset.workspace || '';
const title = host.dataset.title || '';
if (workspace || title) document.title = [title, workspace].filter(Boolean).join(' · ');
const shell = createShell(host, {
  workspace,
  title,
  apps: [],
  collapsed: true,
  railLabel: 'Workspace panel',
  railContent: '',
  appLabel: title || 'Application',
});

shell.shell.querySelector('[data-shell-action="more"]').hidden = true;
