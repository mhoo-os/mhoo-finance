import { runDesignPhase } from './design-pipeline.mjs';
import { composeRecipe } from './recipe.mjs';
import { createServer } from 'node:http';
import { readFile, writeFile, rename, mkdir, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import { seedInbox } from './seed.js';
import { defaultDesign, validateDesign } from './config.js';
import { chooseLayout } from './jev.mjs';
import { createShellTools, toolDefinitions, runCommand } from './commands.mjs';
import { createTraceStore } from './jev-traces.mjs';
import { designLibrary, selectDesignSkill } from './design-skills.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../..');
const files = {
  '/observer': [join(here, 'inspector.html'), 'text/html'],
  '/jev': [join(here, 'inspector.html'), 'text/html'],
  '/inspector.js': [join(here, 'inspector.js'), 'text/javascript'],
  '/inspector.css': [join(here, 'inspector.css'), 'text/css'],
  '/': [join(here, 'index.html'), 'text/html'],
  '/app.js': [join(here, 'app.js'), 'text/javascript'],
  '/config.js': [join(here, 'config.js'), 'text/javascript'],
  '/workbench.css': [join(here, 'workbench.css'), 'text/css'],
  '/component.js': [join(root, 'component.js'), 'text/javascript'],
  '/icons.js': [join(root, 'icons.js'), 'text/javascript'],
  '/shell.css': [join(root, 'dist/shell.css'), 'text/css'],
  '/assets/shell-icons.jpg': [join(root, 'assets/shell-icons.jpg'), 'image/jpeg'],
};
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
async function readJson(path, fallback) {
  try { return JSON.parse(await readFile(path, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return fallback; throw error; }
}
async function atomicJson(path, value) {
  await mkdir(dirname(path), { recursive: true });
  const temporary = `${path}.tmp`;
  await writeFile(temporary, JSON.stringify(value, null, 2) + '\n', { mode: 0o600 });
  await rename(temporary, path);
}
async function bodyJson(request) {
  if (!request.headers['content-type']?.startsWith('application/json')) throw new HttpError(415, 'Send JSON.');
  let body = '';
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > 32_768) throw new HttpError(413, 'Request is too large.');
  }
  try { return JSON.parse(body); } catch { throw new HttpError(400, 'Request is not valid JSON.'); }
}

export async function createWorkbenchServer({ dataDir = join(root, '.workbench'), designFile = join(here, 'selected-design.json'), apiKey = process.env.TYPESAFE_API_KEY, fetchImpl = fetch } = {}) {
  const traces = createTraceStore({ redact: apiKey });
  const csrf = randomBytes(32).toString('hex');
  const stateFile = join(dataDir, 'inbox.json');
  let state = await readJson(stateFile, { revision: 0, messages: seedInbox() });
  if (!Number.isInteger(state.revision) || !Array.isArray(state.messages)) throw new Error('Workbench data is invalid. Restore or remove .workbench/inbox.json to reset.');
  const savedDesign = await readJson(designFile, null);
  let hasKeptDesign = savedDesign !== null;
  let selected = validateDesign(savedDesign ?? defaultDesign);
  const shellTools = createShellTools(selected);
  let writes = Promise.resolve();
  let inferenceRunning = false;
  let lastInference = 0;
  const serial = operation => {
    const next = writes.then(operation);
    writes = next.catch(() => {});
    return next;
  };
  const server = createServer(async (request, response) => {
    const json = (status, value) => { response.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }); response.end(JSON.stringify(value)); };
    try {
      const port = server.address()?.port;
      const allowedHosts = [`127.0.0.1:${port}`, `localhost:${port}`];
      if (!allowedHosts.includes(request.headers.host)) throw new HttpError(403, 'Local workbench host required.');
      const origin = `http://${request.headers.host}`;
      if (request.headers['sec-fetch-site'] === 'cross-site') throw new HttpError(403, 'Cross-site access is not allowed.');
      const url = new URL(request.url, origin);
      if (request.method === 'GET') {
        if (url.pathname === '/api/bootstrap') return json(200, { csrf, state, selected, preview: shellTools.snapshot(), hasKeptDesign, jev: { configured: Boolean(apiKey), model: 'jev-latest' } });
        if (url.pathname === '/api/design-skills') return json(200, { skills: await designLibrary.list() });
        if (url.pathname === '/api/tools') return json(200, { tools: toolDefinitions });
        if(url.pathname==='/api/artifact'){
          const record=traces.list().find(r=>r.id===url.searchParams.get('id'));
          if(typeof record?.result?.html!=='string')throw new HttpError(404,'No HTML artifact for this run.');
          response.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store','content-security-policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'; sandbox allow-scripts"});return response.end(record.result.html);
        }
        if (url.pathname === '/api/preview') return json(200, shellTools.snapshot());
        if (url.pathname === '/api/state') return json(200, state);
        if (url.pathname === '/api/revision') {
          const versions = await Promise.all(Object.values(files).map(async ([path]) => (await stat(path)).mtimeMs));
          return json(200, { revision: versions.join(':') });
        }
        const asset = files[url.pathname];
        if (!asset) throw new HttpError(404, 'Not found.');
        const bytes = await readFile(asset[0]);
        response.writeHead(200, { 'content-type': `${asset[1]}; charset=utf-8`, 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'content-security-policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'" });
        return response.end(bytes);
      }
      if (request.method !== 'POST') throw new HttpError(405, 'Method not allowed.');
      if (request.headers.origin !== origin || request.headers['x-workbench-token'] !== csrf) throw new HttpError(403, 'Reload this local workbench before making changes.');
      const input = await bodyJson(request);
      if (url.pathname === '/api/tools/call') return json(200, shellTools.call(input?.name,input?.arguments));
      if (url.pathname === '/api/commands/preview') return json(200, await runCommand(input,{tools:shellTools,preview:true}));
      if (url.pathname === '/api/jev/traces') return json(200, { traces: traces.list() });
      if (url.pathname === '/api/jev/preview') return json(200, await selectDesignSkill(input, { preview: true }));
      if (url.pathname === '/api/design-skills/read') return json(200, await designLibrary.read(input));
      if (url.pathname === '/api/design-pipeline' || url.pathname === '/api/design-recipes/compose' || url.pathname === '/api/jev' || url.pathname === '/api/design-skills/select' || url.pathname === '/api/commands/run') {
        if (inferenceRunning || Date.now() - lastInference < 1000) throw new HttpError(429, 'Wait for the current Jev request to finish.');
        inferenceRunning = true;
        lastInference = Date.now();
        try { return json(200, await traces.run(url.pathname, tracedFetch => (url.pathname === '/api/design-pipeline' ? runDesignPhase : url.pathname === '/api/design-recipes/compose' ? composeRecipe : url.pathname === '/api/commands/run' ? runCommand : url.pathname === '/api/jev' ? chooseLayout : selectDesignSkill)(input, { library: designLibrary, tools: shellTools, apiKey, fetchImpl: tracedFetch }), fetchImpl)); }
        finally { inferenceRunning = false; }
      }
      const result = await serial(async () => {
        if (url.pathname === '/api/design') {
          let next;
          try { next = validateDesign(input); } catch (error) { throw new HttpError(400, error.message); }
          await atomicJson(designFile, next);
          selected = next;
          hasKeptDesign = true;
          return { selected, file: 'examples/workbench/selected-design.json' };
        }
        if (url.pathname !== '/api/messages' && url.pathname !== '/api/reset') throw new HttpError(404, 'Not found.');
        if (input.revision !== state.revision) throw new HttpError(409, 'The inbox changed in another tab. Reload its data and try again.');
        const next = structuredClone(state);
        if (url.pathname === '/api/reset') next.messages = seedInbox();
        else {
          const message = next.messages.find(item => item.id === input.id);
          if (!message) throw new HttpError(404, 'Conversation not found.');
          if (input.action === 'draft') {
            if (typeof input.draft !== 'string' || input.draft.length > 10_000) throw new HttpError(400, 'Draft must be at most 10,000 characters.');
            message.draft = input.draft;
          } else if (input.action === 'archive') message.archived = true;
          else if (input.action === 'restore') message.archived = false;
          else if (input.action === 'read') message.unread = false;
          else throw new HttpError(400, 'Unknown inbox action.');
        }
        next.revision++;
        await atomicJson(stateFile, next);
        state = next;
        return state;
      });
      json(200, result);
    } catch (error) {
      json(error.status || 500, { error: error.status ? error.message : 'The local workbench could not save or load data. Check the server and retry.' });
    }
  });
  return server;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const server = await createWorkbenchServer();
  server.listen(Number(process.env.WORKBENCH_PORT || 4182), '127.0.0.1', () => console.log(`Shell workbench: http://127.0.0.1:${server.address().port}`));
}
