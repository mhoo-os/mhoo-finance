import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {Client} from '@modelcontextprotocol/sdk/client/index.js';
import {StdioClientTransport} from '@modelcontextprotocol/sdk/client/stdio.js';
import {createWorkbenchServer} from './server.mjs';
import {createShellTools,runCommand,decideCommand} from './commands.mjs';
import {createTraceStore} from './jev-traces.mjs';
const choice=(value,keys)=>({type:'choice',choice:value,confidence:.95,probabilities:Object.fromEntries(keys.map(k=>[k,k===value?1:0]))});
const answers=()=>({action:choice('shell_preview_layout',['shell_inspect','shell_preview_layout','none']),layout:choice('compact',['split','focus','compact','unspecified']),requested:{type:'noul',noul:.99},outside_scope:{type:'noul',noul:.01}});
const reply=()=>Response.json({model:'stress-fixture',answers:answers(),usage:{input_tokens:1,output_tokens:1}});
async function setup(t,fetchImpl=async()=>reply()){
 const dir=await mkdtemp(join(tmpdir(),'shell-stress-'));const server=await createWorkbenchServer({dataDir:dir,designFile:join(dir,'design.json'),apiKey:'stress-key',fetchImpl});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(async()=>{await new Promise(r=>server.close(r));await rm(dir,{recursive:true,force:true});});
 const origin=`http://127.0.0.1:${server.address().port}`;const {csrf}=await(await fetch(origin+'/api/bootstrap')).json();
 const post=(path,input,extra={})=>fetch(origin+path,{method:'POST',headers:{origin,'content-type':'application/json','x-workbench-token':csrf,...extra},body:JSON.stringify(input)});
 return {origin,post};
}
test('stress: 100 simultaneous CAS writes accept exactly one and keep server responsive',async t=>{
 const {origin,post}=await setup(t);
 const results=await Promise.all(Array.from({length:100},()=>post('/api/tools/call',{name:'shell_preview_layout',arguments:{layout:'compact',expectedRevision:0}})));
 assert.equal(results.filter(r=>r.status===200).length,1);assert.equal(results.filter(r=>r.status===409).length,99);
 assert.deepEqual(await(await fetch(origin+'/api/preview')).json(),{design:{layout:'compact'},revision:1});
});
test('stress: 50 commands during a slow provider make one call, and newer direct change wins',async t=>{
 let release,entered;const started=new Promise(r=>entered=r);let calls=0;
 const {origin,post}=await setup(t,async()=>{calls++;entered();await new Promise(r=>release=r);return reply();});
 const first=post('/api/commands/run',{request:'Preview compact'});await started;
 const burst=await Promise.all(Array.from({length:50},()=>post('/api/commands/run',{request:'Preview compact'})));
 assert.ok(burst.every(r=>r.status===429));assert.equal(calls,1);
 assert.equal((await post('/api/tools/call',{name:'shell_preview_layout',arguments:{layout:'focus',expectedRevision:0}})).status,200);
 release();assert.equal((await first).status,409);
 assert.equal((await(await fetch(origin+'/api/preview')).json()).design.layout,'focus');
});
test('stress: 1000 malformed answer mutations cannot execute',()=>{
 const bad=[null,{},[],NaN,Infinity,-1,2,'1',true];let checked=0;
 for(let i=0;i<1000;i++){
  const a=answers();const k=['action','layout','requested','outside_scope'][i%4];
  if(i%2)a[k]=bad[i%bad.length];else a[k][k==='action'||k==='layout'?'confidence':'noul']=bad[i%bad.length];
  assert.throws(()=>decideCommand(a,{revision:0}),/invalid/);checked++;
 }
 assert.equal(checked,1000);
});
test('stress: inconsistent Choice winner cannot execute',()=>{
 const a=answers();a.action.probabilities={shell_inspect:0,shell_preview_layout:0,none:1};
 assert.throws(()=>decideCommand(a,{revision:0}),/invalid/);
});
test('stress: provider failures and malformed JSON produce no side effects or retries',async()=>{
 for(const mode of ['401','429','500','invalid-json','invalid-answer','network']){
  let calls=0;const tools=createShellTools({layout:'split'});
  await assert.rejects(runCommand({request:'Preview compact'},{tools,apiKey:'test',fetchImpl:async()=>{
   calls++;if(mode==='network')throw Error('offline');if(mode==='invalid-json')return new Response('{');if(mode==='invalid-answer')return Response.json({answers:{}});return new Response('{}',{status:Number(mode)});
  }}));assert.equal(calls,1);assert.equal(tools.snapshot().revision,0);
 }
});
test('stress: body limits, foreign origins and 100 invalid tools cannot mutate state',async t=>{
 const {origin,post}=await setup(t);
 assert.equal((await post('/api/commands/run',{request:'x'.repeat(40000)})).status,413);
 assert.equal((await post('/api/tools/call',{name:'shell_inspect'},{origin:'https://evil.example'})).status,403);
 const results=await Promise.all(Array.from({length:100},(_,i)=>post('/api/tools/call',{name:'unknown-'+i,arguments:{}})));
 assert.ok(results.every(r=>r.status===400));assert.equal((await(await fetch(origin+'/api/preview')).json()).revision,0);
});
test('stress: trace retention stays at twelve after 150 runs and strips configured key',async()=>{
 const traces=createTraceStore({redact:'stress-secret'});
 for(let i=0;i<150;i++)await traces.run('/api/commands/run',async fetcher=>{await fetcher('https://api.typesafe.ai',{body:JSON.stringify({state:'stress-secret',questions:{}})});return {i};},async()=>Response.json({value:'stress-secret'}));
 assert.equal(traces.list().length,12);assert.equal(traces.list()[0].result.i,149);assert.equal(JSON.stringify(traces.list()).includes('stress-secret'),false);
});
test('stress: SDK timeout aborts the provider without changing preview',async()=>{
 const tools=createShellTools({layout:'split'});let aborted=false;
 await assert.rejects(runCommand({request:'Preview compact'},{tools,apiKey:'test',fetchImpl:async(_url,init)=>new Promise((resolve,reject)=>{
  init.signal.addEventListener('abort',()=>{aborted=true;reject(Error('aborted'));},{once:true});
 })}),/evaluation failed/);
 assert.equal(aborted,true);assert.equal(tools.snapshot().revision,0);
});

test('stress: 100 concurrent MCP reads and 50 competing MCP writes preserve revision semantics',async t=>{
 const {origin}=await setup(t);const port=new URL(origin).port;
 const client=new Client({name:'stress-mcp',version:'1'});
 await client.connect(new StdioClientTransport({command:process.execPath,args:[new URL('./mcp.mjs',import.meta.url).pathname],env:{WORKBENCH_PORT:port},stderr:'pipe'}));t.after(()=>client.close());
 const reads=await Promise.all(Array.from({length:100},()=>client.callTool({name:'shell_inspect',arguments:{}})));
 assert.ok(reads.every(r=>!r.isError&&JSON.parse(r.content[0].text).revision===0));
 const writes=await Promise.all(Array.from({length:50},()=>client.callTool({name:'shell_preview_layout',arguments:{layout:'focus',expectedRevision:0}})));
 assert.equal(writes.filter(r=>!r.isError).length,1);assert.equal(writes.filter(r=>r.isError).length,49);
});

test('stress: a high confidence field cannot override a flat choice distribution',()=>{
 const a=answers();a.layout.probabilities={compact:.26,focus:.25,split:.25,unspecified:.24};
 assert.equal(decideCommand(a,{revision:0}).status,'not_executed');
});
