import {test} from 'node:test';
import assert from 'node:assert/strict';
import {codexProvider} from './codex-provider.mjs';
const config={CODEX_LB_BASE_URL:'https://provider.example/v1',CODEX_LB_API_KEY:'fixture-secret'};
const models=(ids=['gpt-6-astra'])=>Response.json({object:'list',data:ids.map(id=>({id,object:'model'}))});
const visual={route:{task:'visual-design'},messages:[{role:'user',content:'test'}],max_tokens:100};
test('codex adapter discovers the catalog, routes visual work to Astra, and normalizes chat response',async()=>{
 let observed;
 const provider=codexProvider(config,async(url,init)=>{
  if(String(url).endsWith('/models'))return models(['gpt-5.6-terra','gpt-6-astra']);
  observed={url:String(url),...init};return Response.json({model:'gpt-6-astra',choices:[{message:{content:'<html></html>'}}],usage:{total_tokens:20}});
 });
 const r=await provider.run('ignored-qwen',visual);
 assert.equal(observed.url,'https://provider.example/v1/chat/completions');
 const request=JSON.parse(observed.body);assert.equal(request.model,'gpt-6-astra');assert.equal(request.reasoning_effort,'high');
 assert.equal(observed.redirect,'manual');assert.equal(r.model,'gpt-6-astra');assert.equal(r.response,'<html></html>');assert.equal(r.settings.route,'visual-design');assert.equal(r.settings.routingSource,'discovered-policy');
});
test('missing credentials, unsafe origins and redirects never invoke fallback',async()=>{
 let calls=0;const mock=async()=>{calls++;return new Response('',{status:302});};
 await assert.rejects(codexProvider({},mock).run('',visual),/Configure/);
 await assert.rejects(codexProvider({...config,CODEX_LB_BASE_URL:'http://provider.example'},mock).run('',visual),/HTTPS/);
 assert.equal(calls,0);
 await assert.rejects(codexProvider(config,mock).run('',visual),/discovery.*HTTP 302/);assert.equal(calls,1);
});
test('missing route is rejected and unavailable Astra never falls back',async()=>{
 let calls=0;const mock=async()=>{calls++;return models(['gpt-5.6-sol','gpt-5.6-terra']);};
 await assert.rejects(codexProvider(config,mock).run('',{...visual,route:undefined}),/known task/);
 assert.equal(calls,0);
 await assert.rejects(codexProvider(config,mock).run('',visual),/No approved.*visual-design/);
 assert.equal(calls,1);
});
test('one provider instance reuses its validated catalog without global request state',async()=>{
 let discoveries=0,completions=0;
 const provider=codexProvider(config,async url=>{if(String(url).endsWith('/models')){discoveries++;return models();}completions++;return Response.json({choices:[{message:{content:'ok'}}]});});
 await provider.run('',visual);await provider.run('',visual);
 assert.equal(discoveries,1);assert.equal(completions,2);
});
test('streaming completion survives split events and retains usage',async()=>{
 const wire='data: '+JSON.stringify({model:'resolved',choices:[{delta:{content:'<html>é</html>'}}]})+'\r\n\r\ndata: '+JSON.stringify({choices:[{delta:{},finish_reason:'stop'}],usage:{total_tokens:8}})+'\r\n\r\ndata: [DONE]\r\n\r\n';
 const bytes=new TextEncoder().encode(wire);
 const response=()=>new Response(new ReadableStream({start(controller){for(const byte of bytes)controller.enqueue(new Uint8Array([byte]));controller.close();}}),{headers:{'content-type':'text/event-stream'}});
 const progress=[];
 const result=await codexProvider(config,async(url,init)=>{if(String(url).endsWith('/models'))return models();assert.equal(JSON.parse(init.body).stream,true);return response();},async value=>progress.push(value)).run('',visual);
 assert.equal(result.response,'<html>é</html>');assert.equal(result.model,'resolved');assert.equal(result.usage.total_tokens,8);assert.equal(progress[0].status,'waiting');assert.equal(progress.at(-1).characters,14);assert.equal(progress.at(-1).status,'received');
});
test('truncated streams and provider stream errors fail instead of accepting partial HTML',async()=>{
 for(const wire of ['data: {"choices":[{"delta":{"content":"partial"}}]}\n\n','data: {"error":{"message":"private upstream detail"}}\n\n']){
  await assert.rejects(codexProvider(config,async url=>String(url).endsWith('/models')?models():new Response(wire,{headers:{'content-type':'text/event-stream'}})).run('',visual),/Codex-lb/);
 }
});
