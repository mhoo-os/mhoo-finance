import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { ListToolsRequestSchema, CallToolRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { toolDefinitions } from './commands.mjs';
const port=Number(process.env.WORKBENCH_PORT||4183);
if(!Number.isInteger(port)||port<1||port>65535)throw Error('Invalid workbench port.');
const origin=`http://127.0.0.1:${port}`;
const commandSchema={type:'object',properties:{request:{type:'string',minLength:1,maxLength:4000}},required:['request'],additionalProperties:false};
const server=new Server({name:'shell-workbench',version:'0.1.0'},{capabilities:{tools:{}}});
server.setRequestHandler(ListToolsRequestSchema,async()=>({tools:[...toolDefinitions,
  {name:'shell_command',description:'Use Jev to evaluate a request and execute a supported Shell inspect or reversible layout-preview action. Requires the local server API key.',inputSchema:commandSchema},
  {name:'shell_command_preview',description:'Inspect the decomposed questions and policy without calling Jev or executing a tool.',inputSchema:commandSchema},
]}));
server.setRequestHandler(CallToolRequestSchema,async({params})=>{
 try {
  if(![...toolDefinitions.map(t=>t.name),'shell_command','shell_command_preview'].includes(params.name))throw Error('Unknown Shell tool.');
  const bootstrap=await fetch(origin+'/api/bootstrap',{signal:AbortSignal.timeout(5000)});if(!bootstrap.ok)throw Error('Local Shell server unavailable.');
  const {csrf}=await bootstrap.json();
  const path=params.name==='shell_command'?'/api/commands/run':params.name==='shell_command_preview'?'/api/commands/preview':'/api/tools/call';
  const body=path==='/api/tools/call'?{name:params.name,arguments:params.arguments||{}}:params.arguments||{};
  const response=await fetch(origin+path,{method:'POST',headers:{origin,'content-type':'application/json','x-workbench-token':csrf},body:JSON.stringify(body),signal:AbortSignal.timeout(25000)});
  const value=await response.json();return {isError:!response.ok,content:[{type:'text',text:JSON.stringify(value)}]};
 }catch{return {isError:true,content:[{type:'text',text:'Shell tool request failed. Check that the local server is running and the tool arguments are valid.'}]};}
});
await server.connect(new StdioServerTransport());
