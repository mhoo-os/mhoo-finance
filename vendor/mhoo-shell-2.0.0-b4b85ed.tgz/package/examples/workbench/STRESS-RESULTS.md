# Shell command stress test — 2026-09-22

Scope: local command dispatcher, HTTP protection/concurrency, TypeSafe SDK failure
behavior, stdio MCP bridge and bounded trace history. Tests use isolated temporary
stores and ephemeral ports. No real messages, commits or external tool actions.
Provider results are fixtures, not live Jev judgments.

| Scenario | Observed result |
|---|---|
| 100 simultaneous HTTP previews with revision0 | 1 accepted;99 conflict;final revision1 |
| 50 commands while a provider call is pending | All50 rate-limited;only1 provider call |
| New direct preview during model evaluation | Older result rejected409;newer focus layout retained |
| 1,000 malformed answer mutations | All rejected;bounded repeating mutation set, not1,000 unique semantic cases |
| Choice names winner but probabilities favor none | Initially accepted incorrectly;fixed;regression now rejects |
| Provider401/429/500, invalid JSON/answers, network failure | No handler execution;1 attempt each |
| Provider stalls | Aborted at15,002ms;preview revision unchanged |
| Oversized request / foreign Origin | Rejected413 /403 |
| 100 unknown tool calls | All rejected400;state unchanged |
| 150 recorded runs | Only newest12 retained;configured secret absent |
| 100 concurrent stdio MCP reads | All succeeded with expected revision |
| 50 competing stdio MCP previews | 1 accepted;49 errors |

The full workbench suite passed26tests, followed by the newly added MCP concurrency
test passing separately (27 distinct passing tests in total). Timing describes
this local run, not a throughput/service-level benchmark. The provider timeout
was exercised at the configured15-second limit. Existing tests cover draft
preservation while remote previews change and late layout results are discarded.

## Fix

`commands.mjs` already validated choice membership, probability range/sum and
confidence bounds. It now also requires the reported choice to have maximal
probability, as specified by the TypeSafe Choice response contract. Ties remain
valid. No probability/confidence formula is invented by the validator.

## Remaining evaluation

Port4182 has a key but lacks the command API;4183 has the command API but no key.
No real Jev stress requests were made, no live accuracy measured, and no claim is
made that semantic gates prevent all misinterpretations or prompt injection.
Next model evaluation should cover literal commands, negation, quoted commands,
conflicting preferences, unfamiliar phrasing and requests beyond the two tools.
The current heuristic thresholds remain provisional. No long-duration soak,
distributed load, browser-crash recovery or hosted multi-user test was performed.

Run the suite with `node --test examples/workbench/stress.test.mjs` (about15s,
including the real SDK timeout). The standard workbench test command includes it.

Review follow-up: confidence is derived from a distribution, not identical to the
selected probability, so no equality formula is enforced. Added an explicit .65
selected-probability floor alongside the .65confidence floor for executable action
and layout choices. A flat distribution with a fabricated high confidence now
returns not_executed. This is additional provisional policy, not a calibration
claim. Its regression test passes separately (28 distinct tests total).
