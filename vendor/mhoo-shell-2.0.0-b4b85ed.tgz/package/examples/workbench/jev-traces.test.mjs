import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createTraceStore } from './jev-traces.mjs';
test('traces capture actual bodies, redact credentials, retain errors and bound history', async () => {
  const store=createTraceStore({limit:2,redact:'secret-value'});
  const fetchImpl=async()=>Response.json({choice:'a',echo:'secret-value'});
  const invoke=async fetcher=>{const response=await fetcher('https://api.typesafe.ai/v1/systemone',{headers:{authorization:'Bearer secret-value'},body:JSON.stringify({state:{brief:'hello'},questions:{}})});return {answer:await response.json()};};
  const result=await store.run('/api/design-skills/select',invoke,fetchImpl);
  assert.ok(result.traceId); const [trace]=store.list();assert.equal(trace.status,'complete');assert.equal(trace.steps[0].request.state.brief,'hello');
  assert.equal(JSON.stringify(trace).includes('secret-value'),false);assert.equal(JSON.stringify(trace).includes('authorization'),false);
  await assert.rejects(store.run('/fail',async()=>{throw Object.assign(Error('No key'),{status:503});},fetchImpl));
  assert.equal(store.list()[0].error,'No key');
  await store.run('/next',async()=>({source:'explicit'}),fetchImpl);assert.equal(store.list().length,2);
});
