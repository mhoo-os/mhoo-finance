import {JevError} from '../workbench/jev.mjs';
export async function digest(text){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),b=>b.toString(16).padStart(2,'0')).join('');}
export async function storeArtifact(record,bucket,owner){
 if(typeof record.result?.html!=='string')return record;
 if(!bucket)throw new JevError('Artifact storage is not configured.',503);
 const {html,raw,...rest}=record.result;
 const sha256=await digest(html),bytes=new TextEncoder().encode(html).length;
 const key=`${await digest(owner)}/${record.id}/${sha256}.json`;
 await bucket.put(key,JSON.stringify({html,raw}),{httpMetadata:{contentType:'application/json'}});
 return {...record,result:{...rest,artifact:{storage:'R2',key,sha256,bytes,mimeType:'text/html'}}};
}
export async function readArtifact(db,bucket,owner,id){
 const row=await db.prepare('SELECT record FROM runs WHERE id=? AND owner=?').bind(id,owner).first();
 if(!row)throw new JevError('Artifact not found.',404);
 const record=JSON.parse(row.record),meta=record.result?.artifact;
 let html=record.result?.html,raw=record.result?.raw;
 if(meta){
  if(!bucket)throw new JevError('Artifact storage is not configured.',503);
  const object=await bucket.get(meta.key);if(!object)throw new JevError('Stored artifact is unavailable.',503);
  const payload=await object.json();html=payload.html;raw=payload.raw;
  if(typeof html!=='string'||await digest(html)!==meta.sha256)throw new JevError('Artifact integrity check failed.',502);
 }
 if(typeof html!=='string')throw new JevError('No HTML artifact for this run.',404);
 return {record,html,raw,sha256:meta?.sha256||await digest(html),storage:meta?'R2':'D1 legacy'};
}
