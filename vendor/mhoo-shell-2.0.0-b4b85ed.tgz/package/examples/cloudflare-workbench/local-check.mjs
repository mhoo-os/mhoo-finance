// Against a running LOCAL_DEV Pages worker. No TypeSafe credential or provider calls.
import assert from 'node:assert/strict';
const base=process.env.WORKBENCH_URL||'http://127.0.0.1:4183';
const bootstrap=await (await fetch(base+'/api/bootstrap')).json();assert.equal(bootstrap.history.durable,true);
async function post(path,body){const response=await fetch(base+path,{method:'POST',headers:{origin:base,'content-type':'application/json','x-workbench-token':bootstrap.csrf},body:JSON.stringify(body)});return {status:response.status,body:await response.json()};}
const ids=[];for(let i=0;i<30;i++){const r=await post('/api/tools/call',{name:'shell_inspect',arguments:{}});assert.equal(r.status,200);ids.push(r.body.traceId);}
const first=await post('/api/jev/traces',{limit:12});assert.equal(first.body.traces.length,12);assert.ok(first.body.nextCursor);
let all=[],before;do{const page=await post('/api/jev/traces',{limit:12,...(before?{before}:{})});assert.equal(page.status,200);all.push(...page.body.traces);before=page.body.nextCursor;}while(before);assert.ok(ids.every(id=>all.some(r=>r.id===id)));assert.equal(new Set(all.map(r=>r.id)).size,all.length);
const failed=await post('/api/commands/run',{request:''});assert.equal(failed.status,400);assert.equal((await post('/api/jev/traces',{})).body.traces[0].status,'failed');
const current=await (await fetch(base+'/api/preview')).json();const simultaneous=await Promise.all(['compact','focus'].map(layout=>post('/api/tools/call',{name:'shell_preview_layout',arguments:{layout,expectedRevision:current.revision}})));assert.deepEqual(simultaneous.map(r=>r.status).sort(),[200,409]);
const evaluated=await post('/api/jev/evaluate',{id:ids.at(-1),verdict:'pass',expected:'Read layout',notes:'Local persistence check; no model call.'});assert.equal(evaluated.status,200);
const updated=await post('/api/jev/traces',{});assert.equal(updated.body.traces.find(r=>r.id===ids.at(-1)).evaluation.verdict,'pass');
const exported=await fetch(base+'/api/jev/export',{method:'POST',headers:{origin:base,'content-type':'application/json','x-workbench-token':bootstrap.csrf},body:'{"limit":100}'});assert.equal(exported.status,200);assert.ok((await exported.text()).split('\n').filter(Boolean).map(JSON.parse).some(r=>r.id===ids[0]));
assert.equal((await fetch(base+'/_skills/frontend-design/SKILL.md')).status,404);
assert.equal((await fetch(base+'/api/tools/call',{method:'POST',headers:{'content-type':'application/json'},body:'{}'})).status,403);
console.log(JSON.stringify({passed:true,persistedRuns:all.length,checks:['30 runs retained','cursor pagination','failure retained','revision race','evaluation saved','JSONL export','private assets denied','CSRF denied'],restartWitness:ids[0]}));
