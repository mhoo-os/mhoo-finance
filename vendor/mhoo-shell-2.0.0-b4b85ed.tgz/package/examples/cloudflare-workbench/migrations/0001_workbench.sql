CREATE TABLE IF NOT EXISTS runs (
 seq INTEGER PRIMARY KEY AUTOINCREMENT,
 id TEXT NOT NULL UNIQUE,
 owner TEXT NOT NULL,
 started_at TEXT NOT NULL,
 status TEXT NOT NULL,
 record TEXT NOT NULL CHECK(json_valid(record))
);
CREATE INDEX IF NOT EXISTS runs_owner_seq ON runs(owner,seq DESC);
CREATE TABLE IF NOT EXISTS evaluations (
 run_id TEXT PRIMARY KEY REFERENCES runs(id),
 owner TEXT NOT NULL,
 verdict TEXT NOT NULL CHECK(verdict IN ('pass','fail','unreviewed')),
 expected TEXT NOT NULL DEFAULT '',
 notes TEXT NOT NULL DEFAULT '',
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS workspace (
 owner TEXT PRIMARY KEY,
 revision INTEGER NOT NULL DEFAULT 0,
 preview TEXT NOT NULL,
 inbox TEXT NOT NULL,
 kept TEXT
);
CREATE TABLE IF NOT EXISTS tool_events (
 id TEXT PRIMARY KEY,
 owner TEXT NOT NULL,
 run_id TEXT,
 tool TEXT NOT NULL,
 arguments TEXT NOT NULL,
 result TEXT NOT NULL,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS inference_leases (
 owner TEXT PRIMARY KEY,
 holder TEXT NOT NULL,
 expires INTEGER NOT NULL
);
