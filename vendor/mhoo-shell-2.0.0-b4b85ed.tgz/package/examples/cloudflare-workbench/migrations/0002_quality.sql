CREATE TABLE IF NOT EXISTS quality_evaluations (
 id TEXT PRIMARY KEY,
 owner TEXT NOT NULL,
 run_id TEXT NOT NULL REFERENCES runs(id),
 artifact_hash TEXT NOT NULL,
 result TEXT NOT NULL CHECK(json_valid(result)),
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS quality_owner_run ON quality_evaluations(owner,run_id,created_at DESC);
