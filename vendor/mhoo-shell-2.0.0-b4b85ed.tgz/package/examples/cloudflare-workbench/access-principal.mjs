// Call only after jwtVerify has checked signature, issuer, audience and expiry.
// Machine credentials never impersonate a human subject or apply on another host.
export function accessPrincipal(payload, env, hostname) {
  let previewHost;
  if (env.PREVIEW_REQUIRE_ACCESS === 'true') {
    try {
      const origin = new URL(env.PUBLIC_ORIGIN);
      if (origin.protocol === 'https:' && origin.pathname === '/' && !origin.username && !origin.password && !origin.search && !origin.hash) previewHost = origin.hostname;
    } catch { /* no preview host */ }
  }
  if ((hostname === 'mhoo.dev' || (previewHost && hostname === previewHost)) && payload?.email === 'tanyawit@mhoooo.com'
    && typeof payload?.sub === 'string' && payload.sub) return payload.sub;
  const allowed = env.BKK_AGENT_CLIENT_ID;
  if (hostname === 'mhoo.dev' && typeof allowed === 'string' && allowed.endsWith('.access')
    && payload?.sub === '' && payload?.common_name === allowed) return `service:${allowed}`;
  return null;
}
