import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {Miniflare,convertV4MiniflareOptions} from 'miniflare';
import {runStore,shellTools,workspace,lease} from './store.mjs';
test('D1 isolates owners and exposes atomic execution evidence on unfinished runs',async()=>{
 const mf=new Miniflare(convertV4MiniflareOptions({modules:true,script:'export default {fetch(){return new Response("ok")}}',compatibilityDate:'2026-09-22',d1Databases:['DB'],r2Buckets:['ARTIFACTS']}));
 try{const db=await mf.getD1Database('DB');const sql=await readFile(new URL('./migrations/0001_workbench.sql',import.meta.url),'utf8');await db.batch(sql.split(';').map(s=>s.trim()).filter(Boolean).map(s=>db.prepare(s)));
 const a=runStore(db,'alice'),b=runStore(db,'bob');const record={id:'run-1',startedAt:new Date().toISOString(),status:'running',steps:[],input:{request:'preview compact'}};await a.put(record);
 await workspace(db,'alice');await shellTools(db,'alice','run-1').call('shell_preview_layout',{layout:'compact',expectedRevision:0});
 const page=await a.list();assert.equal(page.traces[0].status,'running');assert.equal(page.traces[0].toolEvents[0].result.revision,1);assert.equal((await b.list()).traces.length,0);
 await assert.rejects(b.evaluate({id:'run-1',verdict:'pass',expected:'',notes:''}),e=>e.status===404);
 await a.linkWorkflow({id:'workflow-1',title:'Fixture workflow',traceIds:['run-1']});
 assert.equal((await a.list({workflowId:'workflow-1'})).traces[0].workflow.stageIndex,0);
 assert.equal((await b.list({workflowId:'workflow-1'})).traces.length,0);
 await assert.rejects(b.linkWorkflow({id:'workflow-1',title:'Fixture',traceIds:['run-1']}),e=>e.status===404);
 await assert.rejects(a.linkWorkflow({id:'another',title:'Fixture',traceIds:['run-1']}),e=>e.status===409);
 await lease(db,'alice','holder-a');await assert.rejects(lease(db,'alice','holder-b'),e=>e.status===429);await lease(db,'bob','holder-b');
 await assert.rejects(shellTools(db,'alice','run-1').call('shell_preview_layout',{layout:'focus',expectedRevision:0}),e=>e.status===409);assert.equal((await a.list()).traces[0].toolEvents.length,1);
 }finally{await mf.dispose();}
});
test('cloud URLs cannot use the loopback identity and missing Access fails closed',async()=>{
 const {default:worker}=await import('./dist/_worker.js');
 assert.equal((await worker.fetch(new Request('https://public.example/api/bootstrap'),{LOCAL_DEV:'true'})).status,503);
 assert.equal((await worker.fetch(new Request('https://public.example/api/bootstrap'),{ACCESS_TEAM_DOMAIN:'team.cloudflareaccess.com',ACCESS_AUD:'aud'})).status,401);
});
test('artifact route isolates owners and sandboxes generated HTML',async()=>{
 const {default:worker}=await import('./dist/_worker.js');
 const mf=new Miniflare(convertV4MiniflareOptions({modules:true,script:'export default {fetch(){return new Response("ok")}}',compatibilityDate:'2026-09-22',d1Databases:['DB'],r2Buckets:['ARTIFACTS']}));
 try{
  const db=await mf.getD1Database('DB');
  const sql=await readFile(new URL('./migrations/0001_workbench.sql',import.meta.url),'utf8');
  await db.batch(sql.split(';').map(s=>s.trim()).filter(Boolean).map(s=>db.prepare(s)));
  const html='<h1>Generated design</h1><script>document.title="preview"</script>';
  for(const [id,owner,result] of [['mine','local-owner',{html}],['private','another-owner',{html}],['decision','local-owner',{}]]){
   await runStore(db,owner,await mf.getR2Bucket('ARTIFACTS')).put({id,startedAt:new Date().toISOString(),status:'complete',steps:[],input:{},result});
  }
  const get=async id=>worker.fetch(new Request(`http://localhost/api/artifact?id=${id}`),{LOCAL_DEV:'true',DB:db,ARTIFACTS:await mf.getR2Bucket('ARTIFACTS')});
  const response=await get('mine');
  assert.equal(response.status,200);
  assert.equal(await response.text(),html);
  assert.equal(response.headers.get('cache-control'),'no-store');
  assert.equal(response.headers.get('x-content-type-options'),'nosniff');
  const csp=response.headers.get('content-security-policy');
  assert.match(csp,/default-src 'none'/);
  assert.match(csp,/sandbox allow-scripts/);
  assert.doesNotMatch(csp,/allow-same-origin/);
  assert.match(csp,/form-action 'none'/);
  for(const id of ['private','missing','decision'])assert.equal((await get(id)).status,404);
 }finally{await mf.dispose();}
});
