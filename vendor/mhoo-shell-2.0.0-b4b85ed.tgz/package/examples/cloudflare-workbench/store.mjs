import {storeArtifact} from './artifacts.mjs';
import {validateDesign,defaultDesign} from '../workbench/config.js';
import {seedInbox} from '../workbench/seed.js';
import {JevError} from '../workbench/jev.mjs';
export async function workspace(db,owner){
 await db.prepare('INSERT OR IGNORE INTO workspace(owner,preview,inbox) VALUES(?,?,?)').bind(owner,JSON.stringify(defaultDesign),JSON.stringify({revision:0,messages:seedInbox()})).run();
 return db.prepare('SELECT * FROM workspace WHERE owner=?').bind(owner).first();
}
export function runStore(db,owner,bucket){return {
 async put(r){if(r.status==='complete'&&typeof r.result?.html==='string')r=await storeArtifact(r,bucket,owner);await db.prepare('INSERT INTO runs(id,owner,started_at,status,record) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,record=excluded.record WHERE runs.owner=excluded.owner').bind(r.id,owner,r.startedAt,r.status,JSON.stringify(r)).run();},
 async list({before,limit=25,workflowId}={}){
  if(!Number.isInteger(limit)||limit<1||limit>100||before!==undefined&&(!Number.isSafeInteger(before)||before<1))throw new JevError('Invalid history cursor or limit.',400);
  if(workflowId!==undefined&&(typeof workflowId!=='string'||!/^[-a-zA-Z0-9_]{1,100}$/.test(workflowId)))throw new JevError('Invalid workflow id.',400);
  const rows=await db.prepare(`SELECT r.seq,r.record,e.verdict,e.expected,e.notes,e.updated_at, (SELECT json_group_array(json_object('id',t.id,'tool',t.tool,'arguments',json(t.arguments),'result',json(t.result),'createdAt',t.created_at)) FROM tool_events t WHERE t.run_id=r.id AND t.owner=r.owner) AS events FROM runs r LEFT JOIN evaluations e ON e.run_id=r.id AND e.owner=r.owner WHERE r.owner=? AND r.seq<? AND (? IS NULL OR json_extract(r.record,'$.workflow.id')=?) ORDER BY r.seq DESC LIMIT ?`).bind(owner,before??Number.MAX_SAFE_INTEGER,workflowId??null,workflowId??null,limit+1).all();
  const page=rows.results.slice(0,limit);
  return {traces:page.map(r=>({...JSON.parse(r.record),toolEvents:JSON.parse(r.events||'[]'),evaluation:r.verdict?{verdict:r.verdict,expected:r.expected,notes:r.notes,updatedAt:r.updated_at}:null})),nextCursor:rows.results.length>limit?page.at(-1).seq:null};
 },
 async linkWorkflow({id,title,traceIds}={}){
  if(typeof id!=='string'||!/^[-a-zA-Z0-9_]{1,100}$/.test(id)||typeof title!=='string'||!title.length||title.length>160||!Array.isArray(traceIds)||!traceIds.length||traceIds.length>100||traceIds.some(v=>typeof v!=='string')||new Set(traceIds).size!==traceIds.length)throw new JevError('Invalid workflow link.',400);
  const rows=await db.batch(traceIds.map(traceId=>db.prepare('SELECT record FROM runs WHERE id=? AND owner=?').bind(traceId,owner)));
  if(rows.some(row=>!row.results.length))throw new JevError('Run not found.',404);
  if(rows.some(row=>{const w=JSON.parse(row.results[0].record).workflow;return w&&w.id!==id;}))throw new JevError('Run already belongs to another workflow.',409);
  await db.batch(traceIds.map((traceId,stageIndex)=>db.prepare("UPDATE runs SET record=json_set(record,'$.workflow',json(?)) WHERE id=? AND owner=?").bind(JSON.stringify({id,title,stageIndex}),traceId,owner)));
  return {linked:traceIds.length,id};
 },
 async evaluate(input){
  if(!input||typeof input.id!=='string'||!['pass','fail','unreviewed'].includes(input.verdict)||typeof input.expected!=='string'||typeof input.notes!=='string'||input.expected.length>4000||input.notes.length>4000)throw new JevError('Invalid evaluation.',400);
  const result=await db.prepare('INSERT INTO evaluations(run_id,owner,verdict,expected,notes,updated_at) SELECT id,owner,?,?,?,? FROM runs WHERE id=? AND owner=? ON CONFLICT(run_id) DO UPDATE SET verdict=excluded.verdict,expected=excluded.expected,notes=excluded.notes,updated_at=excluded.updated_at').bind(input.verdict,input.expected,input.notes,new Date().toISOString(),input.id,owner).run();
  if(!result.meta.changes)throw new JevError('Run not found.',404);return {saved:true};
 }
};}
export function shellTools(db,owner,runId=null){return {
 async snapshot(){const row=await workspace(db,owner);return {design:JSON.parse(row.preview),revision:row.revision};},
 async call(name,args={}){
  if(!args||typeof args!=='object'||Array.isArray(args))throw new JevError('Invalid arguments.',400);
  if(name==='shell_inspect'&&!Object.keys(args).length)return this.snapshot();
  if(name!=='shell_preview_layout'||Object.keys(args).some(k=>!['layout','expectedRevision'].includes(k))||!Number.isSafeInteger(args.expectedRevision)||args.expectedRevision<0)throw new JevError('Unknown tool or invalid arguments.',400);
  let design;try{design=validateDesign({layout:args.layout});}catch{throw new JevError('Unsupported layout.',400);}
  const result={design,revision:args.expectedRevision+1};
  const changes=await db.batch([
   db.prepare('UPDATE workspace SET preview=?,revision=revision+1 WHERE owner=? AND revision=? RETURNING revision').bind(JSON.stringify(design),owner,args.expectedRevision),
   db.prepare('INSERT INTO tool_events(id,owner,run_id,tool,arguments,result,created_at) SELECT ?,?,?,?,?,?,? WHERE changes()=1').bind(crypto.randomUUID(),owner,runId,name,JSON.stringify(args),JSON.stringify(result),new Date().toISOString()),
  ]);
  if(!changes[0].results.length)throw new JevError('Preview changed during this decision. Inspect and retry.',409);
  return result;
 }
};}
export async function lease(db,owner,id){
 const now=Date.now();const r=await db.prepare('INSERT INTO inference_leases(owner,holder,expires) VALUES(?,?,?) ON CONFLICT(owner) DO UPDATE SET holder=excluded.holder,expires=excluded.expires WHERE inference_leases.expires<? RETURNING holder').bind(owner,id,now+360000,now).all();
 if(!r.results.length)throw new JevError('A Jev request is already running.',429);
}
