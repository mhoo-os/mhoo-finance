# Workbench quality review — 2026-09-23

## My assessment

**5/10 as a product workbench; 7/10 as an internal experiment/inspection tool.**
The most valuable progress is now real: a generated app, durable evidence,
clickable workflow stages, streaming progress, content-addressed artifacts and
saved quality judgments. The user still cannot simply describe, generate,
compare and iterate an installed app through one coherent experience. Additional
model workers or storage services alone will not close that gap.

The current Codex app is more coherent than the older Qwen outputs, but this is
not a controlled attribution of the improvement to skills, reference selection,
model, or prompting. The historic B output is not an obvious win over A.

## Jev page review

One live Jev batch judged ten distinct surfaces using browser-derived text
observations. Aliases `/jev` and mounted `/00/shell/` share the corresponding
current surface and are not independent designs. Exact source and responses:
`.workbench/audit/pages.json` and `jev-page-review.json`.

Jev received **text observations, not screenshots**. Scores use explicit ordered
0–4 rubric levels multiplied by 2.5 for display. They are provisional subjective
judgments, not calibrated benchmarks or probability of correctness. Task and
visual dimensions are separate; no overall arithmetic average is a release gate.

| Surface | Task usefulness /10 | Visual composition /10 |
|---|---:|---:|
| Shell empty workspace | 2.7 | 7.5 |
| Observer execution and workflow | 6.3 | 4.9 |
| Output inspector | 5.8 | 4.0 |
| Preview canvas and generated Codex app | 7.0 | 7.5 |
| Artifact quality evaluation | 5.4 | 4.8 |
| Legacy pipeline viewer | 7.1 | 6.0 |
| Legacy Qwen output | 5.0 | 4.4 |
| Legacy A/B comparison landing | 2.4 | 4.6 |
| Historical A output | 4.2 | 5.1 |
| Historical B output | 4.0 | 5.0 |

## Artifact-specific evaluation

The quality panel performed a separate live evaluation against the actual
self-contained decision-log brief, with source and browser observations:
functionality **8.1**, usability **7.6**, visual **7.5** out of ten. This differs
from the page review's task-usefulness rubric, which also considers the surrounding
preview workbench. Do not substitute one score for the other.

Tests observed: combined Bob/Needs review filtering, Enter opening rationale and
alternatives, Escape closing, no-match state, Clear search, all six records,
programmatic labels, mobile repeated field labels and no horizontal overflow
(content viewport/document both 388px within the 390px outer frame). Shell and
observer document widths were also measured at 390px without overflow.

Remaining artifact defect: Needs review badge text overflows at a narrow desktop
embedded width; expanded desktop fits. Unknown: screen-reader experience,
measured contrast, every record interaction, and other browsers. Raw output was
preserved rather than silently repaired before scoring.

## Findings in priority order

1. **Finish the user loop.** Shell's empty state has no actual create/install
   action. Chat opens Observer in a new tab; its label misrepresents the action.
   A working build/iterate path and version comparison matter more than adding
   more Jev instances.
2. **Make evaluation evidence cheaper.** The new evaluator works, but observations
   are manually authored. Capture repeatable interaction results and screenshot
   references per artifact hash, then use Jev for narrowly scoped judgments.
3. **Make evidence readable.** Observer has duplicated workflow/run hierarchy,
   tiny labels, raw JSON walls, and no history search or version diff. Its
   functionality is ahead of its usability and visual craft.
4. **Consolidate experiment entry points.** The A/B landing only links to outputs
   and cannot record preference. The legacy pipeline is clearer at a glance but
   isolated on another port. Integrate useful comparison behavior into Observer.
5. **Strengthen reference selection.** Current recipes mostly synthesize text
   guidance and a few component patterns. Rich media/reference retrieval, when
   appropriate for the brief, is still absent. More workers won't supply taste
   without relevant references and human preference evidence.

## Delivery verification

- R2 bucket `mhoo-shell-artifacts` created remotely, private by default.
- Exact HTML and original raw response uploaded and downloaded from remote R2.
- HTML SHA-256: `107d982f1c490048d0424e7032aa06ff62d7b5535457dafd61c73de141cd245b`.
- Local workerd uses persistent local R2; generated artifact moved out of D1;
  owner-scoped metadata and evaluation history remain in D1.
- Local restart retained the artifact and the saved evaluation; hash matched.
- Browser verified R2 rendering and Load artifact source output.
- Runtime source readback contains HTML, original raw response, hash and R2 label.
- Automated tests cover isolation, corruption, upload failures, validated quality
  scores, evidence requirements, workflow ownership and streaming progress.

The production Worker binding and quality migration are prepared in source but
**not deployed/applied remotely**. The remote bucket/object test does not claim a
production end-to-end deployment. No checkpoint commit or release was made.

## Screenshots

![R2-backed preview](../../.workbench/screenshots/deliverable-r2-preview.png)
![Artifact evaluation](../../.workbench/screenshots/deliverable-quality-evaluation.png)
