# Shell on Cloudflare

Production is one Worker with static assets: `mhoo-shell-workbench`.

- App: https://mhoo.dev/00/shell/
- Inspector: https://mhoo.dev/00/shell/jev
- Production config: `wrangler.worker.jsonc`
- Deploy: `npm run cloudflare:deploy` from the repository root.

The Worker serves the app, API, inspector, and verified design resources. The shared Cloudflare Access application protects `/00` and its child routes. This Worker independently verifies that application's JWT and limits human access to the primary owner email. D1 database `mhoo-shell-workbench` retains inbox state, previews, runs, evaluations, and tool events. Workers.dev and preview URLs are disabled. The old gateway Worker and Pages project were deleted after verifying the direct Worker route. The existing landing site and Email Hub routes are unchanged.

Production receives `CSRF_SECRET`, `TYPESAFE_API_KEY`, and `CODEX_LB_API_KEY` as encrypted Worker secrets; `CODEX_LB_BASE_URL` is non-secret configuration. Inspect only secret names with `wrangler secret list --config examples/cloudflare-workbench/wrangler.worker.jsonc`; update credentials with `wrangler secret put`. Cloud secrets are not copied into local development. Never put secret values in code, frontend assets, or tracked configuration. Native Cloudflare Workers Builds is configured to track `main` in `mhoo-os/mhoo-shell`. The build restores pinned design resources and runs tests before deploying. Every push to main is checked before production deployment.

## Local development

`npm run workbench` runs migrations and the existing local Pages emulator at http://127.0.0.1:4183. Its configuration is `wrangler.jsonc`; it creates no cloud Pages project. Put local-only values such as `TYPESAFE_API_KEY="..."` in `examples/cloudflare-workbench/.dev.vars`; `.dev.vars*` is gitignored. Its local D1 data stays under `.wrangler/state`. The Node example is available as `npm run workbench:legacy` and needs the key in its process environment or an explicit `node --env-file=...` invocation. Production deployment uses only `wrangler.worker.jsonc`.

### Mac mini worktree preview

`npm run preview:hot` serves the current worktree at `http://127.0.0.1:4184/00/shell/`. It watches Shell, Workbench, docs and asset sources, rebuilds on change, and reloads the browser when the new build is ready. It uses local D1 and R2 data and does not deploy or change production. The preview-only reload code is added to generated assets under `dist/`, never to production source.

Open `https://preview.mhoo.dev/00/shell/` for the current Mac mini Shell worktree. It keeps the production path under a dedicated preview hostname. The `dev.mhoo.hot-preview.server` and `dev.mhoo.hot-preview.tunnel` LaunchAgents keep the watcher and named Tunnel running. Their definitions live in `~/Library/LaunchAgents/`, the Tunnel ingress is `~/.cloudflared/mhoo-hot-preview.yml`, and logs are in `~/.local/state/mhoo-hot-preview/`. The Tunnel points only `preview.mhoo.dev` to `http://127.0.0.1:4184` with a 404 fallback. The existing shared `/00` Access application protects `preview.mhoo.dev/00/*`; the preview Worker additionally verifies that JWT on every request and restricts human use to the primary owner identity. Local D1 and R2 remain separate from production. The ignored `.dev.vars` contains local provider credentials and a preview CSRF secret, so keep this endpoint behind Access. This stable URL currently follows this checkout; selecting another Shell task worktree requires moving the server's working directory to that worktree.

## Evaluation history

Authenticated inference runs and registered tool calls are saved before execution. Failures and rejected concurrent runs are retained. Preview-only and authentication/transport rejections are not inference runs. Records include inputs, provider request/response bodies, timestamps, outcomes, and atomic tool events. Headers are excluded, configured TypeSafe key values are redacted, and provider responses are capped at 200KB. Interrupted runs remain visibly unfinished.

The inspector supports cursor pagination, JSONL export, and persistent pass/fail/unreviewed labels, expected outcomes, and notes. No automatic eviction is implemented. Histories are scoped to authenticated subjects. Exports never replay tools. Installed design resources are pinned and checked; their scripts are not executed.

## Artifact storage and evaluation (local implementation)

The observer now stores generated HTML/raw output through `ARTIFACTS` R2 and
retains owner-scoped metadata, hashes and quality evaluations in D1. Local
startup binds persistent simulated R2. The real `mhoo-shell-artifacts` bucket
exists; production binding/migration deployment remains pending. See
[OBSERVER.md](OBSERVER.md) and [QUALITY-REVIEW.md](QUALITY-REVIEW.md).
