import {test} from 'node:test';
import assert from 'node:assert/strict';
import {accessPrincipal} from './access-principal.mjs';
test('machine identity is opt-in, exact and confined to the configured host',()=>{
 const env={BKK_AGENT_CLIENT_ID:'bkk-test.access'},claims={sub:'',common_name:'bkk-test.access'};
 assert.equal(accessPrincipal(claims,env,'mhoo.dev'),'service:bkk-test.access');
 for(const host of ['mhoo.app','localhost','evil.invalid'])assert.equal(accessPrincipal(claims,env,host),null);
 assert.equal(accessPrincipal(claims,{},'mhoo.dev'),null);
 assert.equal(accessPrincipal({...claims,common_name:'other.access'},env,'mhoo.dev'),null);
 assert.equal(accessPrincipal({common_name:'bkk-test.access'},env,'mhoo.dev'),null);
 assert.equal(accessPrincipal({sub:'human-owner',email:'tanyawit@mhoooo.com'},env,'mhoo.dev'),'human-owner');
 assert.equal(accessPrincipal({sub:'human-owner',email:'onemuhre@gmail.com'},env,'mhoo.dev'),null);
 assert.equal(accessPrincipal({sub:'human-owner',email:'tanyawit@mhoooo.com'},env,'mhoo.app'),null);
});
test('Access-signed owner identity may use only the explicitly enabled preview origin',()=>{
 const owner={sub:'human-owner',email:'tanyawit@mhoooo.com'};
 const preview={PREVIEW_REQUIRE_ACCESS:'true',PUBLIC_ORIGIN:'https://preview.mhoo.dev'};
 assert.equal(accessPrincipal(owner,preview,'preview.mhoo.dev'),'human-owner');
 assert.equal(accessPrincipal(owner,{},'preview.mhoo.dev'),null);
 assert.equal(accessPrincipal(owner,{PREVIEW_REQUIRE_ACCESS:'true',PUBLIC_ORIGIN:'https://preview.mhoo.dev.evil.test'},'preview.mhoo.dev'),null);
 assert.equal(accessPrincipal(owner,preview,'other.mhoo.dev'),null);
 assert.equal(accessPrincipal({sub:'human-owner',email:'onemuhre@gmail.com'},preview,'preview.mhoo.dev'),null);
 assert.equal(accessPrincipal({sub:'',common_name:'bkk-test.access'}, {...preview,BKK_AGENT_CLIENT_ID:'bkk-test.access'},'preview.mhoo.dev'),null);
});
