import {accessPrincipal} from './access-principal.mjs';
import docs from '../../docs/generated.json';
import aggregate from '../../docs/aggregate.generated.json';
import {renderDocs} from '../../docs/render.mjs';
import {reviewDocs,reviewRequest} from '../../docs/review.mjs';
import {evaluateArtifact} from './quality.mjs';
import {readArtifact,storeArtifact} from './artifacts.mjs';
import {codexProvider} from '../workbench/codex-provider.mjs';
import {runDesignPhase} from '../workbench/design-pipeline.mjs';
import { composeRecipe } from '../workbench/recipe.mjs';
import {createRemoteJWKSet,jwtVerify,SignJWT} from 'jose';
import {workspace,runStore,shellTools,lease} from './store.mjs';
import {createDurableTraces} from '../workbench/durable-traces.mjs';
import {runCommand,toolDefinitions} from '../workbench/commands.mjs';
import {chooseLayout,JevError} from '../workbench/jev.mjs';
import {selectDesignSkill} from '../workbench/design-selector.mjs';
import {validateDesign} from '../workbench/config.js';
import {seedInbox} from '../workbench/seed.js';
import catalog from '../../design-catalog/catalog.json';
const fail=(message,status=400)=>{throw new JevError(message,status);};
const json=(v,status=200)=>Response.json(v,{status,headers:{'cache-control':'no-store'}});
async function identity(request,env){
 const url=new URL(request.url);
 if(env.LOCAL_DEV==='true'&&env.PREVIEW_REQUIRE_ACCESS!=='true'&&['localhost','127.0.0.1','[::1]'].includes(url.hostname))return 'local-owner';
 if(!env.ACCESS_TEAM_DOMAIN||!env.ACCESS_AUD)fail('Cloudflare Access is not configured.',503);
 const issuer=`https://${env.ACCESS_TEAM_DOMAIN}`;
 try {const {payload}=await jwtVerify(request.headers.get('cf-access-jwt-assertion')||'',createRemoteJWKSet(new URL(`${issuer}/cdn-cgi/access/certs`)),{issuer,audience:env.ACCESS_AUD});const principal=accessPrincipal(payload,env,url.hostname);if(!principal)throw Error();return principal;}catch{fail('Sign in through Cloudflare Access.',401);}
}
async function readBody(request){
 if(!request.headers.get('content-type')?.startsWith('application/json'))fail('Send JSON.',415);
 const reader=request.body?.getReader();if(!reader)fail('Send JSON.');let size=0,text='';const decoder=new TextDecoder();
 while(true){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>32768){await reader.cancel();fail('Request is too large.',413);}text+=decoder.decode(value,{stream:true});}
 try{return JSON.parse(text+decoder.decode());}catch{fail('Invalid JSON.');}
}
function library(env){return {skills:catalog.skills,
 async list(){return catalog.skills.map(({id,description,requires,license,url,explicitOnly})=>({id,description,requires,license,explicitOnly,source:url,available:true}));},
 async read({id,resource='SKILL.md',offset=0,limit=8000}={}){
 const skill=catalog.skills.find(s=>s.id===id);if(!skill)fail('Unknown skill.',404);
 if(!Object.hasOwn(skill.resources,resource)||!/\.(md|txt|json|csv|ya?ml)$/i.test(resource)||!Number.isInteger(offset)||offset<0||!Number.isInteger(limit)||limit<1||limit>12000)fail('Invalid resource or range.');
 const response=await env.ASSETS.fetch(new Request(`https://assets.invalid/_skills/${id}/${resource}`));if(!response.ok)fail('Skill unavailable.',503);
 const bytes=await response.arrayBuffer();const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');if(hash!==skill.resources[resource].sha256)fail('Skill integrity check failed.',409);
 const text=new TextDecoder().decode(bytes);if(offset>text.length)fail('Invalid offset.');const end=Math.min(offset+limit,text.length);
 return {id,resource,text:text.slice(offset,end),offset,nextOffset:end<text.length?end:null,totalCharacters:text.length,resources:Object.keys(skill.resources).filter(p=>/\.(md|txt|json|csv|ya?ml)$/i.test(p)),source:skill.url,license:skill.license};
 }};}
export default {async fetch(request,env){try{
 const owner=await identity(request,env),url=new URL(request.url);
 const mount=url.pathname==='/00/shell'||url.pathname.startsWith('/00/shell/')?'/00/shell':'';
 if(url.pathname===mount&&mount)return Response.redirect(new URL(mount+'/',url),308);
 const path=mount?url.pathname.slice(mount.length):url.pathname;
 const secret=env.CSRF_SECRET||(owner==='local-owner'?'local-development-only':null);if(!secret)fail('CSRF_SECRET is not configured.',503);
 const key=new TextEncoder().encode(secret),store=runStore(env.DB,owner,env.ARTIFACTS),tools=shellTools(env.DB,owner),skills=library(env);
 if(request.method==='GET'){
  if(path==='/api/docs')return json(docs);
  if(path==='/api/docs/catalog')return json(aggregate);
  if(path.startsWith('/docs/source/')){const requested=path.slice(13),id=requested.includes('/')?requested:`shell/${requested}`;const page=aggregate.pages.find(p=>p.id===id);if(!page)fail('Page not found.',404);return new Response(page.raw,{headers:{'content-type':'text/plain; charset=utf-8','x-content-type-options':'nosniff','cache-control':'no-store'}});}

  if(path==='/docs'||path==='/docs/'||/^\/docs\/[a-z][a-z0-9-]*(?:\/[a-z][a-z0-9-]*)?$/.test(path)){
   const requested=path.slice(6),id=path==='/docs/field'?null:requested.includes('/')?requested:`shell/${requested||'start'}`;const html=renderDocs(aggregate,id,mount);if(!html)fail('Page not found.',404);
   return new Response(html,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"}});
  }

  if(path==='/api/bootstrap'){const row=await workspace(env.DB,owner);return json({csrf:await new SignJWT({}).setProtectedHeader({alg:'HS256'}).setSubject(owner).setExpirationTime('12h').sign(key),state:JSON.parse(row.inbox),selected:JSON.parse(row.kept||row.preview),preview:await tools.snapshot(),hasKeptDesign:!!row.kept,jev:{configured:!!env.TYPESAFE_API_KEY,model:'jev-latest'},generator:{provider:'codex-lb',model:'automatic',configured:!!(env.CODEX_LB_BASE_URL&&env.CODEX_LB_API_KEY)},history:{durable:true}});}
  if(path==='/api/artifact'){
    const {html}=await readArtifact(env.DB,env.ARTIFACTS,owner,url.searchParams.get('id')||'');
    return new Response(html,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'self'; sandbox allow-scripts"}});
  }
  if(path==='/api/preview')return json(await tools.snapshot());
  if(path==='/api/state')return json(JSON.parse((await workspace(env.DB,owner)).inbox));
  if(path==='/api/tools')return json({tools:toolDefinitions});
  if(path==='/api/design-skills')return json({skills:await skills.list()});
  if(path==='/api/revision')return json({revision:'cloudflare-v1'});
  const assets=['/docs/docs.js','/docs/docs.css','/particle.js','/field.js','/particle.css','/search.css','/','/jev','/observer','/app.js','/config.js','/workbench.css','/component.js','/icons.js','/shell.css','/assets/shell-icons.jpg','/inspector.js','/inspector.css'];
  if(!assets.includes(path)&&!aggregate.assets.some(asset=>asset.url===path))fail('Not found.',404);
  if(path==='/jev'||path==='/observer')url.pathname=mount+'/inspector';
  const response=await env.ASSETS.fetch(new Request(url,request));const headers=new Headers(response.headers);headers.set('cache-control','no-store');headers.set('x-content-type-options','nosniff');headers.set('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");return new Response(response.body,{status:response.status,headers});
 }
 if(request.method!=='POST')fail('Method not allowed.',405);
 if(![url.origin,env.PUBLIC_ORIGIN].filter(Boolean).includes(request.headers.get('origin')))fail('Same origin required.',403);
 try{await jwtVerify(request.headers.get('x-workbench-token')||'',key,{algorithms:['HS256'],subject:owner});}catch{fail('Reload the workbench.',403);}
 const input=await readBody(request);
 if(path==='/api/docs/review/preview')return json(reviewRequest(input,docs));
 if(path==='/api/docs/review'){
  reviewRequest(input,docs);
  const traces=createDurableTraces(store,{redact:env.TYPESAFE_API_KEY||''});
  return json(await traces.run(path,input,async(fetchImpl,id)=>{
   await lease(env.DB,owner,id);
   try{return await reviewDocs(input,{docs,apiKey:env.TYPESAFE_API_KEY,fetchImpl});}
   finally{await env.DB.prepare('DELETE FROM inference_leases WHERE owner=? AND holder=?').bind(owner,id).run();}
  },fetch));
 }

 if(path==='/api/jev/traces')return json(await store.list(input));
 if(path==='/api/artifacts/evaluate'){const {record}=await readArtifact(env.DB,env.ARTIFACTS,owner,input.id||'');const evaluationInput={...input,...(record.workflow?{workflow:{...record.workflow,stageIndex:record.workflow.stageIndex+1}}:{})};const traces=createDurableTraces(store,{redact:env.TYPESAFE_API_KEY||''});return json(await traces.run(path,evaluationInput,fetchImpl=>evaluateArtifact(input,{db:env.DB,bucket:env.ARTIFACTS,owner,apiKey:env.TYPESAFE_API_KEY,fetchImpl}),fetch));}
 if(path==='/api/artifacts/evaluations'){const rows=await env.DB.prepare('SELECT id,result FROM quality_evaluations WHERE owner=? AND run_id=? ORDER BY created_at DESC LIMIT 20').bind(owner,input.id||'').all();return json({evaluations:rows.results.map(r=>({id:r.id,...JSON.parse(r.result)}))});}
 if(path==='/api/artifacts/source'){const {html,raw,sha256,storage}=await readArtifact(env.DB,env.ARTIFACTS,owner,input.id||'');return json({html,raw,sha256,storage});}
 if(path==='/api/artifacts/store'){const {record}=await readArtifact(env.DB,env.ARTIFACTS,owner,input.id||'');const updated=await storeArtifact(record,env.ARTIFACTS,owner);await store.put(updated);return json({artifact:updated.result.artifact});}
 if(path==='/api/workflows/link')return json(await store.linkWorkflow(input));
 if(path==='/api/jev/evaluate')return json(await store.evaluate(input));
 if(path==='/api/jev/export'){const page=await store.list(input);return new Response(page.traces.map(r=>JSON.stringify(r)).join('\n')+'\n',{headers:{'content-type':'application/x-ndjson','cache-control':'no-store','x-next-cursor':String(page.nextCursor??'')}});}
 if(path==='/api/design-skills/read')return json(await skills.read(input));
 if(path==='/api/commands/preview')return json(await runCommand(input,{tools,preview:true}));
 if(path==='/api/jev/preview')return json(await selectDesignSkill(input,{library:skills,preview:true,apiKey:''}));
 if(path==='/api/tools/call')return json(await shellTools(env.DB,owner).call(input.name,input.arguments));
 if(['/api/design-pipeline','/api/design-recipes/compose','/api/commands/run','/api/jev','/api/design-skills/select'].includes(path)){
 const traces=createDurableTraces(store,{redact:[env.TYPESAFE_API_KEY,env.CODEX_LB_API_KEY,env.CF_AIG_TOKEN]});
 return json(await traces.run(path,input,async(fetchImpl,id,progress)=>{
  await lease(env.DB,owner,id);
  try{return await (path==='/api/design-pipeline'?runDesignPhase:path==='/api/design-recipes/compose'?composeRecipe:path==='/api/commands/run'?runCommand:path==='/api/jev'?chooseLayout:selectDesignSkill)(input,{tools:shellTools(env.DB,owner,id),library:skills,apiKey:env.TYPESAFE_API_KEY||'',fetchImpl,ai:env.CODEX_LB_BASE_URL?codexProvider(env,fetch,progress):undefined});}
  finally{await env.DB.prepare('DELETE FROM inference_leases WHERE owner=? AND holder=?').bind(owner,id).run();}
 },fetch));}
 await workspace(env.DB,owner);
 if(path==='/api/design'){let selected;try{selected=validateDesign(input);}catch(e){fail(e.message);}await env.DB.prepare('UPDATE workspace SET kept=? WHERE owner=?').bind(JSON.stringify(selected),owner).run();return json({selected,storage:'D1'});}
 if(['/api/messages','/api/reset'].includes(path)){
 const row=await workspace(env.DB,owner),state=JSON.parse(row.inbox);if(state.revision!==input.revision)fail('Inbox changed. Reload and retry.',409);
 if(path==='/api/reset')state.messages=seedInbox();else{const message=state.messages.find(m=>m.id===input.id);if(!message)fail('Conversation not found.',404);if(input.action==='draft'){if(typeof input.draft!=='string'||input.draft.length>10000)fail('Invalid draft.');message.draft=input.draft;}else if(input.action==='archive')message.archived=true;else if(input.action==='restore')message.archived=false;else if(input.action==='read')message.unread=false;else fail('Unknown action.');}
 state.revision++;const r=await env.DB.prepare('UPDATE workspace SET inbox=? WHERE owner=? AND inbox=?').bind(JSON.stringify(state),owner,row.inbox).run();if(!r.meta.changes)fail('Inbox changed. Reload and retry.',409);return json(state);}
 fail('Not found.',404);
 }catch(error){return json({error:error.status?error.message:'Workbench request failed. Persisted stages remain available.'},error.status||500);}}};
