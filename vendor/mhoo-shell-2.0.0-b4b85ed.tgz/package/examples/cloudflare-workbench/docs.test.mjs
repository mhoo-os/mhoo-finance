import test from 'node:test';
import assert from 'node:assert/strict';
import {SignJWT} from 'jose';
import worker from './dist/_worker.js';
const env={LOCAL_DEV:'true'};
const get=path=>worker.fetch(new Request('http://localhost'+path),env);
test('docs content-first and graph routes, raw source and mounted assets stay behind identity',async()=>{
 for(const path of ['/docs','/docs/start','/docs/field','/00/shell/docs','/00/shell/docs/field']){
  const response=await get(path);assert.equal(response.status,200,path);const text=await response.text();assert.match(response.headers.get('content-security-policy'),/script-src 'self'/);assert.match(text,path.endsWith('field')?/id="reader"[^>]* hidden/:/data-page="shell\/start"/);
 }
 const docs=await(await get('/api/docs')).json();assert.equal(await(await get('/docs/source/start')).text(),docs.pages[0].raw);
 const aggregate=await(await get('/api/docs/catalog')).json();assert.deepEqual(aggregate.projects.map(p=>p.project),['shell','particle-ui']);assert.ok(aggregate.pages.some(p=>p.id==='particle-ui/field'));
 const particle=await get('/docs/particle-ui/field');assert.equal(particle.status,200);assert.match(await particle.text(),/data-page="particle-ui\/field"/);
 assert.match(await(await get('/docs/source/particle-ui/field')).text(),/pinned landing/);
 assert.equal((await get('/00/shell/docs/particle-ui/start')).status,200);
 assert.equal((await worker.fetch(new Request('https://public.example/api/docs/catalog'),env)).status,503);
 const media=docs.assets.find(asset=>asset.url==='/docs/assets/shell/components-settled.png');assert.ok(media);assert.equal(media.hash.length,64);
 const clip=docs.assets.find(asset=>asset.url==='/docs/assets/shell/field-formation.webm');assert.ok(clip);assert.ok(clip.size>10000);
 const aggregateVisual=docs.assets.find(asset=>asset.url==='/docs/assets/shell/aggregate-field-desktop.png');assert.ok(aggregateVisual);assert.ok(aggregateVisual.size>10000);
 const assetEnv={...env,ASSETS:{fetch:request=>new Response(new URL(request.url).pathname)}};
 assert.equal((await worker.fetch(new Request('http://localhost'+media.url),assetEnv)).status,200);
 assert.equal((await worker.fetch(new Request('http://localhost'+clip.url),assetEnv)).status,200);
 assert.equal((await worker.fetch(new Request('http://localhost'+aggregateVisual.url),assetEnv)).status,200);
 assert.equal((await worker.fetch(new Request('http://localhost/docs/assets/shell/missing.png'),assetEnv)).status,404);
 assert.equal((await worker.fetch(new Request('https://public.example'+media.url),assetEnv)).status,503);
 assert.equal((await get('/docs/missing')).status,404);assert.equal((await get('/docs/source/missing')).status,404);
 for(const path of ['/docs','/docs/source/start','/api/docs'])assert.equal((await worker.fetch(new Request('https://public.example'+path),env)).status,503);
});
test('docs preview requires signed owner-bound CSRF, validates body and makes no inference call',async()=>{
 const docs=await(await get('/api/docs')).json(),page=docs.pages[0];
 const input={pageId:page.id,pageHash:page.hash,change:'Change the documentation navigation behavior.',evidence:'The docs now open directly to the introduction and the user can return to the graph with a separate explicit link.'};
 const token=await new SignJWT({}).setProtectedHeader({alg:'HS256'}).setSubject('local-owner').setExpirationTime('1h').sign(new TextEncoder().encode('local-development-only'));
 const post=(body,headers={})=>worker.fetch(new Request('http://localhost/api/docs/review/preview',{method:'POST',headers:{'content-type':'application/json',origin:'http://localhost','x-workbench-token':token,...headers},body:JSON.stringify(body)}),env);
 assert.equal((await post(input,{origin:'https://foreign.example'})).status,403);assert.equal((await post(input,{'x-workbench-token':''})).status,403);
 assert.equal((await post({...input,pageHash:'stale'})).status,409);assert.equal((await post({...input,evidence:'x'.repeat(33000)})).status,413);
 const response=await post(input);assert.equal(response.status,200);const request=await response.json();assert.equal(request.state.page.text,page.raw);assert.equal(Object.keys(request.questions).length,3);
});
