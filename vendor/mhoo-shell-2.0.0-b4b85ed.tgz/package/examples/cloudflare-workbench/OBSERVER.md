# Observer, artifact storage and quality evaluation

## Current status — 2026-09-23

The local workbench has a linked workflow observer, live generation counters,
R2-backed HTML artifacts and artifact-specific Jev evaluation history.
`QUALITY-REVIEW.md` contains the browser audit and scored assessment.

Remote resources: the existing Worker `mhoo-shell-workbench` has D1 `DB`
(database `00c9bfe5-b4a0-47ee-9fb0-e3e97012ae05`). The new private R2 bucket
`mhoo-shell-artifacts` exists and passed an exact artifact upload/readback check.
The production R2 binding and quality migration are in source but not deployed.
No Durable Object, Cloudflare Workflow or AI Gateway provider was provisioned.

## Local development

Run `npm run workbench` to apply local migrations, build and start the emulator.
Local D1 and R2 persist below `examples/cloudflare-workbench/.wrangler/state`.
Local execution uses simulated R2; it does not silently use the remote bucket.
Secrets belong in the ignored `.dev.vars` file. Restart Wrangler after changing
that file; a build alone did not reliably reload the previous provider settings.

Codex-lb configuration uses `CODEX_LB_BASE_URL` and `CODEX_LB_API_KEY`; a fixed
`CODEX_LB_MODEL` is no longer required. The tested base is
`https://codex-lb.mhoo.app/v1`. Before generation, the adapter reads the
OpenAI-compatible `/models` catalog and selects only from that validated list.
Design planning, visual design and visual observation require `gpt-6-astra` and
fail closed when it is unavailable. Implementation, coordination and routine
policies have separate bounded candidate lists. Catalog discovery is reused only
inside one provider instance; it is not kept as mutable cross-request Worker
state. Workflow validators reject missing required evidence before routing.

The adapter uses streaming Chat Completions with policy-selected reasoning,
bounded capture and a five-minute timeout. The six-minute inference lease exceeds
this window. The deployed OCI version 1.25beta.9 is user-reported, not independently
verified. Responses, WebSockets and a tool-equipped coding harness are not part
of this adapter. Optional `CF_AIG_TOKEN` is only for an explicitly configured
Gateway passthrough. There is no silent provider fallback when Codex-lb is set.

## Artifact persistence

On a completed HTML run, R2 receives a JSON object containing exact `html` and
original generator `raw` output. D1 retains metadata: owner, run, content hash,
byte size, type and R2 key. R2 upload completes before the D1 record references it.
A failed upload fails persistence; no reference to an absent object is committed.
A D1 failure after upload may leave an unreferenced object; automatic garbage
collection is not implemented.

`GET /api/artifact?id=...` checks ownership through D1, reads R2 and verifies the
HTML SHA-256 before serving. Legacy inline D1 HTML remains readable. The response
uses sandbox CSP, blocks network/form requests and has no same-origin privilege.
`POST /api/artifacts/source` returns source and original raw text for inspection.
`POST /api/artifacts/store` migrates one authorized legacy artifact to R2.
Content hashes bind evaluations to the reviewed HTML. These hashes are integrity
checks, not proof of correctness or provenance from a particular model.

Current artifact contract is self-contained HTML. General media upload and
image/video/3D viewers are not implemented.

## Observer and workflow links

`/observer` and `/jev` are aliases; `/00/shell/` paths work under the deployment
mount. Execution Trace, Output Inspector and Preview Canvas share a selected run.
The canvas can expand, render at a phone width and open the authorized artifact.
Output Inspector can load the artifact's stored source.

New pipeline requests carry explicit workflow IDs and stage indexes. History
queries can filter by workflow. Owner-authorized `/api/workflows/link` associates
existing traces by exact IDs and refuses a conflicting workflow. The original
five successful Codex-lb stages and their quality evaluation are linked. Earlier
failed historical attempts remain in Activity; they were not inferred into the
group. Future retries retain the same workflow ID and stage index.

Progress records waiting, streaming and received states plus characters and wire
bytes. Updates are persisted at most once per two seconds while chunks arrive.
Quiet periods do not fabricate progress or percentages. A real request verified
intermediate counts and final completion. Polling preserves a selected run while
new activity arrives and pauses while an evaluation form is being edited.

## Quality evaluation

The artifact panel accepts explicit browser observations and calls Jev with the
artifact source, brief, evidence and three independent Score rubrics. Functionality,
usability and visual composition are displayed separately. Score levels 0–4 are
multiplied by 2.5 to display 0–10; rubric, original distribution, confidence,
observations and artifact hash remain available in each saved report.

The API validates all score ranges before storing a report in D1
`quality_evaluations`. Quality calls also appear as traced Jev turns, linked to
the artifact workflow when available. `/api/artifacts/evaluations` returns only
the current owner's reports. Human pass/fail notes remain a separate facility.

Jev receives text/source, not screenshots. Browser evidence is user/agent supplied;
it is not independently verified by Jev. This is an implemented evidence-review
loop, not automated browser testing, a calibrated aesthetic benchmark, a release
gate, or an automatic repair loop. Missing tests must be stated as unknown.
