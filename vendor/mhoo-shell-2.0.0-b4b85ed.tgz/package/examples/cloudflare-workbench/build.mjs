import {compileDocs,compileAggregateDocs} from '../../docs/build.mjs';
import {mkdir,cp,writeFile,rm,readFile} from 'node:fs/promises';
import {build} from 'esbuild';
import {DesignLibrary} from '../workbench/design-skills.mjs';
const docs=await compileDocs(),aggregate=await compileAggregateDocs();
await writeFile(new URL('../../docs/generated.json',import.meta.url),JSON.stringify(docs));
await writeFile(new URL('../../docs/aggregate.generated.json',import.meta.url),JSON.stringify(aggregate));
const out=new URL('./dist/',import.meta.url);await rm(out,{recursive:true,force:true});await mkdir(out,{recursive:true});
for(const name of ['index.html','app.js','config.js','workbench.css','inspector.html','inspector.js','inspector.css'])await cp(new URL(`../workbench/${name}`,import.meta.url),new URL(name,out));
for(const [src,dest] of [['component.js','component.js'],['icons.js','icons.js'],['dist/shell.css','shell.css'],['assets','assets']])await cp(new URL(`../../${src}`,import.meta.url),new URL(dest,out),{recursive:true});
const library=new DesignLibrary();for(const s of library.skills)for(const resource of Object.keys(s.resources).filter(p=>/\.(md|txt|json|csv|ya?ml)$/i.test(p))){let text='',offset=0;do{const page=await library.read({id:s.id,resource,offset,limit:12000});text+=page.text;offset=page.nextOffset;}while(offset!==null);const file=new URL(`_skills/${s.id}/${resource}`,out);await mkdir(new URL('.',file),{recursive:true});await writeFile(file,text);}
await cp(new URL('../../docs/web/',import.meta.url),new URL('docs/',out),{recursive:true});
for(const asset of aggregate.assets){const destination=new URL(`.${asset.url}`,out);await mkdir(new URL('.',destination),{recursive:true});const source=asset.url.includes('/particle-ui/')?new URL(`../../node_modules/@mhoo/particle-ui/${asset.source}`,import.meta.url):new URL(`../../${asset.source}`,import.meta.url);await cp(source,destination);}
await build({entryPoints:[new URL('../../particle.js',import.meta.url).pathname],outfile:new URL('particle.js',out).pathname,bundle:true,format:'esm',platform:'browser'});
await build({entryPoints:[new URL('../../field.js',import.meta.url).pathname],outfile:new URL('field.js',out).pathname,bundle:true,format:'esm',platform:'browser'});
await cp(new URL(import.meta.resolve('@mhoo/particle-ui/styles.css')),new URL('particle.css',out));
await build({entryPoints:[new URL(import.meta.resolve('@mhoo/particle-ui/search.css')).pathname],outfile:new URL('search.css',out).pathname,bundle:true,platform:'browser',external:['/particle-workflow-v1.png']});
await build({entryPoints:[new URL('./worker.mjs',import.meta.url).pathname],outfile:new URL('_worker.js',out).pathname,bundle:true,format:'esm',platform:'browser',target:'es2022'});
await writeFile(new URL('_routes.json',out),JSON.stringify({version:1,include:['/*'],exclude:[]}));

const mounted=new URL('00/shell/',out);await mkdir(mounted,{recursive:true});
for(const name of ['index.html','app.js','config.js','workbench.css','inspector.html','inspector.js','inspector.css','component.js','icons.js','shell.css']){
 let text=await readFile(new URL(name,out),'utf8');
 text=text.replaceAll("'/api/","'/00/shell/api/").replaceAll('"/api/','"/00/shell/api/');
 for(const asset of ['component.js','config.js','shell.css','workbench.css','app.js','inspector.css','inspector.js'])text=text.replaceAll('/'+asset,'/00/shell/'+asset);
 for(const route of ['observer','jev','docs'])text=text.replaceAll('"/'+route+'"','"/00/shell/'+route+'"').replaceAll("'/"+route+"'","'/00/shell/"+route+"'");
 text=text.replaceAll('href="/"','href="/00/shell/"').replaceAll('../assets/shell-icons.jpg','./assets/shell-icons.jpg');
 await writeFile(new URL(name,mounted),text);
}
await cp(new URL('assets/',out),new URL('assets/',mounted),{recursive:true});

await writeFile(new URL('.assetsignore',out),'_worker.js\n_routes.json\n');

await cp(new URL('docs/',out),new URL('docs/',mounted),{recursive:true});
for(const name of ['particle.js','field.js','particle.css','search.css'])await cp(new URL(name,out),new URL(name,mounted));
