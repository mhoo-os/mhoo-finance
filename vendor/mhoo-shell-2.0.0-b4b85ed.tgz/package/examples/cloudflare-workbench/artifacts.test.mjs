import test from 'node:test';
import assert from 'node:assert/strict';
import {storeArtifact,readArtifact} from './artifacts.mjs';
import {evaluateArtifact} from './quality.mjs';
test('R2 stores exact source and fails closed on corruption or upload error',async()=>{
 let stored;const bucket={async put(key,value){stored={key,value};},async get(){return {async json(){return JSON.parse(stored.value);}};}};
 const record=await storeArtifact({id:'run',result:{html:'<html>test</html>',raw:'original provider output'}},bucket,'owner');
 assert.equal(record.result.html,undefined);assert.equal(record.result.raw,undefined);assert.equal(JSON.parse(stored.value).raw,'original provider output');
 const db={prepare(){return {bind(id,owner){return {async first(){return owner==='owner'?{record:JSON.stringify(record)}:null;}};}};}};
 assert.equal((await readArtifact(db,bucket,'owner','run')).html,'<html>test</html>');
 await assert.rejects(readArtifact(db,bucket,'other','run'),e=>e.status===404);
 stored.value=JSON.stringify({html:'tampered'});await assert.rejects(readArtifact(db,bucket,'owner','run'),/integrity/);
 await assert.rejects(storeArtifact({id:'run',result:{html:'source'}},{async put(){throw Error('storage failed');}},'owner'),/storage failed/);
});
test('quality judgment requires evidence, validates every score, and binds source hash',async()=>{
 let saved;const db={prepare(sql){return {bind(...args){return {async first(){return {record:JSON.stringify({input:{request:'brief'},result:{html:'<html>test</html>'}})};},async run(){saved=args;}};}};}};
 const observations='Browser checked search and filters; mobile behavior is not yet tested.';
 let request;const fetchImpl=async(_url,init)=>{request=JSON.parse(init.body);return Response.json({model:'jev-fixture',answers:Object.fromEntries(['functionality','usability','visual'].map(id=>[id,{type:'score',score:2,confidence:.5}]))});};
 const result=await evaluateArtifact({id:'run',observations},{db,owner:'owner',apiKey:'fixture',fetchImpl});
 assert.equal(result.artifactHash.length,64);assert.equal(saved[3],result.artifactHash);assert.equal(Object.keys(request.questions).length,3);assert.match(request.state.limits,/not screenshots/);
 await assert.rejects(evaluateArtifact({id:'run',observations:'short'},{db,apiKey:'fixture'}),e=>e.status===400);
 await assert.rejects(evaluateArtifact({id:'run',observations},{db,owner:'owner',apiKey:'fixture',fetchImpl:async()=>Response.json({answers:{visual:{type:'score',score:5,confidence:1}}})}),/Invalid Jev/);
});
