# Mhoo Shell host Worker proof

This folder is a local packaging example, not a deployment target. It shows the
host-owned D1 binding and the explicit Email Hub service binding shape without
creating or mutating either resource.

Before any real use, replace the `LOCAL_E2E` actor callback with verified
identity and workspace membership resolution. Service-binding calls do not
inherit Cloudflare Access context automatically.

From this directory, a dry package check is:

```sh
npx wrangler@4.135.0 deploy --dry-run --config wrangler.jsonc
```

For a local D1 run, apply [0001_host_installations.sql](../../migrations/0001_host_installations.sql) using
the host Worker’s migration workflow, then start Wrangler with the local D1
binding. No production database, DNS, Access policy, or service is changed by
this proof.
