import { createAppHostHandler, createD1InstallationStore, createInstallationLedger } from '../../host.js';

/**
 * Local-only packaging example. A real host must replace this callback with
 * verified Access/workspace membership resolution before exposing the handler.
 */
export default {
  async fetch(request, env, ctx) {
    const ledger = createInstallationLedger({ store: createD1InstallationStore(env.DB) });
    const handle = createAppHostHandler({
      ledger,
      actorForRequest: () => env.LOCAL_E2E === 'true' ? { id: 'local-owner@mhoo.test', role: 'owner' } : null,
      origin: new URL(request.url).origin,
    });
    return handle(request, env, ctx);
  },
};
