export interface RenderIconOptions {
  size?: number;
  label?: string;
}

export const iconNames: readonly string[];
export function hasIcon(name: string): boolean;
export function renderIcon(name: string, options?: RenderIconOptions): string;
export function createIcon(name: string, options?: RenderIconOptions): HTMLElement;
