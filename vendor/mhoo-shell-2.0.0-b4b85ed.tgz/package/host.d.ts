import type { MhooAppManifest, MhooAppManifestInput, RegisteredMhooApp } from './component.js';

export declare const APP_HOST_SCHEMA_VERSION: 1;
export declare const DEFAULT_MANIFEST_PATH: '/.well-known/mhoo-app.json';
export declare const MAX_MANIFEST_BYTES: 65536;

export type MhooSourceId = string;

export interface OwnerActor {
  readonly role: string;
  readonly id?: string;
  readonly email?: string;
  readonly subject?: string;
}

export interface ServiceManifestSource {
  readonly type: 'service';
  readonly binding: string;
  readonly manifestPath?: typeof DEFAULT_MANIFEST_PATH;
}

export interface FixtureManifestSource {
  readonly type: 'fixture';
  readonly fixture: string;
}

export type ManifestSource = ServiceManifestSource | FixtureManifestSource;

export interface ApprovalEvidence {
  readonly evidenceId: string;
  readonly idempotencyKey?: string;
  readonly payloadHash: string;
  readonly approvedBy: string;
  readonly approvedAt: string;
  readonly source: ManifestSource;
  readonly label: string;
}

export interface ManifestFailure {
  readonly code: string;
  readonly message: string;
  readonly at: string;
}

export interface InstallationRecord {
  readonly sourceId: string;
  readonly label: string;
  readonly source: ManifestSource;
  readonly enabled: boolean;
  readonly version: number;
  readonly approvalEvidence: readonly ApprovalEvidence[];
  readonly lastKnownValidManifest: MhooAppManifest | null;
  readonly lastKnownValidManifestHash: string | null;
  readonly lastCheckedAt: string | null;
  readonly failure: ManifestFailure | null;
}

export interface CapabilityConsent {
  readonly consentId: string;
  readonly consentKey: string;
  readonly appId: string;
  readonly capability: string;
  readonly description: string;
  readonly consentedBy: string;
  readonly consentedAt: string;
  readonly descriptiveOnly: true;
  readonly authorizationBoundary: 'app-owned';
}

export interface InstallationStore {
  listInstallations(): Promise<InstallationRecord[]>;
  getInstallation(sourceId: string): Promise<InstallationRecord | undefined>;
  insertInstallation(record: InstallationRecord): Promise<InstallationRecord>;
  approveInstallation(record: InstallationRecord, options: {
    readonly idempotencyKey?: string;
    readonly payloadHash?: string;
    readonly evidenceId?: string;
    readonly expectedVersion?: number;
  }): Promise<InstallationRecord>;
  updateInstallation(record: InstallationRecord, expectedVersion: number): Promise<InstallationRecord>;
  removeInstallation(sourceId: string, expectedVersion: number): Promise<InstallationRecord | null>;
  listCapabilityConsents(): Promise<CapabilityConsent[]>;
  getCapabilityConsent(consentKey: string): Promise<CapabilityConsent | undefined>;
  insertCapabilityConsent(record: CapabilityConsent): Promise<CapabilityConsent>;
}

export interface D1PreparedStatementLike {
  bind(...values: unknown[]): D1PreparedStatementLike;
  run(): Promise<{ meta?: { changes?: number } }>;
  first<T = Record<string, unknown>>(): Promise<T | null>;
  all<T = Record<string, unknown>>(): Promise<{ results?: T[] }>;
}

export interface D1DatabaseLike {
  prepare(query: string): D1PreparedStatementLike;
  batch(statements: readonly D1PreparedStatementLike[]): Promise<Array<{ meta?: { changes?: number } }>>;
}

export declare class MhooHostError extends Error {
  readonly code: string;
  readonly status?: number;
  readonly current?: InstallationRecord | CapabilityConsent;
}

export declare class MhooAuthorizationError extends MhooHostError {}
export declare class MhooConflictError extends MhooHostError {}

export declare function createMemoryInstallationStore(
  initialInstallations?: readonly InstallationRecord[],
  initialConsents?: readonly CapabilityConsent[],
): InstallationStore;

export declare function createD1InstallationStore(
  db: D1DatabaseLike,
  options?: { installationTable?: string; consentTable?: string; approvalTable?: string },
): InstallationStore;

export interface FixtureService {
  readonly manifest?: MhooAppManifestInput | (() => MhooAppManifestInput | Promise<MhooAppManifestInput>);
  fetch?(request: Request): Promise<Response> | Response;
  readonly service?: { fetch(request: Request): Promise<Response> | Response };
}

export type ManifestFixture = MhooAppManifestInput | FixtureService | (() => MhooAppManifestInput | FixtureService | Promise<MhooAppManifestInput | FixtureService>);

export interface InstallationLedgerOptions {
  readonly store: InstallationStore;
  readonly fixtures?: Readonly<Record<string, ManifestFixture>> | ReadonlyMap<string, ManifestFixture>;
  readonly clock?: () => string;
  readonly idFactory?: () => string;
  readonly defaultOrigin?: string;
}

export interface ApproveSourceInput {
  readonly sourceId: string;
  readonly label: string;
  readonly source?: ManifestSource;
  readonly type?: ManifestSource['type'];
  readonly binding?: string;
  readonly bindingName?: string;
  readonly fixture?: string;
  readonly fixtureKey?: string;
  readonly idempotencyKey?: string;
  readonly approvedAt?: string;
}

export interface ConsentInput {
  readonly appId: string;
  readonly capability: string;
  readonly description: string;
  readonly consentedAt?: string;
}

export interface InstallationLedger {
  listInstallations(actor: OwnerActor): Promise<readonly InstallationRecord[]>;
  getInstallation(sourceId: string): Promise<InstallationRecord | undefined>;
  approveSource(input: ApproveSourceInput, actor: OwnerActor): Promise<InstallationRecord>;
  setEnabled(sourceId: string, actor: OwnerActor, options: { enabled: boolean; expectedVersion?: number }): Promise<InstallationRecord>;
  setSourceEnabled(sourceId: string, actor: OwnerActor, options: { enabled: boolean; expectedVersion?: number }): Promise<InstallationRecord>;
  removeSource(sourceId: string, actor: OwnerActor, options?: { expectedVersion?: number }): Promise<InstallationRecord | null>;
  refreshSource(sourceId: string, actor: OwnerActor, context?: { env?: Record<string, unknown>; origin?: string; checkedAt?: string }): Promise<InstallationRecord>;
  getCatalog(options?: { role?: string }): Promise<readonly RegisteredMhooApp[]>;
  getWebMcpDirectory(options?: { role?: string }): Promise<WebMcpDirectory>;
  recordCapabilityConsent(input: ConsentInput, actor: OwnerActor): Promise<CapabilityConsent>;
  listCapabilityConsents(actor: OwnerActor): Promise<readonly CapabilityConsent[]>;
  resolveAppRoute(request: Request, actor: OwnerActor, options?: { env?: Record<string, unknown>; role?: string; origin?: string }): Promise<Response | null>;
  routeInstalledApp(request: Request, actor: OwnerActor, options?: { env?: Record<string, unknown>; role?: string; origin?: string }): Promise<Response | null>;
}

export declare function createInstallationLedger(options: InstallationLedgerOptions): InstallationLedger;

export interface WebMcpTool {
  readonly name: string;
  readonly title: string;
  readonly description: string;
  readonly inputSchema: { readonly type: 'object'; readonly properties: Record<string, never>; readonly additionalProperties: false };
  readonly annotations: { readonly readOnlyHint: true; readonly destructiveHint: false; readonly openWorldHint: false };
}

export interface WebMcpDirectoryApp {
  readonly id: string;
  readonly label: string;
  readonly route: string;
  readonly capabilities: readonly string[];
  readonly tools: readonly WebMcpTool[];
  readonly authorizationBoundary: 'app-owned';
}

export interface WebMcpDirectory {
  readonly schemaVersion: 1;
  readonly apps: readonly WebMcpDirectoryApp[];
}

export declare function createWebMcpDirectory(apps?: readonly RegisteredMhooApp[]): WebMcpDirectory;

export declare const APPS_SETTINGS_CSS: string;

export declare function renderAppsSettings(options: {
  role: 'owner';
  installations?: readonly InstallationRecord[];
  capabilityConsents?: readonly CapabilityConsent[];
  actionPath?: string;
  approvalIdempotencyKey?: string;
}): string;

export interface AppHostHandlerOptions {
  readonly ledger: InstallationLedger;
  readonly actorForRequest: (request: Request, env: unknown, ctx: unknown) => OwnerActor | null | Promise<OwnerActor | null>;
  readonly settingsPath?: string;
  readonly directoryPath?: string;
  readonly origin?: string;
  readonly renderSettings?: typeof renderAppsSettings;
}

export declare function createAppHostHandler(options: AppHostHandlerOptions): (request: Request, env: unknown, ctx: unknown) => Promise<Response>;
