export interface ParticleOptions { duration?: number }
/** Decorate an existing HTML object without replacing its DOM or listeners. */
export declare function formParticles(element: HTMLElement | null, options?: ParticleOptions): Promise<void>;
/** Dissolve the visual object; the caller retains responsibility for removal/state. */
export declare function dissolveParticles(element: HTMLElement | null, options?: ParticleOptions): Promise<void>;
