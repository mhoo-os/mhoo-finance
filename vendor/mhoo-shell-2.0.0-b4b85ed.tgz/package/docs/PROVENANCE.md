# Mhoo Docs visual provenance

User explicitly requested reuse of mhoo.dev on 2026-09-23. Inspected the live
homepage, floating Search panel, particle field, and About Mhoo content page.
The local mhoo-public-landing checkout is older than the live visual authority.

Adapted search proportions, dotted orb, blue accent, field label language and
reading typography from these user-owned public sources:
- https://mhoo.dev/knowledge-field.css
- https://mhoo.dev/knowledge-compact.css
- https://mhoo.dev/experiments/particle-world/particle-world.css
- https://mhoo.dev/experiments/particle-world/particle-world.js
- https://mhoo.dev/experiments/particle-world/reading.css

The field component extracts the pinned landing Three shader, seeded sine
distribution and flow from `@mhoo/particle-ui/field`. Graph nodes
and links are generated from this repository's actual documentation catalog and
Markdown relationships; no remote content or background services are copied.
The shared particle primitive is independently authored for semantic HTML.
Brand color values derive from mhoo-email-hub/src/email.ts. The full live landing
boot sequence, world settings API, newsletter service and 3D media are not imported.
The original vendor files remain unchanged and source-locked. The docs-specific
adapter omits public WebMCP and uses normal links for fallback navigation.

Default /docs opens the content reader directly. /docs/field opens the graph
without the landing welcome motion. This implements the latest user direction.
