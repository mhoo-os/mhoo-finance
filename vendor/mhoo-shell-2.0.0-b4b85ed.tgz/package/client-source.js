/**
 * Browser-ready hydration source for server-rendered consumers.
 * Serve this string from a same-origin JavaScript endpoint after renderShell().
 */
const shellClientSource = String.raw`(() => {
  const hydrate = host => {
    if (host.dataset.shellHydrated === 'true') return;
    const shell = host.matches('[data-mhoo-shell]') ? host : host.querySelector('[data-mhoo-shell]');
    if (!shell) return;
    host.dataset.shellHydrated = 'true';
    const toggle = shell.querySelector('[data-shell-toggle]');
    const rail = shell.querySelector('.ms-rail');
    const page = shell.querySelector('.ms-page');
    const collapse = shell.querySelector('[data-shell-collapse]');
    const more = shell.querySelector('[data-shell-action="more"]');
    const actions = shell.querySelector('[data-shell-actions]');
    const mobile = matchMedia('(max-width: 768px)');
    const compactHeader = matchMedia('(max-width: 560px)');
    const focusableSelector = 'button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]';
    const focusableElements = container => [...container.querySelectorAll(focusableSelector)].filter(element => {
      const tabIndex = element.getAttribute('tabindex');
      return !(tabIndex !== null && Number(tabIndex) < 0) && !element.closest('[hidden],[aria-hidden="true"]');
    });
    const focusFirst = container => focusableElements(container)[0]?.focus();
    const itemFrom = element => { try { return JSON.parse(element.dataset.navItem || 'null') || undefined; } catch { return undefined; } };
    const emit = (name, detail = {}) => host.dispatchEvent(new CustomEvent('mhoo:' + name, { detail, bubbles: true }));
    const sync = () => {
      const railEnabled = shell.dataset.railEnabled === 'true';
      const expanded = mobile.matches ? shell.classList.contains('ms-mobile-open') : shell.dataset.collapsed !== 'true';
      collapse.hidden = !railEnabled;
      collapse.setAttribute('aria-label', mobile.matches ? 'Close panel' : (expanded ? 'Collapse' : 'Expand') + ' panel');
      toggle.hidden = !railEnabled || !mobile.matches;
      toggle.setAttribute('aria-expanded', String(expanded));
      toggle.setAttribute('aria-label', mobile.matches ? (expanded ? 'Close' : 'Open') + ' panel' : (expanded ? 'Collapse' : 'Expand') + ' panel');
    };
    const setCollapsed = value => { shell.dataset.collapsed = String(Boolean(value)); sync(); };
    const setActionsOpen = (value, restoreFocus = false) => {
      const expanded = Boolean(value) && compactHeader.matches && Boolean(actions.children.length);
      shell.dataset.actionsOpen = String(expanded);
      more.setAttribute('aria-expanded', String(expanded));
      if (compactHeader.matches) { actions.setAttribute('role', 'dialog'); actions.setAttribute('aria-label', 'Header actions'); }
      else { actions.removeAttribute('role'); actions.removeAttribute('aria-label'); }
      if (expanded) focusFirst(actions);
      else if (restoreFocus) more.focus();
    };
    const syncActions = () => setActionsOpen(shell.dataset.actionsOpen === 'true');
    const setMobileOpen = (value, restoreFocus = false) => {
      const expanded = Boolean(value) && mobile.matches && shell.dataset.railEnabled === 'true';
      if (expanded && shell.dataset.actionsOpen === 'true') setActionsOpen(false);
      shell.classList.toggle('ms-mobile-open', expanded);
      page.inert = expanded;
      if (expanded) {
        page.setAttribute('aria-hidden', 'true');
        rail.setAttribute('role', 'dialog');
        rail.setAttribute('aria-modal', 'true');
        rail.setAttribute('aria-label', shell.dataset.railLabel || 'Workspace panel');
        focusFirst(rail);
      } else {
        page.removeAttribute('aria-hidden');
        rail.removeAttribute('role');
        rail.removeAttribute('aria-modal');
        if (restoreFocus) toggle.focus();
      }
      sync();
    };
    const closeMobile = (restoreFocus = false) => setMobileOpen(false, restoreFocus);
    const syncMobile = () => mobile.matches ? sync() : setMobileOpen(false);
    toggle.addEventListener('click', () => {
      if (mobile.matches) setMobileOpen(!shell.classList.contains('ms-mobile-open'));
      else setCollapsed(shell.dataset.collapsed !== 'true');
    });
    collapse.addEventListener('click', () => mobile.matches ? closeMobile(true) : setCollapsed(shell.dataset.collapsed !== 'true'));
    shell.querySelector('[data-shell-scrim]').addEventListener('click', () => closeMobile(true));
    host.addEventListener('click', event => {
      const action = event.target.closest('[data-shell-action]');
      if (action && (rail.contains(action) || actions.contains(action) || action === more)) {
        emit(action.dataset.shellAction);
        if (action === more && compactHeader.matches) setActionsOpen(shell.dataset.actionsOpen !== 'true');
        else if (actions.contains(action)) setActionsOpen(false);
      }
      if (compactHeader.matches && actions.contains(event.target) && event.target.closest('button,a,[role="button"]')) setActionsOpen(false);
      const disclosure = event.target.closest('[data-shell-nav-toggle]');
      if (disclosure && rail.contains(disclosure)) {
        const expanded = disclosure.getAttribute('aria-expanded') !== 'true';
        disclosure.setAttribute('aria-expanded', String(expanded));
        const children = shell.querySelector('[data-nav-children="' + disclosure.dataset.navPath + '"]');
        if (children) children.hidden = !expanded;
        emit('navigate', { item: itemFrom(disclosure), path: disclosure.dataset.navPath, expanded });
      }
      const navigation = event.target.closest('[data-shell-navigate]');
      if (navigation && rail.contains(navigation)) emit('navigate', { item: itemFrom(navigation), path: navigation.dataset.navPath });
    });
    document.addEventListener('click', event => {
      if (shell.dataset.actionsOpen === 'true' && !actions.contains(event.target) && !more.contains(event.target)) setActionsOpen(false);
    });
    const trapFocus = (event, container) => {
      const focusable = focusableElements(container);
      if (!focusable.length) { event.preventDefault(); return; }
      const first = focusable[0];
      const last = focusable.at(-1);
      const active = document.activeElement;
      if (event.shiftKey && (active === first || !container.contains(active))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (active === last || !container.contains(active))) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', event => {
      if (event.key === 'Tab') {
        if (shell.dataset.actionsOpen === 'true') trapFocus(event, actions);
        else if (shell.classList.contains('ms-mobile-open')) trapFocus(event, rail);
        return;
      }
      if (event.key !== 'Escape') return;
      if (shell.dataset.actionsOpen === 'true') setActionsOpen(false, true);
      else if (shell.classList.contains('ms-mobile-open')) closeMobile(true);
    });
    mobile.addEventListener('change', syncMobile);
    compactHeader.addEventListener('change', syncActions);
    setCollapsed(shell.dataset.collapsed === 'true');
    syncMobile();
    syncActions();
    emit('ready');
  };
  const start = () => document.querySelectorAll('[data-mhoo-shell]').forEach(hydrate);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
  else start();
})();`;

export default shellClientSource;
