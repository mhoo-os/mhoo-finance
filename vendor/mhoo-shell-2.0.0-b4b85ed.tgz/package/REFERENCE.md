# Visual reference and fidelity

## Pinned shell contract (2026-09-14)

The standalone shell consumes the MIT `twenty-ui` light/dark CSS snapshots at `twenty/v2.37.0` (`6da524b8903ec16a3eeea4b2e4a5fb63dbfc1c58`). SHA-256: light `81ae120718a7697e16ba3181b1c0550cb613b8403156202032cf622fc50a961e`, dark `e4ac6fa4ffc84d63c1d949061771f6d3fc686af2cff8852b710f7432d8a63431`. The source relationship used for this refinement is:

| Surface | Twenty source | Pinned value |
| --- | --- | --- |
| Navigation background | `theme-light.css` `--t-background-secondary` | `color(display-p3 0.988 0.988 0.988)` |
| Main panel background | `theme-light.css` `--t-background-primary` | `color(display-p3 1 1 1)` |
| Panel top-left radius | `PageCardLayout.tsx` `themeCssVariables.border.radius.lg` | `16px` base; `32px` squircle in supporting Chromium |
| Panel edge | `PageCardLayout.tsx` | `-4px 0 4px 0 rgba(0,0,0,.006), 0 0 0 1px` medium border token |
| Header | `PageCardHeader.tsx` | secondary background, medium bottom border, `48px` minimum height |

The current shell implements these relationships in `dist/shell.css`. It does **not** import React components or the AGPL Twenty Front navigation runtime, and its DOM remains independently authored.

## Live Mhoo workspace measurement (2026-09-14)

The authenticated `mhoooo.mhoo.app/objects/dashboards` page was inspected in the in-app browser after expanding its rail. At a 1093px-wide viewport, the expanded rail measured **220px**; navigation rows were **204×28px** at x=8 with **16px squircle** radii; the workspace selector was x=8, y=10, 28px high; the tabs and New chat row started at y=52; the Workspace label started at y=92; the first navigation row began at y=122. The panel began at x=221 with **32px top-left squircle** radius, white primary background, and the same shadow recorded above. Its header was **48px** high with secondary background, and the white secondary bar was **40px** high. The surrounding canvas resolved to `color(display-p3 0.976 0.976 0.976)` (`--t-gray-scale-gray3`); the header resolved to `0.988`, and the panel to `1 1 1`. The primary action resolved to `color(display-p3 0.276 0.384 0.837)`, 24px high, 16px squircle radius. These are computed-style observations of this live state, not a promise that every Mhoo theme or route is identical.

The package now matches those measured surface dimensions/tokens for the expanded shell. Its icons, workspace controls, tabs, and example Dashboard body remain independently authored approximations; the authenticated Twenty behavior and exact live DOM are not vendored.

## Embedded App shell measurement (2026-09-14)

The authenticated Inbox page at `/page/7277801e-53a2-4cf0-b443-44460ddc01e9` showed how a developed app fits inside the host. In the collapsed state the rail occupied 40px, the page card began at x=41, and its header was 48px high. Below it a secondary-background widget stage began at y=48 with 8px padding. A bordered frame began at x=50/y=57; the app root itself began at x=51/y=58, with a 320px list pane and the remaining detail pane. These measurements informed `component.js` and `library.css`: the shell owns the rail/header/stage/frame; the consuming app owns the content of `appRoot`. The Inbox's 403 error is live application state, not part of the shell or demo.

The visual target was the owner's live Mhoo Dashboards screenshot during the original Design Studio shell trial. The durable fixture is the pinned Twenty source structure and the original trial's captured renders:

- `packages/twenty-front/src/modules/navigation/components/MainNavigationDrawer.tsx` uses a fixed/scrollable drawer composition.
- `packages/twenty-front/src/modules/ui/layout/page/components/PageCardLayout.tsx` defines a light card with rounded upper-left corner and border shadow.
- `packages/twenty-front/src/modules/ui/layout/page/components/PageCardHeader.tsx` defines a compact secondary-background header with a medium border.
- `packages/twenty-front/src/modules/settings/components/layout/SettingsPageLayout.tsx` composes header, secondary bar and body.

Historical local captures: `design-studio-reusable-shell-desktop.png` at 1440×900 and `design-studio-reusable-shell-phone.png` at 390×844 in `/Users/mhoooo/.codex/visualizations/2026/09/14/01a09ea6-344f-7592-a82a-2a102441a5ff/`. They are reference evidence, not a runtime dependency of this repository.

Matched: compact white rail, light bordered header/card, Twenty theme tokens, responsive collapse, dark app-owned canvas. Remaining gaps: Mhoo's exact branding, search/command menu, workspace selector, settings routes, Tabler icons, resizable drawer and authenticated state. These require app behavior or AGPL front-end code beyond the MIT token snapshot and are not claimed as implemented.
