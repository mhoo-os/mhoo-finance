# Changelog

## 2.0.0 — 2026-09-25

- Rename the package from `@mhoo/twenty-shell` to `@mhoo/shell`. The API is unchanged; consumers update the dependency name and import specifiers when they next bump their pin.
- Add `APP-CONTRACT.md`, the standard every Mhoo app follows to run on its own and install into Shell.
- Add `templates/app/` and `scripts/new-app.mjs`, a starter Worker with static assets, D1, the Shell manifest, and routes at `mhoo.dev/00/<name>`, and in-Worker verification of the shared `/00` Access token plus the app's own email/service-token allow-list.

## 1.0.0 — 2026-09-22

- Add the host-owned installation ledger adapter with D1 persistence, optimistic concurrency, immutable approval evidence, enabled state, stale manifest fallback, and explicit failure records.
- Add owner-only Apps settings rendering and a small host handler for inspect, approve, refresh, enable/disable, and remove actions.
- Resolve routes only through explicitly configured Cloudflare service bindings with a fixed manifest path; arbitrary URL fetching and open-proxy behavior are rejected.
- Add descriptive capability-consent records and a catalog-derived WebMCP directory whose authorization boundary remains app-owned.
- Make approval and capability-consent writes converge safely under retries and concurrent submissions, with fail-closed same-origin settings writes and server-rendered approval idempotency keys.
- Add an explicit local Email Hub manifest/service fixture, migration SQL, package exports, local end-to-end proof, and 1.0 package verification.

## 0.9.0 — 2026-09-22

- Add `createAppCatalog()` for combining only host-supplied v1 discovery manifests.
- Reject duplicate app IDs and overlapping route ownership across the combined registry.
- Keep discovery metadata separate from fetching, installation, authorization, and deployment.

## 0.8.0

- Add a strict, versioned app discovery manifest contract.
- Normalize and freeze discovered app metadata before it enters the Shell registry.
- Bound discovery documents to 64 apps and 65,536 JSON characters.

## 0.7.0 — 2026-09-22

Private app-registry candidate.

### Added

- Typed `MhooApp` manifests for Worker-and-page applications.
- `createAppRegistry()` validation, duplicate detection, capability normalization, and optional role filtering.
- `appForPath()` discovery for exact app routes and their descendant pages.
- `apps` and `role` shell options that render registry-driven navigation while preserving the existing `navigation` API.
- Controller `getApps()` and `getCurrentApp()` read-only discovery methods.

### Boundaries

- The registry contains presentation and discovery metadata only. It does not deploy Workers, create service bindings, grant storage access, or authorize capabilities.
- Consumers still own routing, identity verification, and service-specific authorization.

## 0.6.0 — 2026-09-21

Private release candidate. No registry publication or deployment is implied.

### Added

- Edge-to-edge application content by default, with an explicit `contentMode: 'framed'` compatibility option.
- Runtime `setContentMode()` and `update({ contentMode })` without replacing mounted application DOM.
- Responsive header actions with a functional compact dialog disclosure through the More button.
- Consumer-controlled navigation state through `activePath`, `setActivePath()`, and `update({ activePath })`.
- Deterministic single active target selection and automatic expansion of nested ancestors.
- Mobile navigation focus entry/return, page isolation, viewport cleanup, and mutually exclusive overlays.
- TypeScript declarations for the shell, icon library, and browser-ready hydration source.
- Packed-artifact verification with isolated installation and public-export smoke tests.

### Changed

- Applications now own their internal padding, borders, cards, and split-pane layout in edge mode.
- Header titles truncate before consumer actions, and compact actions remain usable below 560px.
- SSR navigation snapshots remain authoritative when hydration does not repeat the navigation array.
- The private package now verifies its installed form during the normal test workflow.

### Compatibility

- Existing consumers that require the old inset content surface should pass `contentMode: 'framed'`.
- The shell still does not own browser history or routing; consumers provide navigation state.
- `appRoot` and `actionsRoot` remain stable across supported updates.
- The package remains private and is intended to be installed from a pinned Git revision or local path.

## 0.5.0

Initial standalone private shell, Twenty theme snapshots, Mhoo icon library, server rendering, and framework-neutral hydration.
