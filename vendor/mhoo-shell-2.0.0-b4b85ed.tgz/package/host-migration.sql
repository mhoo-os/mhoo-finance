-- Mhoo Shell host control-plane storage.
-- Apply this migration in the host Worker that owns app installation state.
-- The Shell package never creates or mutates a live D1 binding.

CREATE TABLE IF NOT EXISTS mhoo_shell_installations (
  source_id TEXT PRIMARY KEY,
  label TEXT NOT NULL,
  source_json TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK (enabled IN (0, 1)),
  version INTEGER NOT NULL DEFAULT 0,
  approval_evidence_json TEXT NOT NULL,
  last_manifest_json TEXT,
  last_manifest_hash TEXT,
  last_checked_at TEXT,
  failure_json TEXT
) STRICT;

CREATE TABLE IF NOT EXISTS mhoo_shell_approval_idempotency (
  idempotency_key TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  evidence_id TEXT NOT NULL UNIQUE
) STRICT;

CREATE TABLE IF NOT EXISTS mhoo_shell_capability_consents (
  consent_id TEXT PRIMARY KEY,
  consent_key TEXT NOT NULL UNIQUE,
  app_id TEXT NOT NULL,
  capability TEXT NOT NULL,
  description TEXT NOT NULL,
  consented_by TEXT NOT NULL,
  consented_at TEXT NOT NULL,
  descriptive_only INTEGER NOT NULL DEFAULT 1 CHECK (descriptive_only = 1),
  authorization_boundary TEXT NOT NULL DEFAULT 'app-owned' CHECK (authorization_boundary = 'app-owned')
) STRICT;

CREATE INDEX IF NOT EXISTS mhoo_shell_installations_enabled_idx
  ON mhoo_shell_installations (enabled, source_id);

CREATE INDEX IF NOT EXISTS mhoo_shell_capability_consents_app_idx
  ON mhoo_shell_capability_consents (app_id, capability);
