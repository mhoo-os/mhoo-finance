/** First-party default; third-party skills refine implementation within this language. */
export const mhooCore=Object.freeze({
 id:'mhoo-core-particle',name:'Mhoo Core — Particle',version:1,
 reference:'https://mhoo.dev/',documentation:'/docs/particle',
 language:'White space, dark ink, precise Mhoo blue, restrained editorial typography. Particles form useful objects and dissolve on departure. Settled content is crisp, readable and interactive.',
 rules:Object.freeze(['Use Mhoo Core as the default brand foundation unless the user explicitly chooses another identity.','Design skills may supply layout and interaction guidance; they do not silently replace Mhoo branding.','Keep real semantic HTML usable during decorative particle effects.','Respect reduced motion and stop decorative work when settled or hidden.','Documentation opens directly on content; omit the landing welcome sequence.']),
 primitives:Object.freeze({stylesheet:'@mhoo/shell/particle.css',module:'@mhoo/shell/particle',formation:'formParticles',dissolution:'dissolveParticles'}),
});
