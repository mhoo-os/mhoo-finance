# Shell design library experiment

Mhoo Core — Particle is the first-party default foundation. The selector returns
its rules and reusable module paths alongside selected third-party guidance.
Recipes and generation briefs carry the same foundation; explicit user identity
choices still take precedence. See [Particle docs](../docs/content/particle.md).

An agent uses its existing chat to describe a design task. Shell asks Jev to suggest
one skill, then supplies that skill's instructions on demand. There is no extra
chat or required toolbar. Jev selects guidance; the coding agent applies it and
edits the running app. This does not make Jev a code generator or automatically
teach an external agent to call Shell.

## Use from an agent terminal

Start the server with `npm run workbench` in a Terminal with `TYPESAFE_API_KEY` set.
The key stays in that server's environment. In another terminal in this worktree:

```sh
npm run design:skills -- select '{"request":"Make our inbox calm and minimal","preferences":"Quiet colors and generous spacing","capabilities":[]}'
npm run design:skills -- read '{"id":"taste-minimalist","limit":8000}'
```

Use the actual `selected.id` or returned `read` object from the first response.
If `nextOffset` is non-null, read the next page before applying the skill. Relevant
reference files are listed in `resources`. Full instructions remain available;
the API does not silently truncate them. `list` returns compact metadata and instruction-file availability when
needed; missing or modified skills are excluded before ranking. An agent only needs this workflow, not the whole catalog in its prompt.
`preferred` selects a known skill directly, without a model call; `avoid` excludes
IDs. Capabilities are explicit, e.g. `react`, `shadcn`, `python`, `gsap`,
`stitch-mcp`, `stitch-project`. Preferences apply to this request only.

In a browser implementing WebMCP, the app registers `shell_design_skills_select`,
`shell_design_skills_read`, and `shell_design_skills_list`. Native WebMCP is
optional; the CLI and HTTP API work without it. Tools are available after the
page reloads. Downloaded skills are not installed into Codex's global skill list.

## HTTP contract

- `GET /api/design-skills`: compact catalog.
- `POST /api/design-skills/select`: `{request, preferences?, capabilities?, preferred?, avoid?}`.
- `POST /api/design-skills/read`: `{id, resource?, offset?, limit?}`; max 12,000 characters per page.

POST clients get `csrf` from `/api/bootstrap`, then send `Origin` matching the
loopback server and `X-Workbench-Token: <csrf>`. The CLI handles this without
printing the token. The server binds only to `127.0.0.1`; this is a local
experiment, not a hosted multi-user authentication system.

Selection uses at most two TypeSafe requests: compact eligible metadata, then
up to three 2,400-character excerpts. Either stage may return no match. Explicit
choices bypass inference. Missing required capabilities and avoided skills are
excluded before inference; Nothing styling requires an explicit name/request.
Only supplied brief/preferences/capabilities and catalog material go to TypeSafe;
app messages, source files, drafts and credentials are not part of selection.
Returned confidence is a model judgment, not proof of aesthetic quality.
`inputCharacters`, `excerptCharacters` and `elapsedMs` expose measured request
size and latency; they are not token counts, cost estimates or quality scores.

## Sources and installation

24 skill payloads from 15 repositories, chosen from a 24-repository GitHub survey
on 2026-09-22. This is a broad starting set, not every design repository on GitHub.
`research/*.json` records repo-level popularity and discovery metadata.
`catalog.json` records immutable commit references, concise human-written routing
metadata, source URLs, required capabilities, licenses, and every installed file's
SHA-256. Stars measure repository popularity and are never sent to Jev for ranking.
Anthropic's selected skills carry their own Apache-2.0 license; other entries use
MIT or Apache-2.0 as recorded. License notices are retained under each payload's
`_provenance` directory. See the pinned sources for full terms and bundled assets.

```sh
npm run design:install
```

Requires Python 3 and Codex's installed skill-installer helper. Override its path
with `python3 design-catalog/install.py --helper /path/to/install-skill-from-github.py`.
The helper downloads pinned skill directories into `.workbench/design-skills/`.
The installer fetches retained license files and verifies pinned hashes. It refuses
to silently accept a modified payload. No downloaded hook, script or command runs.
A directory is a stored skill payload, not activation of its upstream plugin,
connector, runtime dependency or executable tools. These may need separate setup.
The store is gitignored; source lock, metadata, installer and integration code are
reviewable in Git. To deliberately update a skill, review its new source/license
and refresh the lock rather than following a moving branch automatically.

The read API allows only catalog-listed text files, checks their hashes and real
paths, and bounds each response. Instruction text remains third-party guidance:
it cannot override user/system instructions or grant authority. Commands embedded
in skills require the agent's normal inspection and execution rules. Scripts and
binary assets stay on disk and are not executed by selection or reading.

The default Shell route passes an empty application registry and shows the
no-app-installed state. The design catalog is agent guidance, not a list of apps.

## Experiment limits

The router is a recommendation mechanism. A coding agent still needs to invoke it,
read selected guidance, implement changes and verify the app. Selection does not
save or commit designs. No automatic commits, pushes, deployments, permanent taste
learning, or universal app routing/authentication are introduced here.

Reference: [TypeSafe skill-suggestion cookbook](https://docs.typesafe.ai/cookbooks/skill_suggestion).
Its published benchmark is not a benchmark of this catalog or this implementation.

## Inspect Jev calls

Open `/jev` on the workbench server. It is a read-only ledger of actual Jev turns
made through Shell, including coding-agent API calls. Each run shows structured
state, every batched question and typed response, timing, application composition,
and tool events. The page does not submit prompts. Cloudflare history persists in
D1; the legacy server keeps 12 runs in memory. Headers and API keys are never
recorded. Briefs and provider responses are visible in this local history.

## Clean CI builds

Run `python3 design-catalog/restore.py` to restore only catalog-listed files from pinned GitHub archives. Every file is checked against its recorded size and SHA-256; no downloaded scripts are executed and no Codex installation is required.
