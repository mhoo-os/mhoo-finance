// Pure presentation: destinations are supplied by the consuming app.
const escape = value => value.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function url(value) {
 if (typeof value !== 'string' || value.startsWith('//')) throw new TypeError('A URL is required');
 const parsed = new URL(value, 'https://mhoo.invalid');
 if ((!value.startsWith('/') || value.startsWith('//')) && parsed.protocol !== 'https:') throw new TypeError('Use HTTPS or a root-relative URL');
 if (parsed.protocol !== 'https:' || parsed.username || parsed.password || /[\\\r\n]/.test(value)) throw new TypeError('Unsafe URL');
 return escape(value);
}
export function renderSignIn(input) { return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <meta name="color-scheme" content="light">
  <title>Sign in · Mhoo</title>
  <link rel="stylesheet" href="${url(input.stylesheetUrl)}">
</head>
<body>
  <main class="signin" aria-labelledby="title">
    <a class="brand" href="${url(input.homeUrl)}" aria-label="Mhoo home"><img src="${url(input.wordmarkUrl)}" alt="MHOO" width="176" height="52"></a>
    <p class="kicker">YOUR WORK, CONTINUED</p>
    <h1 id="title">Good to see<br>you again.</h1>
    <p class="intro">Back to your workspace.<br>Sign in with your Mhoo Google account.</p>
    <a class="continue" href="${url(input.continueUrl)}">
      <span>Continue with Google</span>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
    <p class="helper">Already signed in? You’ll go straight to your workspace.</p>
    <details>
      <summary>Opening another app?</summary>
      <nav aria-label="Private apps">
        <a href="${url(input.docsUrl)}">Documentation <span aria-hidden="true">↗</span></a>
        <a href="${url(input.shellUrl)}">Shell workbench <span aria-hidden="true">↗</span></a>
      </nav>
      <p class="helper">Each app uses your existing access permissions.</p>
    </details>
    <footer>
      <p class="meta">Your private Mhoo workspace.</p>
      <nav aria-label="Support and legal">
        <a href="${url(input.privacyUrl)}">Privacy</a>
        <a href="${url(input.termsUrl)}">Terms</a>
        <a href="${url(input.helpUrl)}">Help</a>
      </nav>
    </footer>
  </main>
</body>
</html>
`; }
