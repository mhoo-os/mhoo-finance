import { type EmailMessage } from './email.ts';
export type OperationalTemplateId = 'workspace-invite' | 'magic-link' | 'password-reset' | 'workspace-welcome' | 'payment-receipt';
export type OperationalEmail = {
    template: OperationalTemplateId;
    message: EmailMessage;
};
export declare function workspaceInviteEmail(input: {
    publicOrigin: string;
    acceptUrl: string;
    inviterName: string;
    workspaceName: string;
    role: string;
    expiresInDays: number;
}): OperationalEmail;
export declare function magicLinkEmail(input: {
    publicOrigin: string;
    signInUrl: string;
    expiresInMinutes: number;
}): OperationalEmail;
export declare function passwordResetEmail(input: {
    publicOrigin: string;
    resetUrl: string;
    expiresInMinutes: number;
}): OperationalEmail;
export declare function workspaceWelcomeEmail(input: {
    publicOrigin: string;
    workspaceUrl: string;
}): OperationalEmail;
export declare function paymentReceiptEmail(input: {
    publicOrigin: string;
    receiptUrl: string;
    receiptNumber: string;
    amount: string;
    currency: string;
    plan: string;
    billingPeriod: string;
    paidOn: string;
    paymentMethod: string;
}): OperationalEmail;
