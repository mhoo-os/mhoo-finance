const escapeHtml = (value) => value.replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
const KIND_LABELS = { news: 'NEWS', transactional: 'TRANSACTIONAL', system: 'SYSTEM', notification: 'NOTIFICATION', 'auto-reply': 'RECEIVED' };
const SOCIAL_LINKS = [
    ['github', 'GitHub', 'https://github.com/mhoo-os'],
    ['instagram', 'Instagram', 'https://instagram.com/mootanyawit/'],
    ['youtube', 'YouTube', 'https://youtube.com/@mootanyawit'],
    ['linkedin', 'LinkedIn', 'https://linkedin.com/in/tanyawit/'],
];
const LEGAL_LINKS = [
    ['Privacy', '/legal/privacy/'], ['Terms', '/legal/terms/'],
    ['Acceptable use', '/legal/acceptable-use/'], ['Data deletion', '/data-deletion/'],
    ['DPA', '/legal/dpa/'], ['Open source', '/legal/open-source/'],
];
/** One renderer owns Mhoo branding, HTML escaping, and the text fallback. */
export function renderBrandedEmail(input) {
    const origin = escapeHtml(input.publicOrigin);
    const editorial = input.layout === 'story' || input.kind === 'news';
    const compact = !editorial;
    const actionUrl = input.action ? escapeHtml(input.action.url) : '';
    const action = input.action ? `<table role="presentation" cellspacing="0" cellpadding="0" style="margin-top:28px"><tr><td style="${editorial ? 'border-bottom:1px solid #075cff' : 'background:#075cff;border-radius:3px'}"><a href="${actionUrl}" style="display:inline-block;padding:${editorial ? '10px 0' : '15px 23px'};color:${editorial ? '#075cff' : '#fff'};font:700 14px/1.5 Arial,sans-serif;text-decoration:none">${escapeHtml(input.action.label)} &nbsp;↗</a></td></tr></table>` : '';
    const note = input.note ? `<p style="margin:24px 0 0;font:13px/1.7 Arial,sans-serif;color:#647080">${escapeHtml(input.note)}</p>` : '';
    const textAction = input.action ? `\n\n${input.action.label}: ${input.action.url}` : '';
    const textNote = input.note ? `\n\n${input.note}` : '';
    const facts = input.facts?.length ? `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:28px;border-top:1px solid #e1e6ec">${input.facts.map(fact => `<tr><td style="padding:12px 0;border-bottom:1px solid #e1e6ec;font:12px/1.5 Arial,sans-serif;color:#647080">${escapeHtml(fact.label)}</td><td align="right" style="padding:12px 0;border-bottom:1px solid #e1e6ec;font:700 12px/1.5 Arial,sans-serif;color:#172033">${escapeHtml(fact.value)}</td></tr>`).join('')}</table>` : '';
    const sections = input.sections?.length ? input.sections.map(section => `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:38px;border-top:1px solid #e1e6ec"><tr><td style="padding-top:30px">${section.eyebrow ? `<p style="margin:0 0 12px;font:10px/1.5 'Courier New',monospace;letter-spacing:1px;color:#075cff">${escapeHtml(section.eyebrow)}</p>` : ''}<h2 style="margin:0 0 14px;font:700 ${editorial ? '28' : '21'}px/1.2 Arial,sans-serif;letter-spacing:-.7px;color:#172033">${escapeHtml(section.heading)}</h2><p style="margin:0;font:15px/1.85 Arial,sans-serif;color:#526174">${escapeHtml(section.body)}</p>${section.quote ? `<blockquote style="margin:28px 0 4px;padding:3px 0 3px 20px;border-left:2px solid #075cff;font:24px/1.45 Georgia,serif;color:#172033">${escapeHtml(section.quote)}</blockquote>` : ''}${section.action ? `<p style="margin:18px 0 0"><a href="${escapeHtml(section.action.url)}" style="color:#075cff;font:700 13px/1.5 Arial,sans-serif;text-decoration:none;border-bottom:1px solid #075cff">${escapeHtml(section.action.label)} &nbsp;↗</a></p>` : ''}</td></tr></table>`).join('') : '';
    const artwork = input.artwork ? `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin:30px 0 32px"><tr><td><img src="${origin}/api/newsletter/assets/email-${input.artwork}.png?v=1" alt="${escapeHtml(input.artworkCaption || 'Mhoo editorial illustration')}" width="552" style="display:block;width:100%;height:auto;border:0;background:#f4f6f8"></td></tr>${input.artworkCaption ? `<tr><td style="padding-top:10px;font:10px/1.6 'Courier New',monospace;color:#647080">${escapeHtml(input.artworkCaption)}</td></tr>` : ''}</table>` : '';
    const summary = input.summary ? `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:28px;background:#f4f6f8"><tr><td style="padding:24px"><p style="margin:0 0 8px;font:10px/1.5 'Courier New',monospace;color:#647080;letter-spacing:1px">${escapeHtml(input.summary.label)}</p><p style="margin:0;font:700 ${input.layout === 'receipt' ? '38' : '23'}px/1.3 Arial,sans-serif;color:#172033;letter-spacing:-.8px">${escapeHtml(input.summary.value)}</p></td></tr></table>` : '';
    const signature = input.signature ? `<p style="margin:32px 0 0;font:15px/1.8 Arial,sans-serif;color:#172033">${escapeHtml(input.signature)}</p>` : '';
    const textFacts = input.facts?.length ? `\n\n${input.facts.map(fact => `${fact.label}: ${fact.value}`).join('\n')}` : '';
    const textSections = input.sections?.length ? `\n\n${input.sections.map(section => `${section.heading}\n${section.body}${section.quote ? `\n“${section.quote}”` : ''}${section.action ? `\n${section.action.label}: ${section.action.url}` : ''}`).join('\n\n')}` : '';
    const unsubscribe = input.unsubscribeUrl ? `<p style="margin:18px 0 0;font:12px/1.7 Arial,sans-serif;color:#647080">You're receiving Mhoo News because you subscribed.<br><a href="${escapeHtml(input.unsubscribeUrl)}" style="color:#344a63;text-decoration:underline">Unsubscribe</a> at any time.</p>` : '';
    const socials = [...SOCIAL_LINKS, ['contact', 'Contact', `${input.publicOrigin}/contact/`]].map(([icon, label, url]) => `<td width="56" style="padding:0 8px 0 0"><a href="${escapeHtml(url)}" title="${label}" style="display:block;text-decoration:none"><img src="${origin}/api/newsletter/assets/email-${icon}.png?v=3" alt="${label}" width="44" height="44" style="display:block;border:0;width:44px;height:44px;color:#344a63;font:10px Arial,sans-serif"></a></td>`).join('');
    const legal = LEGAL_LINKS.map(([label, path]) => `<a href="${origin}${path}" style="display:inline-block;margin-right:14px;padding:4px 0;color:#566577;text-decoration:none;white-space:nowrap">${label}</a>`).join(' ');
    const textFooter = `\n\nMhoo Co., Ltd. · Bangkok, Thailand\nContact: ${input.publicOrigin}/contact/\n${SOCIAL_LINKS.map(([, label, url]) => `${label}: ${url}`).join('\n')}\n${LEGAL_LINKS.map(([label, path]) => `${label}: ${input.publicOrigin}${path}`).join('\n')}${input.unsubscribeUrl ? `\nUnsubscribe: ${input.unsubscribeUrl}` : ''}`;
    return {
        subject: input.subject,
        text: `${input.heading}\n\n${input.body}${input.summary ? `\n\n${input.summary.label}: ${input.summary.value}` : ''}${textFacts}${textSections}${textAction}${textNote}${input.signature ? `\n\n${input.signature}` : ''}${textFooter}`,
        html: `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>${escapeHtml(input.subject)}</title>
<style>@media only screen and (max-width:480px){.email-gutter{padding-left:24px!important;padding-right:24px!important}.email-title{font-size:32px!important;letter-spacing:-1.2px!important}.email-masthead{padding-top:30px!important;padding-bottom:34px!important}.email-body{padding-bottom:38px!important}}</style>
</head><body style="margin:0;padding:0;background:#fff;color:#172033;-webkit-text-size-adjust:100%">
<div style="display:none;max-height:0;overflow:hidden;opacity:0;mso-hide:all">${escapeHtml(input.preheader)}</div>
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;background:#fff"><tr><td align="center">
<!--[if mso]><table role="presentation" width="640" cellspacing="0" cellpadding="0"><tr><td><![endif]-->
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="width:100%;max-width:640px;border-collapse:collapse;background:#fff">
<tr><td class="email-gutter" style="padding:28px 44px 0"><table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr>
<td style="font:11px/1.5 Arial,sans-serif;color:#566577"><a href="${origin}" style="color:#566577;text-decoration:none">mhoo<span style="color:#075cff">.</span></a></td>
<td align="right" style="font:10px/1.5 'Courier New',monospace;letter-spacing:1px;color:#566577">${KIND_LABELS[input.kind]}${input.index ? ` / ${escapeHtml(input.index)}` : ''}</td>
</tr></table></td></tr>
<tr><td class="email-gutter email-masthead" style="padding:${compact ? '38px 44px 40px' : '42px 44px 42px'}"><a href="${origin}" style="display:block;text-decoration:none"><img src="${origin}/api/newsletter/assets/mhoo-particle-wordmark.png?v=3" width="${compact ? '190' : '552'}" alt="MHOO" style="display:block;width:${compact ? '190px' : '100%'};max-width:100%;height:auto;border:0;color:#111;font:900 48px/1 Arial,sans-serif"></a></td></tr>
<tr><td class="email-gutter email-body" style="padding:0 44px 46px">
<p style="margin:0 0 16px;font:11px/1.6 'Courier New',monospace;letter-spacing:1px;color:#075cff">${escapeHtml(input.eyebrow)}${input.date ? `<span style="color:#647080"> &nbsp;/&nbsp; ${escapeHtml(input.date)}</span>` : ''}</p>
<h1 class="email-title" style="margin:0 0 20px;font:700 ${compact ? '34' : '44'}px/1.12 Arial,sans-serif;letter-spacing:-1.6px;color:#172033">${escapeHtml(input.heading)}</h1>
<p style="margin:0;font:16px/1.8 Arial,sans-serif;color:#526174">${escapeHtml(input.body)}</p>${summary}${artwork}${facts}${editorial ? sections + action : action + note + sections}${editorial ? note : ''}${signature}
</td></tr>
<tr><td class="email-gutter" style="padding:0 44px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="border-top:1px solid #e1e6ec"><tr><td style="padding-top:26px">
${editorial ? '<p style="margin:0 0 6px;font:700 18px/1.4 Arial,sans-serif;letter-spacing:-.4px;color:#172033">The work continues.</p><p style="margin:0 0 18px;font:13px/1.7 Arial,sans-serif;color:#647080">Experiments, conversations, and things we’re building.</p>' : ''}
<table role="presentation" cellspacing="0" cellpadding="0"><tr>${socials}</tr></table>
<p style="margin:18px 0 0;font:13px/1.7 Arial,sans-serif"><a href="mailto:support@mhoooo.com" style="color:#344a63;text-decoration:none">support@mhoooo.com</a><span style="color:#b0bbc6"> &nbsp; / &nbsp; </span><a href="${origin}/contact/" style="color:#344a63;text-decoration:none">Contact Mhoo ↗</a></p>
</td></tr></table></td></tr>
<tr><td class="email-gutter" style="padding:24px 44px 30px">
<p style="margin:0 0 12px;font:12px/1.7 Arial,sans-serif">${legal}</p>
<p style="margin:0;font:11px/1.75 Arial,sans-serif;color:#647080">© 2026 Mhoo Co., Ltd. · Bangkok, Thailand<br>48/49 Soi Ramkhamhaeng102, Saphan Sung, Bangkok 10240, Thailand</p>${unsubscribe}
</td></tr></table>
<!--[if mso]></td></tr></table><![endif]-->
</td></tr></table></body></html>`,
    };
}
export function confirmationEmail(confirmUrl, publicOrigin) {
    const message = renderBrandedEmail({ kind: 'transactional', subject: 'Confirm your Mhoo News subscription', preheader: 'One quiet click to confirm', eyebrow: 'ONE QUIET CLICK', heading: 'Stay close to the work.', body: 'Confirm that you want occasional Mhoo development notes, experiments, and founder stories. Owning a workspace never subscribes you automatically.', action: { label: 'Confirm subscription', url: confirmUrl }, note: 'This link expires soon and works once. If you did not request it, ignore this message.', publicOrigin });
    return { ...message, text: `Confirm your Mhoo News subscription: ${confirmUrl}\n\nIf you did not request this, ignore this message. You will not be subscribed.` };
}
export const newsEmail = (input) => renderBrandedEmail({ ...input, kind: 'news' });
export const systemEmail = (input) => renderBrandedEmail({ ...input, kind: 'system' });
export const notificationEmail = (input) => renderBrandedEmail({ ...input, kind: 'notification' });
export const autoReplyEmail = (input) => renderBrandedEmail({ ...input, kind: 'auto-reply', eyebrow: 'MESSAGE RECEIVED', note: input.note ?? 'This automatic reply confirms receipt. A person has not reviewed your message yet.' });
