# Mhoo communications

Shared presentation owned by mhoo-shell. The small @mhoo/communications package lets mail and static-site consumers reuse the design without installing the workspace shell runtime. Shell also exposes these files under its communications subpaths.

- `email`: escaped branded HTML and plain-text emails, including newsletter confirmation.
- `email-templates`: invitation, magic-link, password-reset, welcome and receipt renderers.
- `signin`: `renderSignIn({continueUrl, docsUrl, shellUrl, homeUrl, privacyUrl, termsUrl, helpUrl, wordmarkUrl, stylesheetUrl})`. The consumer owns the destinations and authentication.
- `signin.css` and `assets/mhoo-particle-wordmark.png`: static presentation assets.

The particle PNG is the unchanged Email Hub asset from a496efdc3029947c44bc347e468613fc24cd6897. It is a static wordmark; interactive particle behavior remains in @mhoo/particle-ui. The landing's @mhoo/brand package currently owns the separate mascot and favicon.

Email renderers preserve existing output and accept trusted application-generated URLs. They do not issue tokens, grant permissions, send email, or validate authentication. Preview-only consent interactions and sample identities remain in Email Hub. Existing email artwork and social icon URLs remain hosted by Email Hub.

Pack this directory with `npm pack`, then install the versioned tarball in consumers and commit their lockfiles. There is no runtime CDN dependency. The entrance build copies assets from the installed package; edit this source, never the generated copies.
