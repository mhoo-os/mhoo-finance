export type EmailKind = 'news' | 'transactional' | 'system' | 'notification' | 'auto-reply';
export type EmailMessage = {
    subject: string;
    text: string;
    html: string;
};
export type EmailAction = {
    label: string;
    url: string;
};
export type EmailSection = {
    eyebrow?: string;
    heading: string;
    body: string;
    action?: EmailAction;
    quote?: string;
};
export type EmailFact = {
    label: string;
    value: string;
};
export type BrandedEmail = {
    kind: EmailKind;
    subject: string;
    preheader: string;
    eyebrow: string;
    heading: string;
    body: string;
    publicOrigin: string;
    action?: EmailAction;
    note?: string;
    date?: string;
    index?: string;
    unsubscribeUrl?: string;
    sections?: EmailSection[];
    facts?: EmailFact[];
    layout?: 'action' | 'letter' | 'receipt' | 'story';
    artwork?: 'delivery' | 'finance' | 'clover';
    artworkCaption?: string;
    summary?: {
        label: string;
        value: string;
    };
    signature?: string;
};
/** One renderer owns Mhoo branding, HTML escaping, and the text fallback. */
export declare function renderBrandedEmail(input: BrandedEmail): EmailMessage;
export declare function confirmationEmail(confirmUrl: string, publicOrigin: string): {
    text: string;
    subject: string;
    html: string;
};
export declare const newsEmail: (input: Omit<BrandedEmail, "kind">) => EmailMessage;
export declare const systemEmail: (input: Omit<BrandedEmail, "kind">) => EmailMessage;
export declare const notificationEmail: (input: Omit<BrandedEmail, "kind">) => EmailMessage;
export declare const autoReplyEmail: (input: Omit<BrandedEmail, "kind" | "eyebrow">) => EmailMessage;
