import { notificationEmail, systemEmail } from "./email.js";
const oneLine = (value) => value.replace(/[\r\n]+/g, ' ').trim();
export function workspaceInviteEmail(input) {
    const inviter = oneLine(input.inviterName);
    const workspace = oneLine(input.workspaceName);
    return { template: 'workspace-invite', message: notificationEmail({ publicOrigin: input.publicOrigin, subject: `${inviter} invited you to ${workspace}`, preheader: `Join ${workspace} as ${oneLine(input.role)}`, eyebrow: 'YOU’RE INVITED', heading: 'A place at the table.', body: `${inviter} invited you to work together in Mhoo. Here’s where you’ll be joining.`, summary: { label: 'WORKSPACE', value: workspace }, facts: [{ label: 'Invited by', value: inviter }, { label: 'Your role', value: oneLine(input.role) }], action: { label: 'Accept invitation', url: input.acceptUrl }, note: `This invitation expires in ${input.expiresInDays} days. If you weren’t expecting it, you can leave it unanswered.` }) };
}
export function magicLinkEmail(input) {
    return { template: 'magic-link', message: systemEmail({ publicOrigin: input.publicOrigin, subject: 'Your link to sign in to Mhoo', preheader: `Valid for ${input.expiresInMinutes} minutes · Use once`, eyebrow: 'SIGN IN TO MHOO', heading: 'Pick up where you left off.', body: 'Your secure sign-in link is ready. Use it to return to your workspace.', action: { label: 'Sign in to Mhoo', url: input.signInUrl }, note: `Valid for ${input.expiresInMinutes} minutes. This link works once and is only for you. If you didn’t request it, ignore this email.` }) };
}
export function passwordResetEmail(input) {
    return { template: 'password-reset', message: systemEmail({ publicOrigin: input.publicOrigin, subject: 'Reset your Mhoo password', preheader: `Reset link valid for ${input.expiresInMinutes} minutes`, eyebrow: 'ACCOUNT SECURITY', heading: 'Choose a new password.', body: 'We received a request to reset the password for your Mhoo account.', action: { label: 'Reset password', url: input.resetUrl }, note: `This link expires in ${input.expiresInMinutes} minutes. If this wasn’t you, your password has not changed.` }) };
}
export function workspaceWelcomeEmail(input) {
    return { template: 'workspace-welcome', message: notificationEmail({ publicOrigin: input.publicOrigin, layout: 'letter', subject: 'Welcome to Mhoo', preheader: 'Start with one thing worth working on', eyebrow: 'WELCOME TO MHOO', heading: 'Make yourself at home.', body: 'Glad you’re here. Mhoo is a place for work that needs a little more context—a project, a question, or an experiment you don’t want to lose track of.', action: { label: 'Open your workspace', url: input.workspaceUrl }, sections: [{ eyebrow: 'START SMALL', heading: 'Bring one real thing.', body: 'A note you keep rewriting. A workflow that keeps falling through the cracks. A question with too many open tabs. Start there; you don’t need to set up everything today.' }], signature: 'See you in there — Moo', note: 'This welcome is about your workspace. Mhoo News is a separate, optional subscription.' }) };
}
export function paymentReceiptEmail(input) {
    const receiptNumber = oneLine(input.receiptNumber);
    const amount = oneLine(input.amount);
    const currency = oneLine(input.currency);
    return { template: 'payment-receipt', message: systemEmail({ publicOrigin: input.publicOrigin, layout: 'receipt', subject: `Your Mhoo receipt · ${receiptNumber}`, preheader: `Payment received · ${amount} ${currency}`, eyebrow: 'PAYMENT RECEIVED', heading: 'All taken care of.', body: 'Thanks for being part of Mhoo. Here’s the record of your latest workspace payment.', summary: { label: `TOTAL PAID · ${currency}`, value: amount }, facts: [{ label: oneLine(input.plan), value: amount }, { label: 'Receipt number', value: receiptNumber }, { label: 'Billing period', value: oneLine(input.billingPeriod) }, { label: 'Paid on', value: oneLine(input.paidOn) }, { label: 'Payment method', value: oneLine(input.paymentMethod) }], action: { label: 'Download receipt', url: input.receiptUrl }, note: 'Questions about this payment? Contact support@mhoooo.com and include your receipt number.' }) };
}
