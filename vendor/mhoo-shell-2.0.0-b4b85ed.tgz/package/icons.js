/** Mhoo artwork icon catalog. Coordinates point into the original, unchanged contact sheet. */
const rows = [
  ['mascot', 'terminal', 'folder', 'document', 'data-cylinder', 'settings', 'cloud', 'code'],
  ['search', 'connections', 'cube', 'rocket', 'desktop', 'mobile', 'layers', 'database'],
  ['code-file', 'edit', 'trash', 'download', 'upload', 'sync', 'shield', 'lock'],
  ['person', 'people', 'chat', 'notifications', 'calendar', 'inbox', 'console', 'toggle'],
  ['globe', 'compass', 'command', 'favorite', 'link', 'analytics', 'folder-add', 'cloud-download'],
];
const centersY = [120, 275, 425, 585, 740];
const coordinates = Object.fromEntries(rows.flatMap((row, rowIndex) => row.map((name, column) => [name, [80 + column * 160, centersY[rowIndex]]])));
const aliases = Object.freeze({ brand: 'mascot', dashboard: 'analytics', finance: 'database', files: 'folder', bell: 'notifications', chart: 'analytics', mail: 'inbox', group: 'people' });
export const iconNames = Object.freeze(rows.flat());
export const hasIcon = name => Object.hasOwn(coordinates, name) || Object.hasOwn(aliases, name);
const resolve = name => {
  const key = Object.hasOwn(aliases, name) ? aliases[name] : name;
  if (!Object.hasOwn(coordinates, key)) throw new RangeError(`Unknown Mhoo icon: ${name}`);
  return key;
};
const styleFor = (name, size) => {
  if (!Number.isFinite(size) || size < 8 || size > 256) throw new RangeError('Icon size must be between 8 and 256 pixels');
  const [x, y] = coordinates[resolve(name)];
  const scale = size / 160;
  return `width:${size}px;height:${size}px;background-size:${1280 * scale}px ${853 * scale}px;background-position:${size / 2 - x * scale}px ${size / 2 - y * scale}px`;
};
const escape = value => String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

/** Framework-neutral HTML; load @mhoo/shell/icons.css alongside it. */
export function renderIcon(name, { size = 32, label } = {}) {
  const key = resolve(name);
  const accessibility = label ? `role="img" aria-label="${escape(label)}"` : 'aria-hidden="true"';
  return `<span class="mhoo-icon mhoo-icon-${key}" style="${styleFor(key, size)}" ${accessibility}></span>`;
}

/** Native DOM variant for plain JS apps; React/Vue can use renderIcon or the CSS class. */
export function createIcon(name, options = {}) {
  const element = document.createElement('span');
  const key = resolve(name);
  element.className = `mhoo-icon mhoo-icon-${key}`;
  element.style.cssText = styleFor(key, options.size ?? 32);
  if (options.label) { element.setAttribute('role', 'img'); element.setAttribute('aria-label', String(options.label)); }
  else element.setAttribute('aria-hidden', 'true');
  return element;
}
